'use strict';

/**
 * ═══════════════════════════════════════════════════════════════
 *  Reply Helper
 *  Fungsi pengiriman pesan dengan tampilan newsletter & ad-reply.
 *
 *  Konfigurasi di config.json → bagian "botReply":
 *    botName        – nama bot di judul notifikasi
 *    ownerNumber    – nomor owner (tanpa +), untuk link wa.me
 *    newsletterJid  – JID channel WhatsApp (120363xxx@newsletter)
 *    newsletterName – nama channel/newsletter
 *    thumbnailUrl   – URL gambar thumbnail ad-reply
 *    replyBody      – teks body pada notifikasi ad-reply
 * ═══════════════════════════════════════════════════════════════
 */

import fs from 'fs';
import path from 'path';

const CONFIG_PATH = path.join(process.cwd(), 'config.json');

/**
 * Baca konfigurasi botReply dari config.json.
 * Jika tidak ada / gagal dibaca, gunakan nilai default.
 * @returns {object}
 */
export function getReplyConfig() {
    try {
        const raw  = fs.readFileSync(CONFIG_PATH, 'utf-8');
        const cfg  = JSON.parse(raw);
        const r    = cfg.botReply || {};
        return {
            botName:       r.botName       || 'Wily Bot',
            ownerNumber:   r.ownerNumber   || '',
            newsletterJid: r.newsletterJid || '',
            newsletterName:r.newsletterName|| 'Wily Bot Channel',
            thumbnailUrl:  r.thumbnailUrl  || '',
            replyBody:     r.replyBody     || 'Halo kak! Ada yang bisa saya bantu? 🙏',
        };
    } catch (_) {
        return {
            botName: 'Wily Bot', ownerNumber: '', newsletterJid: '',
            newsletterName: 'Wily Bot Channel', thumbnailUrl: '', replyBody: 'Halo kak! 🙏',
        };
    }
}

/**
 * Buat objek contextInfo berisi newsletter + external ad-reply.
 * Bisa langsung di-spread ke payload sendMessage.
 *
 * @param {string} senderJid – JID yang di-mention (misal: 6281234@s.whatsapp.net)
 * @param {string} [titlePrefix='🚫'] – emoji / teks di depan botName
 * @returns {object} contextInfo
 */
export function buildReplyContext(senderJid, titlePrefix = '🚫') {
    const cfg = getReplyConfig();
    const sourceUrl = cfg.ownerNumber ? `https://wa.me/${cfg.ownerNumber}` : '';
    return {
        mentionedJid: senderJid ? [senderJid] : [],
        forwardingScore: 999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid:     cfg.newsletterJid,
            serverMessageId:   Math.floor(Math.random() * 9999) + 1,
            newsletterName:    cfg.newsletterName,
        },
        externalAdReply: {
            showAdAttribution: true,
            containsAutoReply: true,
            title:             `${titlePrefix} ${cfg.botName}`,
            body:              cfg.replyBody,
            previewType:       'VIDEO',
            thumbnailUrl:      cfg.thumbnailUrl,
            sourceUrl,
        },
    };
}

/**
 * Kirim pesan penolakan dengan tampilan newsletter & ad-reply penuh.
 *
 * @param {object} hydro  – instance socketon/Baileys (hisoka / conn)
 * @param {object} m      – pesan masuk (sudah di-inject, harus punya .chat/.from & .sender)
 * @param {string} sender – JID pengirim yang akan di-mention
 * @param {string} teks   – teks yang akan dikirimkan
 */
export async function replyTolak(hydro, m, sender, teks) {
    const toJid = m.chat || m.from;
    const sent = await hydro.sendMessage(
        toJid,
        {
            text:        teks,
            contextInfo: buildReplyContext(sender, '🚫'),
        },
        { quoted: m }
    );
    return sent;
}

/**
 * Versi ringkas — otomatis pakai m.sender sebagai mention, prefix '🚫'.
 *
 * Contoh pemakaian di command handler:
 *   import { tolak } from '../helper/reply.js';
 *   await tolak(hydro, m, 'Kamu tidak punya izin untuk fitur ini.');
 *
 * @param {object} hydro  – instance socketon/Baileys
 * @param {object} m      – pesan masuk (sudah di-inject)
 * @param {string} teks   – teks penolakan
 */
export async function tolak(hydro, m, teks) {
    return await replyTolak(hydro, m, m.sender, teks);
}
