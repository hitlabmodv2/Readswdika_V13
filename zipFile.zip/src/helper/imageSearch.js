import axios from 'axios';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36';

// ── Normalisasi query: bersihkan suffix bahasa Indonesia ──
function normalizeQuery(query) {
    let q = query.trim();
    // Hapus suffix possessive Indonesia: -nya (jika kata dasar >= 3 karakter)
    q = q.replace(/\b(\w{3,})(nya)\b/gi, '$1');
    // Hapus suffix -lah, -kah, -pun
    q = q.replace(/\b(\w{3,})(lah|kah|pun)\b/gi, '$1');
    // Bersihkan spasi berlebih
    q = q.replace(/\s+/g, ' ').trim();
    return q;
}

async function downloadImageBuffer(url, timeout = 8000) {
    const { data } = await axios.get(url, {
        responseType: 'arraybuffer',
        timeout,
        headers: {
            'User-Agent': UA,
            'Accept': 'image/webp,image/apng,image/*,*/*;q=0.8',
            'Referer': 'https://www.google.com/',
        },
        maxRedirects: 5,
    });
    return Buffer.from(data);
}

// ── Sumber 1: Google Images (paling andal) ──
async function searchGoogle(query, count = 10) {
    try {
        const { data } = await axios.get('https://www.google.com/search', {
            params: { q: query, tbm: 'isch', hl: 'en', safe: 'off', num: 30 },
            headers: {
                'User-Agent': UA,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.9',
                'Accept-Encoding': 'gzip, deflate',
                'Referer': 'https://www.google.com/',
            },
            timeout: 10000,
        });
        const results = [];
        const seen = new Set();
        // Pattern 1: ["url",width,height] embedded in page JSON
        const re1 = /\["(https?:\/\/(?!encrypted-tbn)[^"\\]{10,}\.(?:jpg|jpeg|png|webp|gif)(?:\?[^"\\]{0,200})?)",\d+,\d+\]/g;
        let m;
        while ((m = re1.exec(data)) !== null && results.length < count) {
            const url = m[1];
            if (!seen.has(url) && !url.includes('gstatic') && !url.includes('google')) {
                seen.add(url);
                results.push({ image: url, title: query });
            }
        }
        // Pattern 2: "ou":"url" older format
        if (results.length < 3) {
            const re2 = /"ou":"(https?:\/\/[^"]+)"/g;
            while ((m = re2.exec(data)) !== null && results.length < count) {
                const url = m[1];
                if (!seen.has(url) && !url.includes('google') && !url.includes('gstatic')) {
                    seen.add(url);
                    results.push({ image: url, title: query });
                }
            }
        }
        console.log(`[ImageSearch] Google: ${results.length} hasil`);
        return results;
    } catch (e) {
        console.error(`[ImageSearch] Google error: ${e.message}`);
        return [];
    }
}

// ── Sumber 2: Bing Images ──
async function searchBing(query, count = 10) {
    try {
        const { data } = await axios.get('https://www.bing.com/images/async', {
            params: { q: query, first: 1, count: count * 2, mmasync: 1, adlt: 'off' },
            headers: {
                'User-Agent': UA,
                'Accept': 'text/html,application/xhtml+xml,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.9',
                'Referer': 'https://www.bing.com/',
                'Cookie': 'SRCHHPGUSR=ADLT=DEMOTE',
            },
            timeout: 8000,
        });
        const results = [];
        const seen = new Set();
        const patterns = [
            /"murl":"([^"]+)"/g,
            /"imgurl":"([^"]+)"/g,
            /imgurl=([^&"]+)/g,
        ];
        for (const re of patterns) {
            let m;
            while ((m = re.exec(data)) !== null && results.length < count) {
                try {
                    const url = decodeURIComponent(m[1]);
                    if (url.startsWith('http') && !seen.has(url) && !url.includes('bing.com')) {
                        seen.add(url);
                        results.push({ image: url, title: query });
                    }
                } catch (_) {}
            }
            if (results.length >= 3) break;
        }
        console.log(`[ImageSearch] Bing: ${results.length} hasil`);
        return results;
    } catch (e) {
        console.error(`[ImageSearch] Bing error: ${e.message}`);
        return [];
    }
}

// ── Sumber 3: DuckDuckGo Images ──
async function searchDuckDuckGo(query, count = 8) {
    try {
        const { data: tokenData } = await axios.get('https://duckduckgo.com/', {
            params: { q: query, iax: 'images', ia: 'images' },
            headers: {
                'User-Agent': UA,
                'Accept': 'text/html',
                'Accept-Language': 'en-US,en;q=0.9',
            },
            timeout: 8000,
        });
        const vqdMatch = tokenData.match(/vqd=([\d-]+)/);
        if (!vqdMatch) {
            console.log(`[ImageSearch] DDG: gagal ambil vqd token`);
            return [];
        }
        const vqd = vqdMatch[1];
        const { data } = await axios.get('https://duckduckgo.com/i.js', {
            params: { q: query, vqd, f: ',,,,,', p: 1 },
            headers: {
                'User-Agent': UA,
                'Referer': 'https://duckduckgo.com/',
                'Accept': 'application/json',
            },
            timeout: 8000,
        });
        const results = (data.results || []).slice(0, count).map(r => ({
            image: r.image || r.url,
            title: r.title || query,
        })).filter(r => r.image);
        console.log(`[ImageSearch] DDG: ${results.length} hasil`);
        return results;
    } catch (e) {
        console.error(`[ImageSearch] DDG error: ${e.message}`);
        return [];
    }
}

// ── Sumber 4: Openverse API (gambar bebas lisensi) ──
async function searchOpenverse(query, count = 8) {
    try {
        const { data } = await axios.get('https://api.openverse.org/v1/images/', {
            params: { q: query, page_size: count, license_type: 'all' },
            headers: { 'User-Agent': UA },
            timeout: 8000,
        });
        const results = (data.results || []).map(r => ({ image: r.url, title: r.title || query }));
        console.log(`[ImageSearch] Openverse: ${results.length} hasil`);
        return results;
    } catch (e) {
        console.error(`[ImageSearch] Openverse error: ${e.message}`);
        return [];
    }
}

// ── Sumber 5: Yandex Images ──
async function searchYandex(query, count = 8) {
    try {
        const { data } = await axios.get('https://yandex.com/images/search', {
            params: { text: query, isize: 'medium' },
            headers: {
                'User-Agent': UA,
                'Accept': 'text/html',
                'Accept-Language': 'en-US,en;q=0.9',
            },
            timeout: 10000,
        });
        const results = [];
        const seen = new Set();
        // Yandex embeds image JSON in page
        const re = /"url":"(https?:\/\/[^"]+\.(?:jpg|jpeg|png|webp)[^"]*)"/g;
        let m;
        while ((m = re.exec(data)) !== null && results.length < count) {
            const url = m[1].replace(/\\u002F/g, '/').replace(/\\\//g, '/');
            if (!seen.has(url) && !url.includes('yandex') && url.length > 20) {
                seen.add(url);
                results.push({ image: url, title: query });
            }
        }
        console.log(`[ImageSearch] Yandex: ${results.length} hasil`);
        return results;
    } catch (e) {
        console.error(`[ImageSearch] Yandex error: ${e.message}`);
        return [];
    }
}

// ── Sumber 6: Wikipedia thumbnail ──
async function searchWikipedia(query) {
    try {
        const { data } = await axios.get('https://en.wikipedia.org/w/api.php', {
            params: {
                action: 'query', generator: 'search', gsrsearch: query,
                prop: 'pageimages', pithumbsize: 800, format: 'json',
                gsrnamespace: 0, gsrlimit: 6,
            },
            headers: { 'User-Agent': UA },
            timeout: 8000,
        });
        const pages = Object.values(data.query?.pages || {});
        const results = pages.filter(p => p.thumbnail?.source).map(p => ({ image: p.thumbnail.source, title: p.title || query }));
        console.log(`[ImageSearch] Wikipedia: ${results.length} hasil`);
        return results;
    } catch (e) {
        console.error(`[ImageSearch] Wikipedia error: ${e.message}`);
        return [];
    }
}

// ── Download satu gambar valid dari daftar ──
async function tryDownloadOne(results) {
    for (const r of results) {
        try {
            if (!r.image || r.image.length < 10) continue;
            const buf = await downloadImageBuffer(r.image, 9000);
            if (buf && buf.length > 5000) return { buffer: buf, url: r.image, title: r.title };
        } catch (_) {}
    }
    return null;
}

// ── Download N gambar berbeda dari daftar ──
async function tryDownloadMany(results, count = 1) {
    const found = [];
    const usedUrls = new Set();
    for (const r of results) {
        if (found.length >= count) break;
        try {
            if (!r.image || r.image.length < 10 || usedUrls.has(r.image)) continue;
            const buf = await downloadImageBuffer(r.image, 9000);
            if (buf && buf.length > 5000) {
                found.push({ buffer: buf, url: r.image, title: r.title });
                usedUrls.add(r.image);
            }
        } catch (_) {}
    }
    return found;
}

// ── Cari 1 gambar (semua sumber paralel, ambil yang pertama berhasil) ──
export async function searchAndGetImage(query) {
    const q = normalizeQuery(query);
    console.log(`[ImageSearch] Paralel cari: "${q}" (asli: "${query}")`);

    const [googleRes, bingRes, ddgRes, openverseRes, yandexRes, wikiRes] = await Promise.all([
        searchGoogle(q, 10),
        searchBing(q, 10),
        searchDuckDuckGo(q, 8),
        searchOpenverse(q, 6),
        searchYandex(q, 8),
        searchWikipedia(q),
    ]);

    // Susun: sumber paling andal duluan
    const allResults = [
        ...googleRes,
        ...bingRes,
        ...ddgRes,
        ...yandexRes,
        ...openverseRes,
        ...wikiRes,
    ];

    console.log(`[ImageSearch] Total kandidat: ${allResults.length}`);

    if (allResults.length > 0) {
        const found = await tryDownloadOne(allResults);
        if (found) {
            console.log(`[ImageSearch] ✅ Berhasil: ${found.url}`);
            return found;
        }
    }

    throw new Error('Semua sumber gambar gagal. Coba kata kunci yang lebih spesifik ya!');
}

// ── Cari N gambar sekaligus ──
export async function searchAndGetImages(query, count = 1) {
    if (count <= 1) {
        const single = await searchAndGetImage(query);
        return [single];
    }

    const q = normalizeQuery(query);
    console.log(`[ImageSearch] Paralel cari ${count} gambar: "${q}"`);

    const [googleRes, bingRes, ddgRes, openverseRes, yandexRes, wikiRes] = await Promise.all([
        searchGoogle(q, count * 4),
        searchBing(q, count * 4),
        searchDuckDuckGo(q, count * 3),
        searchOpenverse(q, count * 2),
        searchYandex(q, count * 3),
        searchWikipedia(q),
    ]);

    const allResults = [
        ...googleRes,
        ...bingRes,
        ...ddgRes,
        ...yandexRes,
        ...openverseRes,
        ...wikiRes,
    ];

    console.log(`[ImageSearch] Total kandidat (multi): ${allResults.length}`);

    if (allResults.length === 0) throw new Error('Tidak ada hasil gambar ditemukan. Coba kata kunci lain ya!');

    const found = await tryDownloadMany(allResults, count);
    if (found.length === 0) throw new Error('Gagal download gambar. Coba kata kunci lain ya!');

    console.log(`[ImageSearch] ✅ Berhasil download ${found.length}/${count} gambar`);
    return found;
}

export { downloadImageBuffer };
