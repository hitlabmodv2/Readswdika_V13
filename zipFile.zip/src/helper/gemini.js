import axios from 'axios';

class Gemini {
    constructor() {
        this.authToken = null;
        this.tokenExpiry = null;
    }

    async getAuthToken() {
        try {
            if (this.authToken && this.tokenExpiry && Date.now() < this.tokenExpiry - 300000) {
                return this.authToken;
            }

            const { data } = await axios.post(
                'https://www.googleapis.com/identitytoolkit/v3/relyingparty/signupNewUser?key=AIzaSyAxof8_SbpDcww38NEQRhNh0Pzvbphh-IQ',
                { clientType: 'CLIENT_TYPE_ANDROID' },
                {
                    headers: {
                        'accept-encoding': 'gzip',
                        'accept-language': 'in-ID, en-US',
                        'connection': 'Keep-Alive',
                        'content-type': 'application/json',
                        'user-agent': 'Dalvik/2.1.0 (Linux; U; Android 10; SM-J700F Build/QQ3A.200805.001)',
                        'x-android-cert': '037CD2976D308B4EFD63EC63C48DC6E7AB7E5AF2',
                        'x-android-package': 'com.jetkite.gemmy',
                        'x-client-version': 'Android/Fallback/X24000001/FirebaseCore-Android',
                        'x-firebase-appcheck': 'eyJlcnJvciI6IlVOS05PV05fRVJST1IifQ==',
                        'x-firebase-client': 'H4sIAAAAAAAAAKtWykhNLCpJSk0sKVayio7VUSpLLSrOzM9TslIyUqoFAFyivEQfAAAA',
                        'x-firebase-gmpid': '1:652803432695:android:c4341db6033e62814f33f2',
                    },
                }
            );

            if (!data.idToken) throw new Error('Failed to get Gemini auth token.');
            this.authToken = data.idToken;
            this.tokenExpiry = Date.now() + 3600 * 1000;

            return this.authToken;
        } catch (error) {
            throw new Error('Auth error: ' + error.message);
        }
    }

    async chat({ contents, model = 'gemini-flash-latest', ...config }) {
        try {
            if (!Array.isArray(contents)) throw new Error('Contents must be an array.');
            const authToken = await this.getAuthToken();

            const { data } = await axios.post(
                'https://asia-northeast3-gemmy-ai-bdc03.cloudfunctions.net/gemini',
                {
                    model,
                    stream: false,
                    request: {
                        contents,
                        generationConfig: {
                            maxOutputTokens: 8192,
                            ...config,
                        },
                    },
                },
                {
                    headers: {
                        'accept-encoding': 'gzip',
                        'authorization': `Bearer ${authToken}`,
                        'content-type': 'application/json; charset=UTF-8',
                        'user-agent': 'okhttp/5.3.2',
                    },
                    timeout: 30000,
                }
            );

            const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
            if (!text) throw new Error('Gemini returned empty response. Raw: ' + JSON.stringify(data).substring(0, 200));

            return text;
        } catch (error) {
            if (error.response?.data) {
                throw new Error(JSON.stringify(error.response.data).substring(0, 300));
            }
            throw new Error(error.message);
        }
    }

    // Chat text only
    async ask(prompt) {
        return this.chat({
            contents: [{ role: 'user', parts: [{ text: prompt }] }],
            model: 'gemini-flash-latest',
        });
    }

    // Chat dengan gambar (vision) - gunakan model yang support multimodal
    async askWithImage(prompt, imageBuffer, mimeType = 'image/jpeg') {
        if (!imageBuffer || imageBuffer.length === 0) {
            throw new Error('Image buffer kosong atau tidak valid');
        }

        const base64 = imageBuffer.toString('base64');

        // Coba dengan model yang tersedia di endpoint ini
        const models = ['gemini-flash-latest', 'gemini-2.0-flash', 'gemini-pro'];
        let lastError = null;

        for (const model of models) {
            try {
                const result = await this.chat({
                    model,
                    contents: [{
                        role: 'user',
                        parts: [
                            {
                                inlineData: {
                                    mimeType: mimeType,
                                    data: base64,
                                },
                            },
                            { text: prompt },
                        ],
                    }],
                });
                console.log(`\x1b[36m[Gemini Vision]\x1b[0m ✅ Berhasil dengan model: ${model}`);
                return result;
            } catch (err) {
                console.error(`\x1b[31m[Gemini Vision]\x1b[0m ❌ Model ${model} gagal: ${err.message}`);
                lastError = err;
            }
        }

        throw lastError || new Error('Semua model gagal untuk vision');
    }
}

const gemini = new Gemini();
export default gemini;
