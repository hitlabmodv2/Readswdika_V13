/**
 * ═══════════════════════════════════════════════════════════════
 *  Base Script    : Bang Dika Ardnt
 *  Recode By      : Bang Wilykun
 *  WhatsApp       : 6289688206739
 *  Telegram       : @Wilykun1994
 * ═══════════════════════════════════════════════════════════════
 *  Script ini GRATIS, tidak untuk diperjualbelikan!
 *  Jika ketahuan menjual script ini = NO UPDATE / NO FIX
 *  Hargai kerja keras developer, gunakan dengan bijak!
 * ═══════════════════════════════════════════════════════════════
 */

'use strict';

import fs from 'fs';
import path from 'path';
import os from 'os';
import { createRequire } from 'module';
const _require = createRequire(import.meta.url);
const { isJidGroup, downloadMediaMessage, getContentType, generateWAMessageFromContent, generateWAMessageContent, prepareWAMessageMedia, proto } = _require('socketon');
import crypto from 'crypto';
import { exec } from 'child_process';
import util from 'util';

import { msToTime, loadConfig, saveConfig } from '../helper/utils.js';
import { stopAutoCleaner, restartAutoCleaner, cleanStaleSessionFiles, clearOldFiles } from '../helper/cleaner.js';
import { getUptimeFormatted, getBotStats } from '../db/botStats.js';
import { logError, formatErrorReport, clearErrors, generateErrorFileTxt, getInfoErrorTxtPath } from '../db/errorLog.js';
import { startJadibot, startJadibotQR, stopJadibot, jadibotMap, pendingJadibotChoices, formatPairingCode, maskNumber } from '../helper/jadibot.js';
import { hasViewOnceCache, getViewOnceCache } from '../helper/voCache.js';
import { isAntiTagSWEnabled, toggleAntiTagSW, resetWarnings, getWarnings } from './antitagsw.js';
// yg bawah pindah ke sini
import { injectMessage } from '../helper/inject.js';
import { tolak, buildReplyContext } from '../helper/reply.js';
import listenEvent from './event.js';
import gemini from '../helper/gemini.js';
import { updateUserName, getUserName } from '../db/userDb.js';
import { searchAndGetImage, searchAndGetImages } from '../helper/imageSearch.js';
import { getHistory, addToHistory, clearHistory, clearAllHistory, countHistory, getSessionKey } from '../db/aiHistory.js';
import { sendAIReply, buildReactPromptRules, buildPersonalityBoost } from '../helper/aiReact.js';

function isMainBot(hisoka) {
    return hisoka?.isMainBot === true;
}

function detectImageSearchQuery(text) {
    if (!text) return null;
    const t = text.trim();

    // Jika teks mengandung tanda tanya atau terlihat seperti pertanyaan, jangan cari gambar
    const questionIndicators = /\?|apakah|kenapa|mengapa|bagaimana|gimana|apa itu|siapa|kapan|berapa|benarkah|iya ga|iya gak|beneran|emang|bisa gak|bisa ga|itu apa|apa yang|gimana cara/i;
    if (questionIndicators.test(t)) return null;

    // Prefix umum di awal kalimat sebelum kata kunci
    const prefixPattern = /^(?:boleh\s+|bisa\s+|tolong\s+|dong\s+|coba\s+|mau\s+|aku\s+mau\s+|aku\s+minta\s+|saya\s+minta\s+|please\s+|pls\s+)?/i;

    const patterns = [
        // "cariin/cari/carikan gambar/foto X"
        /^(?:boleh\s+|bisa\s+|tolong\s+|dong\s+|coba\s+|mau\s+)?cari(?:kan|in|i)?\s+(?:gambar|foto|image|pic|picture)\s+(?:dari\s+|tentang\s+)?(.+)/i,
        // "kirimin/kirimkan gambar/foto X"
        /^(?:boleh\s+|bisa\s+|tolong\s+)?kirim(?:in|kan)?\s+(?:aku\s+|saya\s+)?(?:gambar|foto|image)\s+(?:dari\s+|tentang\s+)?(.+)/i,
        // "boleh/bisa minta gambar X" / "minta gambar X" / "pengen gambar X" / "request gambar X"
        /^(?:boleh\s+|bisa\s+)?(?:minta|pengen|pengin|ingin|mau|request|order)\s+(?:\d+\s+)?(?:gambar|foto|image)\s+(?:anime\s+|manga\s+)?(.+)/i,
        // "minta X gambar/foto" (urutan terbalik)
        /^(?:boleh\s+|bisa\s+)?(?:minta|pengen|pengin)\s+(.+?)\s+(?:\d+\s+)?(?:gambar|foto|image)(?:\s+dong|\s+ya|\s+yuk)?$/i,
        // "gambar X dong/ya" / "foto X dong" — di awal kalimat
        /^(?:gambar|foto)\s+(.{2,50})(?:\s+dong|\s+ya|\s+yuk|\s+aja|\s+saja)?$/i,
        // "kirim gambar X" — singkat
        /^kirim\s+(?:gambar|foto)\s+(.+)/i,
        // "find/search image of X" — bahasa Inggris
        /^(?:find|search|get|send)\s+(?:\d+\s+)?(?:image|picture|photo)s?\s+(?:of\s+)?(.+)/i,
        // "show me X picture/image"
        /^show\s+me\s+(?:\d+\s+)?(?:images?|pictures?|photos?)\s+(?:of\s+)?(.+)/i,
    ];

    for (const pat of patterns) {
        const match = t.match(pat);
        if (match && match[1]) {
            // Bersihkan trailing: angka + kata seperti "2 saja", "3 aja", "dong", "ya", dll
            let q = match[1].trim()
                .replace(/\s+\d+\s+(?:saja|aja|doang|dulu|deh|aja)$/i, '')
                .replace(/\s+(?:saja|aja|doang|dulu|deh|dong|ya|yuk)$/i, '')
                .replace(/[?.!,]+$/, '')
                .trim();
            // Query harus pendek dan spesifik
            if (q.length >= 2 && q.length <= 80 && !questionIndicators.test(q)) return q;
        }
    }
    return null;
}

// Ekstrak jumlah gambar dari teks user (misal: "2 saja", "3 foto", "beberapa")
function extractImageCount(text) {
    if (!text) return 1;
    const t = text.toLowerCase();
    const numMatch = t.match(/\b(\d+)\s*(?:gambar|foto|image|saja|aja|buah|lembar)?\b/);
    if (numMatch) {
        const n = parseInt(numMatch[1]);
        if (n >= 1 && n <= 5) return n;
    }
    if (/\b(beberapa|beberapa|few|some|multiple)\b/.test(t)) return 3;
    return 1;
}

const pendingPlayChoices = new Map();

function buildWilySystemPrompt({ userName, currentTime, currentDate, timeOfDay, hasHistory = false, quotedBotText = '', chatContext = '' }) {
    const historyNote = hasHistory
        ? `\n⚡ PERINGATAN KONTEKS: Kamu SEDANG MELANJUTKAN percakapan dengan ${userName}. History percakapan ada di atas. WAJIB gunakan informasi dari history untuk menjawab. Jika user menyebut "itu", "tadi", "gambar tadi", "manhwa itu", "yang kamu bilang", dll — SELALU rujuk ke history, JANGAN jawab seolah percakapan baru.`
        : '';
    const quotedNote = quotedBotText
        ? `\n💬 KONTEKS REPLY: User sedang membalas pesan kamu:\n"${quotedBotText.substring(0, 400)}"\n→ Jawab LANGSUNG sesuai isi pesan di atas. Jangan abaikan konteksnya.`
        : '';
    const chatCtxNote = chatContext ? `\n${chatContext}` : '';

    return `Kamu adalah Wily Bot — AI cerdas, jujur, dan serbaguna buatan Bang Wilykun. Kamu berjalan di WhatsApp sebagai asisten pribadi yang pintar, santai, dan to-the-point.

━━━ IDENTITAS ━━━
Nama      : Wily Bot
Creator   : Bang Wilykun (WA: 6289688206739)
Model     : Gemini Vision (multimodal — bisa baca teks, gambar, video, dokumen)
Karakter  : Cerdas, santai, jujur, tidak munafik, tidak menghakimi
Platform  : WhatsApp Bot

━━━ KONTEKS WAKTU (GUNAKAN INI, JANGAN ASAL!) ━━━
Waktu WIB : ${currentTime} (${timeOfDay})
Tanggal   : ${currentDate}
User      : ${userName}

⚠️ PENTING soal SAPAAN WAKTU:
- JANGAN mulai setiap balasan dengan sapaan waktu ("Malam", "Pagi", "Sore", dll) secara otomatis
- Gunakan sapaan waktu HANYA JIKA: user menyapa duluan (contoh: "Selamat malam", "Halo pagi"), atau ini adalah pembuka percakapan yang sangat baru
- Kalau sudah mid-conversation atau user langsung tanya sesuatu → langsung jawab tanpa sapaan waktu basa-basi
- Jika HARUS menyebut waktu (karena relevan), WAJIB pakai "${timeOfDay}" sesuai jam ${currentTime} WIB — JANGAN pakai yang lain
${historyNote}${quotedNote}${chatCtxNote}

━━━ KEMAMPUAN UTAMA ━━━

1. ANALISIS GAMBAR, VIDEO & VISUAL
   - Ekstrak SEMUA teks: dialog, subtitle, caption, watermark, teks kecil
   - Identifikasi judul: manhwa/manga/anime/webtoon/film/series dari cover, poster, screenshot
   - Kenali karakter: nama, asal franchise, sifat — jelaskan detail
   - Kenali ORANG NYATA dari foto: nama artis/public figure, profesi, negara. Jika tidak 100% yakin → sebutkan "kemungkinan [nama]" berdasarkan ciri fisik, pakaian, latar. JANGAN bilang "saya tidak bisa mengenali orang"
   - Analisis video: deskripsikan adegan, lokasi, orang/karakter, teks, konteks
   - Rating konten: umum / teen (13+) / dewasa (18+/NSFW) / explicit — jawab JUJUR
   - Baca meme, infografis, tabel, dokumen scan, kode QR dalam gambar

2. PENGETAHUAN LUAS
   - Anime, manga, manhwa, webtoon, light novel — karakter, sinopsis, chapter, arc cerita
   - Game — gameplay, lore, karakter, tips
   - Film & series — plot, episode, review
   - NSFW/dewasa — genre, judul, karakter; jawab faktual tanpa sensor hipokrit
   - Sains, teknologi, sejarah, budaya pop, musik, olahraga, kuliner, keuangan, hukum umum
   - Coding — debug, jelaskan kode, buatkan fungsi sesuai bahasa
   - Terjemahan — Indonesia, Inggris, Jepang, Korea, dll

3. PERCAKAPAN NATURAL
   - Ngobrol santai, curhat, bercanda — respon hangat dan manusiawi
   - Roleplay ringan sesuai permintaan
   - Brainstorming, nulis teks, caption, lirik, puisi, cerita
   - Topik sensitif (seks, mental health, hubungan) — jawab bijak tanpa menghakimi

━━━ ATURAN WAJIB SAAT MENJAWAB ━━━

1. NYAMBUNG — jawab sesuai konteks, bukan ngawur
2. HISTORY FIRST — jika ada history, WAJIB pakai; jangan jawab seolah percakapan baru
3. GAMBAR DULU — jika ada gambar/video/dokumen, analisis sebelum jawab
4. JUJUR — akui jika tidak tahu; jangan pura-pura tahu
5. BAHASA INDONESIA santai — boleh "dong", "sih", "nih", "wkwk", "hehe", "lho", "deh"
6. EMOJI KONTEKSTUAL — pakai 1-3 emoji yang benar-benar cocok dengan isi/topik pesan:
   - Coding/teknis → 💻 🔧 ⚙️ 🛠️
   - Anime/manga/webtoon → 🎌 📖 🎭 ✨
   - Gambar/visual/foto → 🖼️ 👀 🔍 📸
   - Bercanda/santai/lucu → 😄 😂 🤣 😜
   - Serius/informatif/fakta → ℹ️ 📌 ✅ 📊
   - Curhat/emosional → 💙 🤗 😊 💭
   - Makanan/kuliner → 🍜 🍕 😋
   - Game → 🎮 🕹️ ⚔️
   - Download/media → 📥 🎵 🎬
   - NSFW/dewasa → 🔞 (jika relevan, tidak berlebihan)
   JANGAN taruh emoji waktu/salam (🌙🌅☀️) di setiap balasan secara acak. Emoji harus NYAMBUNG dengan isi pesan!
7. RINGKAS & BERISI — tidak terlalu panjang kecuali perlu detail
8. FORMAT WhatsApp — *tebal*, _miring_, ~coret~. JANGAN pakai # ## atau ** atau markdown non-WA
9. TIDAK MENGHAKIMI — user bebas tanya apapun, jawab objektif dan netral
10. WAKTU AKURAT — WAJIB gunakan waktu/tanggal dari konteks di atas. JANGAN bilang waktu yang salah!
${buildReactPromptRules()}

━━━ KONTEN SENSITIF ━━━
- NSFW (manhwa 18+, hentai, dll): identifikasi faktual, sebutkan judul/genre jika dikenali — tidak perlu disensor selama user nanya secara informatif
- Pertanyaan seksual: jawab edukatif dan informatif
- Kontroversial: perspektif berimbang
- Topik ilegal: beri info umum/edukasi + ingatkan risiko hukum

━━━ PANDUAN JAWABAN SPESIFIK ━━━
→ "Itu manhwa 18+?" → cek visual: ada adegan eksplisit? → ya/tidak + genre singkat
→ "Judul ini apa?" → identifikasi dari gaya gambar, karakter, teks di gambar
→ "Chapter/episode berapa?" → lihat nomor/teks di gambar atau perkirakan dari cerita
→ "Terjemahin" → terjemahkan SEMUA teks dalam gambar dengan akurat
→ "Karakter ini siapa?" → nama, franchise, info singkat karakter
→ "Ini siapa?" / "Dia siapa?" (foto orang) → WAJIB identifikasi: sebut nama jika dikenali, atau "kemungkinan [nama]" berdasarkan ciri fisik/pakaian/latar. JANGAN tolak dengan "saya tidak bisa mengenali orang"
→ "Isi video ini?" → deskripsikan adegan, karakter, teks, konteks secara detail
→ "Rangkum/baca PDF/dokumen ini" → baca dan rangkum isi yang sudah diberikan di konteks
→ Reply pesan orang → jawab berdasarkan isi pesan yang di-reply, sebut nama pengirim jika relevan
→ Sapaan waktu → HANYA pakai "${timeOfDay}" JIKA user menyapa duluan atau konteks memang butuh. Jangan taruh sapaan waktu otomatis di setiap balasan!
→ Pertanyaan langsung (tanpa salam) → langsung jawab, tidak perlu basa-basi sapaan waktu dulu
${buildPersonalityBoost(userName)}`;
}

function parseYtdlpError(stderr, fallback) {
    if (!stderr) return fallback || 'Unknown error';
    const errorLine = stderr.split('\n').find(l => l.trim().startsWith('ERROR:'));
    if (errorLine) {
        return errorLine.replace(/^ERROR:\s*/, '').replace(/^\[youtube\]\s*[^:]+:\s*/, '').trim();
    }
    return fallback || stderr.substring(0, 150);
}

async function ensureYtdlp(hisoka, m) {
    const binDir = path.join(process.cwd(), 'bin');
    const ytdlpBin = path.join(binDir, 'yt-dlp');

    if (!fs.existsSync(binDir)) {
        fs.mkdirSync(binDir, { recursive: true });
    }

    if (fs.existsSync(ytdlpBin)) return ytdlpBin;

    console.log('\x1b[33m[YT-DLP] Binary tidak ditemukan, mengunduh otomatis...\x1b[39m');

    if (hisoka && m) {
        await hisoka.sendMessage(m.from, { react: { text: '⬇️', key: m.key } });
        await tolak(hisoka, m, '⬇️ *Mohon tunggu sebentar...*\n\nSistem sedang mempersiapkan downloader YouTube. Proses ini hanya terjadi sekali dan tidak akan terulang lagi. Permintaanmu akan otomatis dilanjutkan setelah siap. ⏳');
    }

    const downloadUrl = 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_linux';

    await new Promise((resolve, reject) => {
        exec(`curl -L "${downloadUrl}" -o "${ytdlpBin}"`, { timeout: 120000 }, (err) => {
            if (err) return reject(new Error('Gagal mengunduh yt-dlp: ' + err.message));
            resolve();
        });
    });

    fs.chmodSync(ytdlpBin, 0o755);
    console.log('\x1b[32m[YT-DLP] ✓ Binary berhasil diunduh dan siap digunakan.\x1b[39m');

    if (hisoka && m) {
        await tolak(hisoka, m, '✅ *Downloader siap!* Sedang memproses permintaanmu...');
    }

    return ytdlpBin;
}

function getSenderNumber(m) {
    if (m.key?.participant) return m.key.participant.split('@')[0];
    if (m.key?.remoteJid) return m.key.remoteJid.split('@')[0];
    return null;
}

function isAllowedForJadibot(m, hisoka) {
    if (m.key?.fromMe) return true;

    const senderNumber = getSenderNumber(m);
    if (!senderNumber) return false;

    if (senderNumber === hisoka.mainBotNumber) return true;

    const botNumber = hisoka.user?.id?.split(':')[0]?.split('@')[0];
    if (senderNumber === botNumber) return true;

    return false;
}

class Button {
    constructor() {
        this._title = '';
        this._subtitle = '';
        this._body = '';
        this._footer = '';
        this._beton = [];
        this._data = undefined;
        this._contextInfo = {};
        this._currentSelectionIndex = -1;
        this._currentSectionIndex = -1;
        this._type = 0;
        this._betonOld = [];
        this._params = {};
    }
    setVideo(path, options = {}) {
        Buffer.isBuffer(path) ? this._data = { video: path, ...options } : this._data = { video: { url: path }, ...options };
        return this;
    }
    setImage(path, options = {}) {
        Buffer.isBuffer(path) ? this._data = { image: path, ...options } : this._data = { image: { url: path }, ...options };
        return this;
    }
    setDocument(path, options = {}) {
        Buffer.isBuffer(path) ? this._data = { document: path, ...options } : this._data = { document: { url: path }, ...options };
        return this;
    }
    setMedia(obj) {
        if (typeof obj === 'object' && !Array.isArray(obj)) { this._data = obj; } else { return 'Type of media must be an Object'; }
        return this;
    }
    setTitle(title) { this._title = title; return this; }
    setSubtitle(subtitle) { this._subtitle = subtitle; return this; }
    setBody(body) { this._body = body; return this; }
    setFooter(footer) { this._footer = footer; return this; }
    setContextInfo(obj) {
        if (typeof obj === 'object' && !Array.isArray(obj)) { this._contextInfo = obj; } else { return 'Type of contextInfo must be an Object'; }
        return this;
    }
    setParams(obj) {
        if (typeof obj === 'object' && !Array.isArray(obj)) { this._params = obj; } else { return 'Type of params must be an Object'; }
        return this;
    }
    setButton(name, params) { this._beton.push({ name, buttonParamsJson: JSON.stringify(params) }); return this; }
    setButtonV2(params) { this._betonOld.push(params); return this; }
    makeRow(header = '', title = '', description = '', id = '') {
        if (this._currentSelectionIndex === -1 || this._currentSectionIndex === -1) throw new Error('You need to create a selection and a section first');
        const buttonParams = JSON.parse(this._beton[this._currentSelectionIndex].buttonParamsJson);
        buttonParams.sections[this._currentSectionIndex].rows.push({ header, title, description, id });
        this._beton[this._currentSelectionIndex].buttonParamsJson = JSON.stringify(buttonParams);
        return this;
    }
    makeSections(title = '', highlight_label = '') {
        if (this._currentSelectionIndex === -1) throw new Error('You need to create a selection first');
        const buttonParams = JSON.parse(this._beton[this._currentSelectionIndex].buttonParamsJson);
        buttonParams.sections.push({ title, highlight_label, rows: [] });
        this._currentSectionIndex = buttonParams.sections.length - 1;
        this._beton[this._currentSelectionIndex].buttonParamsJson = JSON.stringify(buttonParams);
        return this;
    }
    addSelection(title) {
        this._beton.push({ name: 'single_select', buttonParamsJson: JSON.stringify({ title, sections: [] }) });
        this._currentSelectionIndex = this._beton.length - 1;
        this._currentSectionIndex = -1;
        return this;
    }
    addReply(display_text = '', id = '') { this._beton.push({ name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text, id }) }); return this; }
    addReplyV2(displayText = 'Nixel', buttonId = 'Nixel') { this._betonOld.push({ buttonId, buttonText: { displayText }, type: 1 }); this._type = 1; return this; }
    addCall(display_text = '', id = '') { this._beton.push({ name: 'cta_call', buttonParamsJson: JSON.stringify({ display_text, id }) }); return this; }
    addUrl(display_text = '', url = '', merchant_url = '') { this._beton.push({ name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text, url, merchant_url }) }); return this; }
    addCopy(display_text = '', copy_code = '', id = '') { this._beton.push({ name: 'cta_copy', buttonParamsJson: JSON.stringify({ display_text, copy_code, id }) }); return this; }
    async run(jid, conn, quoted = '') {
        if (this._type === 0) {
            const message = {
                body: { text: this._body },
                footer: { text: this._footer },
                header: {
                    title: this._title,
                    subtitle: this._subtitle,
                    hasMediaAttachment: !!this._data,
                    ...(this._data ? await prepareWAMessageMedia(this._data, { upload: conn.waUploadToServer }) : {})
                }
            };
            const msg = generateWAMessageFromContent(jid, {
                interactiveMessage: {
                    ...message,
                    contextInfo: this._contextInfo,
                    nativeFlowMessage: {
                        messageParamsJson: JSON.stringify(this._params),
                        buttons: this._beton
                    }
                }
            }, { quoted });
            await conn.relayMessage(msg.key.remoteJid, msg.message, {
                messageId: msg.key.id,
                additionalNodes: [{
                    tag: 'biz',
                    attrs: {},
                    content: [{
                        tag: 'interactive',
                        attrs: { type: 'native_flow', v: '1' },
                        content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }]
                    }]
                }]
            });
            return msg;
        } else {
            return await conn.sendMessage(jid, {
                ...(this._data ? this._data : {}),
                [this._data ? 'caption' : 'text']: this._body,
                title: (!!this._data ? null : this._title),
                footer: this._footer,
                viewOnce: true,
                contextInfo: this._contextInfo,
                buttons: [
                    ...this._betonOld,
                    ...this._beton.map(b => ({
                        buttonId: 'id',
                        buttonText: { displayText: 'btn' },
                        type: 1,
                        nativeFlowInfo: { name: b.name, paramsJson: b.buttonParamsJson }
                    }))
                ]
            }, { quoted });
        }
    }
}

async function listbut2(jid, teks, listnye, m, hisoka) {
    const cfg = loadConfig();
    const botReply      = cfg.botReply || {};
    const thumbnailUrl  = botReply.thumbnailUrl  || '';
    const botName       = botReply.botName       || 'Wily Bot';
    const newsletterJid = botReply.newsletterJid || '';
    const newsletterName= botReply.newsletterName|| '';

    const headerMedia = thumbnailUrl
        ? await prepareWAMessageMedia({ image: { url: thumbnailUrl } }, { upload: hisoka.waUploadToServer })
        : {};

    const msg = generateWAMessageFromContent(jid, {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    contextInfo: {
                        mentionedJid: [m.sender],
                        forwardingScore: 999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid,
                            newsletterName,
                            serverMessageId: Math.floor(Math.random() * 9999) + 1
                        }
                    },
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: teks
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: `✨ Powered By ${botName}`
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        title: ``,
                        subtitle: ``,
                        gifPlayback: true,
                        hasMediaAttachment: !!thumbnailUrl,
                        ...headerMedia
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                            {
                                name: 'single_select',
                                buttonParamsJson: JSON.stringify(listnye)
                            }
                        ]
                    })
                })
            }
        }
    }, { quoted: m });

    await hisoka.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id
    });
}

function logCommand(m, hisoka, command) {
        if (process.env.BOT_LOG_MESSAGE !== 'true') return;
        const location = m.isGroup ? `"${hisoka.getName(m.from)}"` : 'Private Chat';
        console.log(`\x1b[32m[CMD]\x1b[39m \x1b[36m.${command}\x1b[39m - ${m.pushName} @ ${location}`);
}

// ── ZIP FILE PARSER (pure Node.js, no external lib) ──
function parseZipBuffer(buffer) {
    const result = { files: [], isPasswordProtected: false, error: null };
    try {
        const LOCAL_FILE_HEADER_SIG = 0x04034b50;
        const CENTRAL_DIR_SIG = 0x02014b50;
        const EOCD_SIG = 0x06054b50;

        let eocdOffset = -1;
        for (let i = buffer.length - 22; i >= 0; i--) {
            if (buffer.readUInt32LE(i) === EOCD_SIG) {
                eocdOffset = i;
                break;
            }
        }
        if (eocdOffset === -1) {
            result.error = 'Bukan file ZIP yang valid';
            return result;
        }

        const centralDirSize = buffer.readUInt32LE(eocdOffset + 12);
        const centralDirOffset = buffer.readUInt32LE(eocdOffset + 16);

        let pos = centralDirOffset;
        while (pos < centralDirOffset + centralDirSize && pos + 46 <= buffer.length) {
            if (buffer.readUInt32LE(pos) !== CENTRAL_DIR_SIG) break;
            const generalFlag = buffer.readUInt16LE(pos + 8);
            const isEncrypted = (generalFlag & 0x01) !== 0;
            if (isEncrypted) result.isPasswordProtected = true;
            const compressedSize = buffer.readUInt32LE(pos + 20);
            const uncompressedSize = buffer.readUInt32LE(pos + 24);
            const fileNameLen = buffer.readUInt16LE(pos + 28);
            const extraFieldLen = buffer.readUInt16LE(pos + 30);
            const commentLen = buffer.readUInt16LE(pos + 32);
            const fileName = buffer.slice(pos + 46, pos + 46 + fileNameLen).toString('utf8');
            const isDir = fileName.endsWith('/');
            if (!isDir) {
                const sizeKb = uncompressedSize > 0 ? (uncompressedSize / 1024).toFixed(1) : (compressedSize / 1024).toFixed(1);
                result.files.push({ name: fileName, size: parseFloat(sizeKb), encrypted: isEncrypted });
            }
            pos += 46 + fileNameLen + extraFieldLen + commentLen;
        }
    } catch (e) {
        result.error = 'Gagal parse ZIP: ' + e.message;
    }
    return result;
}

// ── PDF TEXT EXTRACTOR via pdftotext ──
async function extractPdfText(pdfBuffer) {
    const execAsync = util.promisify(exec);
    const tmpFile = `/tmp/wily_pdf_${Date.now()}.pdf`;
    try {
        fs.writeFileSync(tmpFile, pdfBuffer);
        const { stdout } = await execAsync(`pdftotext "${tmpFile}" -`, { timeout: 15000 });
        return stdout.trim().substring(0, 4000);
    } catch (e) {
        throw new Error('Gagal baca PDF: ' + e.message);
    } finally {
        try { fs.unlinkSync(tmpFile); } catch (_) {}
    }
}

function extractMediaFromMessage(quotedMsg) {
        let targetMessage = quotedMsg;
        let foundViewOnce = false;

        if (quotedMsg.ephemeralMessage?.message) {
                targetMessage = quotedMsg.ephemeralMessage.message;
        }

        if (targetMessage.viewOnceMessage?.message) {
                targetMessage = targetMessage.viewOnceMessage.message;
                foundViewOnce = true;
        }

        if (targetMessage.viewOnceMessageV2?.message) {
                targetMessage = targetMessage.viewOnceMessageV2.message;
                foundViewOnce = true;
        }

        if (targetMessage.viewOnceMessageV2Extension?.message) {
                targetMessage = targetMessage.viewOnceMessageV2Extension.message;
                foundViewOnce = true;
        }

        const mediaTypes = [
                'imageMessage',
                'videoMessage',
                'audioMessage',
                'documentMessage',
                'stickerMessage'
        ];

        for (const mediaType of mediaTypes) {
                if (targetMessage[mediaType]) {
                        return {
                                mediaMessage: targetMessage[mediaType],
                                mediaType: mediaType,
                                isViewOnce: foundViewOnce || 
                                        targetMessage[mediaType].viewOnce === true ||
                                        quotedMsg.viewOnceMessage ||
                                        quotedMsg.viewOnceMessageV2 ||
                                        quotedMsg.viewOnceMessageV2Extension
                        };
                }
        }

        return null;
}

function isViewOnceMessage(quotedMsg) {
        if (quotedMsg.viewOnceMessage) return true;
        if (quotedMsg.viewOnceMessageV2) return true;
        if (quotedMsg.viewOnceMessageV2Extension) return true;

        if (quotedMsg.ephemeralMessage?.message) {
                const ephemeralContent = quotedMsg.ephemeralMessage.message;
                if (ephemeralContent.viewOnceMessage) return true;
                if (ephemeralContent.viewOnceMessageV2) return true;
                if (ephemeralContent.viewOnceMessageV2Extension) return true;

                const mediaTypes = ['imageMessage', 'videoMessage', 'audioMessage', 'documentMessage', 'stickerMessage'];
                for (const type of mediaTypes) {
                        if (ephemeralContent[type]?.viewOnce) return true;
                }
        }

        const mediaTypes = ['imageMessage', 'videoMessage', 'audioMessage', 'documentMessage', 'stickerMessage'];
        for (const type of mediaTypes) {
                if (quotedMsg[type]?.viewOnce) return true;
        }

        return false;
}

export default async function ({ message, type: messagesType }, hisoka) {
        let m;
        try {
                m = await injectMessage(hisoka, message);

                if (!m || !m.message) return;

                await listenEvent(m, hisoka);

                const quoted = m.isMedia ? m : m.isQuoted ? m.quoted : m;
                const text = m.text;
                const query = m.query || quoted.query;

                if (!m.key) return;

                // Simpan nama user ke DB per-user
                if (m.sender && m.pushName) {
                        updateUserName(m.sender, m.pushName);
                }
                // Blokir pesan auto-bot kecuali ada command (prefix maupun tanpa prefix)
                if (m.isBot && !m.command) return;
                // Blokir pesan dari device lain (sinkronisasi) kecuali ada command
                if (messagesType === 'append' && !m.command) return;

                // AutoSimi (Gemini AI - tanpa API key, vision support)
                if (!m.text?.startsWith('.')) {
                        try {
                                const config = loadConfig();
                                const autoSimi = config.autoSimi || {};

                                if (autoSimi.enabled) {
                                        const botId = hisoka.user?.id || '';
                                        const botNumber = botId.split(':')[0] || botId.split('@')[0];
                                        const botJid = botNumber + '@s.whatsapp.net';
                                        const botLid = hisoka.user?.lid || '';

                                        const mentionedJids = m.mentions ||
                                                m.message?.extendedTextMessage?.contextInfo?.mentionedJid ||
                                                m.message?.imageMessage?.contextInfo?.mentionedJid ||
                                                m.message?.videoMessage?.contextInfo?.mentionedJid ||
                                                m.message?.stickerMessage?.contextInfo?.mentionedJid ||
                                                m.content?.contextInfo?.mentionedJid ||
                                                [];

                                        const isBotMentioned = mentionedJids.some(jid => {
                                                if (!jid) return false;
                                                const jidNumber = jid.split(':')[0]?.split('@')[0] || jid.split('@')[0];
                                                return jid === botJid ||
                                                        jid === botId ||
                                                        jid === botLid ||
                                                        jid?.includes(botNumber) ||
                                                        jidNumber === botNumber;
                                        }) || m.text?.includes('@' + botNumber);

                                        const isReplyToBot = m.isQuoted && m.quoted?.key?.fromMe;

                                        if (isBotMentioned || isReplyToBot) {
                                                let userMessage = m.text?.trim() || '';
                                                if (userMessage) {
                                                        userMessage = userMessage.replace(/@\d+/g, '').replace(/@bot/gi, '').trim();
                                                }

                                                // Deteksi media di pesan saat ini atau di pesan yang di-reply
                                                let imageBuffer = null;
                                                let imageMime = 'image/jpeg';
                                                let hasMedia = false;
                                                let mediaLabel = '';

                                                const currentType = m.type || '';
                                                const quotedType = m.isQuoted ? (m.quoted?.type || '') : '';

                                                // Coba ambil gambar/sticker dari pesan saat ini
                                                if (currentType === 'imageMessage' || currentType === 'stickerMessage') {
                                                        try {
                                                                imageBuffer = await m.downloadMedia();
                                                                imageMime = currentType === 'stickerMessage' ? 'image/webp' : 'image/jpeg';
                                                                hasMedia = true;
                                                                mediaLabel = currentType === 'stickerMessage' ? 'sticker' : 'gambar';
                                                        } catch (_) {}
                                                }

                                                // Kalau tidak ada di pesan saat ini, coba dari pesan yang di-reply
                                                if (!imageBuffer && m.isQuoted) {
                                                        const qt = quotedType;
                                                        if (qt === 'imageMessage' || qt === 'stickerMessage') {
                                                                try {
                                                                        imageBuffer = await downloadMediaMessage(
                                                                                { ...m.quoted, message: m.quoted.raw },
                                                                                'buffer',
                                                                                {},
                                                                                { logger: hisoka.logger, reuploadRequest: hisoka.updateMediaMessage }
                                                                        );
                                                                        imageMime = qt === 'stickerMessage' ? 'image/webp' : 'image/jpeg';
                                                                        hasMedia = true;
                                                                        mediaLabel = qt === 'stickerMessage' ? 'sticker' : 'gambar';
                                                                } catch (_) {}
                                                        }
                                                }

                                                // Kalau tidak ada teks dan tidak ada gambar, kasih pesan default
                                                if (!userMessage && !hasMedia) {
                                                        if (currentType.includes('video')) userMessage = 'Pengguna mengirim video';
                                                        else if (currentType.includes('audio')) userMessage = 'Pengguna mengirim voice note';
                                                        else if (currentType.includes('document')) userMessage = 'Pengguna mengirim dokumen';
                                                        else userMessage = 'Halo!';
                                                }

                                                if (!userMessage && hasMedia) {
                                                        userMessage = `Tolong analisis ${mediaLabel} ini secara lengkap dan akurat.`;
                                                }

                                                // ── DETEKSI PERMINTAAN CARI GAMBAR di AutoSimi ──
                                                if (userMessage && !hasMedia) {
                                                        const autoImgQuery = detectImageSearchQuery(userMessage);
                                                        if (autoImgQuery) {
                                                                try {
                                                                        await tolak(hisoka, m, `🔍 Oke ${getUserName(m.sender, m.pushName || 'Kak')}, aku cariin gambar *${autoImgQuery}*...`);
                                                                        const imgResult = await searchAndGetImage(autoImgQuery);
                                                                        await hisoka.sendMessage(m.from, {
                                                                                image: imgResult.buffer,
                                                                                caption: `🖼️ *${imgResult.title || autoImgQuery}*\n🔗 ${imgResult.url}`
                                                                        }, { quoted: m });
                                                                        console.log(`\x1b[36m[AutoGemini]\x1b[39m Image search: "${autoImgQuery}" by ${m.pushName}`);
                                                                } catch (se) {
                                                                        console.error(`\x1b[31m[AutoGemini]\x1b[39m Image search error: ${se.message}`);
                                                                        await tolak(hisoka, m, `❌ Maaf, gagal nyariin gambar "${autoImgQuery}". Coba lagi nanti ya!`);
                                                                }
                                                                return;
                                                        }
                                                }

                                                const now = new Date();
                                                const hours = parseInt(now.toLocaleString('en-US', { hour: 'numeric', hour12: false, timeZone: 'Asia/Jakarta' }));
                                                const timeOfDay = hours < 5 ? 'dini hari' : hours < 11 ? 'pagi' : hours < 15 ? 'siang' : hours < 18 ? 'sore' : 'malam';
                                                const currentTime = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Jakarta' });
                                                const currentDate = now.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Asia/Jakarta' });

                                                const userName = getUserName(m.sender, m.pushName || 'Kak');

                                                const quotedBotText = isReplyToBot ? (m.quoted?.text || '') : '';
                                                const systemPrompt = buildWilySystemPrompt({
                                                        userName, currentTime, currentDate, timeOfDay,
                                                        hasHistory: false,
                                                        quotedBotText,
                                                });

                                                let response;
                                                const fullPrompt = systemPrompt + '\n\n' + userMessage;

                                                if (imageBuffer && imageBuffer.length > 0) {
                                                        // Konversi webp (sticker) ke jpeg agar Gemini bisa baca
                                                        let finalBuffer = imageBuffer;
                                                        let finalMime = imageMime;
                                                        if (imageMime === 'image/webp') {
                                                                try {
                                                                        const sharp = (await import('sharp')).default;
                                                                        finalBuffer = await sharp(imageBuffer).jpeg({ quality: 90 }).toBuffer();
                                                                        finalMime = 'image/jpeg';
                                                                } catch (_) {}
                                                        }
                                                        response = await gemini.askWithImage(fullPrompt, finalBuffer, finalMime);
                                                } else {
                                                        response = await gemini.ask(fullPrompt);
                                                }

                                                if (response && response.trim()) {
                                                        await sendAIReply(hisoka, m, response.trim());
                                                        console.log(`\x1b[36m[AutoGemini]\x1b[39m Reply to ${userName} (${m.pushName}) in "${m.isGroup ? hisoka.getName(m.from) : 'DM'}" | Trigger: ${isBotMentioned ? 'mention' : 'reply'} | Media: ${hasMedia ? mediaLabel : 'none'}`);
                                                }
                                        }
                                }

                                // ── WILY AUTO REPLY (tanpa autoSimi) ──
                                // Kalau autoSimi mati tapi wilyAI.autoReply aktif,
                                // bot tetap reply otomatis saat seseorang reply pesan bot
                                if (!autoSimi.enabled) {
                                        const wilyAICfg = config.wilyAI || {};
                                        const isWilyOn = wilyAICfg.enabled !== false;
                                        const isAutoReplyOn = wilyAICfg.autoReply !== false;
                                        const isReplyToBotMsg = m.isQuoted && m.quoted?.key?.fromMe;

                                        // WilyAutoReply hanya untuk GRUP — private sepenuhnya dihandle WilyPrivate
                                        if (isWilyOn && isAutoReplyOn && isReplyToBotMsg && m.isGroup) {
                                                const userName = getUserName(m.sender, m.pushName || 'Kak');
                                                const now = new Date();
                                                const hours = parseInt(now.toLocaleString('en-US', { hour: 'numeric', hour12: false, timeZone: 'Asia/Jakarta' }));
                                                const timeOfDay = hours < 5 ? 'dini hari' : hours < 11 ? 'pagi' : hours < 15 ? 'siang' : hours < 18 ? 'sore' : 'malam';
                                                const currentTime = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Jakarta' });
                                                const currentDate = now.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Asia/Jakarta' });

                                                let userMessage = m.text?.trim() || '';

                                                // Deteksi media dari pesan saat ini atau pesan yang di-reply
                                                let imageBuffer = null;
                                                let imageMime = 'image/jpeg';
                                                let hasMedia = false;
                                                let mediaLabel = '';
                                                const curType = m.type || '';
                                                const qtType = m.isQuoted ? (m.quoted?.type || '') : '';

                                                if ((curType === 'imageMessage' || curType === 'stickerMessage') && m.isMedia) {
                                                        try {
                                                                imageBuffer = await m.downloadMedia();
                                                                if (imageBuffer?.length > 0) {
                                                                        imageMime = curType === 'stickerMessage' ? 'image/webp' : 'image/jpeg';
                                                                        hasMedia = true;
                                                                        mediaLabel = curType === 'stickerMessage' ? 'sticker' : 'gambar';
                                                                }
                                                        } catch (_) {}
                                                } else if (m.isQuoted && (qtType === 'imageMessage' || qtType === 'stickerMessage')) {
                                                        try {
                                                                imageBuffer = await downloadMediaMessage(
                                                                        { ...m.quoted, message: m.quoted.raw },
                                                                        'buffer', {},
                                                                        { logger: hisoka.logger, reuploadRequest: hisoka.updateMediaMessage }
                                                                );
                                                                if (imageBuffer?.length > 0) {
                                                                        imageMime = qtType === 'stickerMessage' ? 'image/webp' : 'image/jpeg';
                                                                        hasMedia = true;
                                                                        mediaLabel = qtType === 'stickerMessage' ? 'sticker' : 'gambar';
                                                                }
                                                        } catch (_) {}
                                                }

                                                if (!userMessage && hasMedia) {
                                                        userMessage = `Tolong analisis ${mediaLabel} ini secara lengkap dan detail.`;
                                                }
                                                if (!userMessage) userMessage = 'Halo!';

                                                // Cek apakah ini permintaan cari gambar
                                                const autoImgQuery = !hasMedia ? detectImageSearchQuery(userMessage) : null;
                                                if (autoImgQuery) {
                                                        try {
                                                                await tolak(hisoka, m, `🔍 Oke ${userName}, aku cariin gambar *${autoImgQuery}*...`);
                                                                const imgResult = await searchAndGetImage(autoImgQuery);
                                                                await hisoka.sendMessage(m.from, {
                                                                        image: imgResult.buffer,
                                                                        caption: `🖼️ *${imgResult.title || autoImgQuery}*\n🔗 ${imgResult.url}`
                                                                }, { quoted: m });
                                                                if (isAutoReplyOn) {
                                                                        addToHistory(getSessionKey(m), userMessage, `Ini gambar "${autoImgQuery}" yang aku cariin! Kalau mau yang lain bilang aja ya 🖼️`);
                                                                }
                                                        } catch (se) {
                                                                await tolak(hisoka, m, `❌ Maaf gagal cariin gambar "${autoImgQuery}". Coba lagi ya!`);
                                                        }
                                                        return;
                                                }

                                                // Load history untuk konteks
                                                const sessKey = getSessionKey(m);
                                                const histMsgs = getHistory(sessKey);
                                                const quotedBotText = (m.isQuoted && m.quoted?.key?.fromMe) ? (m.quoted?.text || '') : '';
                                                const systemPrompt = buildWilySystemPrompt({
                                                        userName, currentTime, currentDate, timeOfDay,
                                                        hasHistory: histMsgs.length > 0,
                                                        quotedBotText,
                                                });
                                                let contents;
                                                if (histMsgs.length > 0) {
                                                        contents = [
                                                                { role: 'user', parts: [{ text: systemPrompt }] },
                                                                { role: 'model', parts: [{ text: `Halo ${userName}! Aku Wily Bot, siap membantu 🤖` }] },
                                                                ...histMsgs,
                                                                { role: 'user', parts: [{ text: userMessage }] },
                                                        ];
                                                } else {
                                                        contents = [{ role: 'user', parts: [{ text: systemPrompt + '\n\n' + userMessage }] }];
                                                }

                                                let response;
                                                try {
                                                        if (imageBuffer && imageBuffer.length > 0) {
                                                                let finalBuffer = imageBuffer;
                                                                let finalMime = imageMime;
                                                                if (imageMime === 'image/webp') {
                                                                        try {
                                                                                const sharp = (await import('sharp')).default;
                                                                                finalBuffer = await sharp(imageBuffer).jpeg({ quality: 90 }).toBuffer();
                                                                                finalMime = 'image/jpeg';
                                                                        } catch (_) {}
                                                                }
                                                                if (histMsgs.length > 0) {
                                                                        const vContents = [
                                                                                { role: 'user', parts: [{ text: systemPrompt }] },
                                                                                { role: 'model', parts: [{ text: `Halo ${userName}! Aku Wily Bot 🤖` }] },
                                                                                ...histMsgs,
                                                                                { role: 'user', parts: [
                                                                                        { inlineData: { mimeType: finalMime, data: finalBuffer.toString('base64') } },
                                                                                        { text: userMessage },
                                                                                ]},
                                                                        ];
                                                                        const models = ['gemini-flash-latest', 'gemini-2.0-flash', 'gemini-pro'];
                                                                        for (const model of models) {
                                                                                try { response = await gemini.chat({ model, contents: vContents }); break; } catch (_) {}
                                                                        }
                                                                } else {
                                                                        response = await gemini.askWithImage(systemPrompt + '\n\n' + userMessage, finalBuffer, finalMime);
                                                                }
                                                        } else {
                                                                response = await gemini.chat({ contents });
                                                        }

                                                        if (response && response.trim()) {
                                                                const cleanResp = await sendAIReply(hisoka, m, response.trim());
                                                                addToHistory(sessKey, userMessage, cleanResp || response.trim());
                                                                console.log(`\x1b[36m[WilyAutoReply]\x1b[39m ${userName} | ${m.isGroup ? 'Grup' : 'Private'} | Media: ${hasMedia ? mediaLabel : 'tidak ada'}`);
                                                        }
                                                } catch (arErr) {
                                                        console.error('\x1b[31m[WilyAutoReply] Error:\x1b[39m', arErr.message);
                                                }
                                        }

                                        // ── WILY PRIVATE CHAT AUTO REPLY (semua pesan di DM) ──
                                        // Balas semua pesan di private chat tanpa perlu .wily
                                        // Termasuk saat user reply pesan bot — tidak ada pengecualian
                                        if (isWilyOn && wilyAICfg.privateReply !== false && !m.isGroup) {
                                                const pvUserName = getUserName(m.sender, m.pushName || 'Kak');
                                                const pvNow = new Date();
                                                const pvHours = parseInt(pvNow.toLocaleString('en-US', { hour: 'numeric', hour12: false, timeZone: 'Asia/Jakarta' }));
                                                const pvTimeOfDay = pvHours < 5 ? 'dini hari' : pvHours < 11 ? 'pagi' : pvHours < 15 ? 'siang' : pvHours < 18 ? 'sore' : 'malam';
                                                const pvCurrentTime = pvNow.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Jakarta' });
                                                const pvCurrentDate = pvNow.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Asia/Jakarta' });

                                                let pvUserMsg = m.text?.trim() || '';

                                                // Deteksi media
                                                let pvImageBuffer = null;
                                                let pvImageMime = 'image/jpeg';
                                                let pvHasMedia = false;
                                                let pvMediaLabel = '';
                                                const pvCurType = m.type || '';
                                                const pvQtType = m.isQuoted ? (m.quoted?.type || '') : '';

                                                if ((pvCurType === 'imageMessage' || pvCurType === 'stickerMessage') && m.isMedia) {
                                                        try {
                                                                pvImageBuffer = await m.downloadMedia();
                                                                if (pvImageBuffer?.length > 0) {
                                                                        pvImageMime = pvCurType === 'stickerMessage' ? 'image/webp' : 'image/jpeg';
                                                                        pvHasMedia = true;
                                                                        pvMediaLabel = pvCurType === 'stickerMessage' ? 'sticker' : 'gambar';
                                                                }
                                                        } catch (_) {}
                                                } else if (m.isQuoted && (pvQtType === 'imageMessage' || pvQtType === 'stickerMessage')) {
                                                        try {
                                                                pvImageBuffer = await downloadMediaMessage(
                                                                        { ...m.quoted, message: m.quoted.raw },
                                                                        'buffer', {},
                                                                        { logger: hisoka.logger, reuploadRequest: hisoka.updateMediaMessage }
                                                                );
                                                                if (pvImageBuffer?.length > 0) {
                                                                        pvImageMime = pvQtType === 'stickerMessage' ? 'image/webp' : 'image/jpeg';
                                                                        pvHasMedia = true;
                                                                        pvMediaLabel = pvQtType === 'stickerMessage' ? 'sticker' : 'gambar';
                                                                }
                                                        } catch (_) {}
                                                }

                                                if (!pvUserMsg && pvHasMedia) pvUserMsg = `Tolong analisis ${pvMediaLabel} ini secara lengkap dan detail.`;
                                                if (!pvUserMsg) {
                                                        if (pvCurType.includes('video')) pvUserMsg = 'Pengguna mengirim video';
                                                        else if (pvCurType.includes('audio')) pvUserMsg = 'Pengguna mengirim voice note';
                                                        else if (pvCurType.includes('document')) pvUserMsg = 'Pengguna mengirim dokumen';
                                                        else pvUserMsg = 'Halo!';
                                                }

                                                // Cek permintaan cari gambar
                                                if (!pvHasMedia) {
                                                        const pvImgQ = detectImageSearchQuery(pvUserMsg);
                                                        if (pvImgQ) {
                                                                try {
                                                                        await tolak(hisoka, m, `🔍 Oke ${pvUserName}, aku cariin gambar *${pvImgQ}*...`);
                                                                        const pvImgResult = await searchAndGetImage(pvImgQ);
                                                                        await hisoka.sendMessage(m.from, {
                                                                                image: pvImgResult.buffer,
                                                                                caption: `🖼️ *${pvImgResult.title || pvImgQ}*\n🔗 ${pvImgResult.url}`
                                                                        }, { quoted: m });
                                                                } catch (_) {
                                                                        await tolak(hisoka, m, `❌ Maaf gagal cariin gambar "${pvImgQ}". Coba lagi ya!`);
                                                                }
                                                                return;
                                                        }
                                                }

                                                const pvSessKey = getSessionKey(m);
                                                const pvHistMsgs = getHistory(pvSessKey);
                                                // Kalau user reply pesan bot, kirim konteks pesan yang di-reply ke AI
                                                const pvQuotedBotText = (m.isQuoted && m.quoted?.key?.fromMe)
                                                        ? (m.quoted?.text || m.quoted?.caption || '')
                                                        : '';
                                                const pvSystemPrompt = buildWilySystemPrompt({
                                                        userName: pvUserName, currentTime: pvCurrentTime, currentDate: pvCurrentDate, timeOfDay: pvTimeOfDay,
                                                        hasHistory: pvHistMsgs.length > 0,
                                                        quotedBotText: pvQuotedBotText,
                                                });

                                                let pvContents;
                                                if (pvHistMsgs.length > 0) {
                                                        pvContents = [
                                                                { role: 'user', parts: [{ text: pvSystemPrompt }] },
                                                                { role: 'model', parts: [{ text: `Halo ${pvUserName}! Aku Wily Bot 🤖` }] },
                                                                ...pvHistMsgs,
                                                                { role: 'user', parts: [{ text: pvUserMsg }] },
                                                        ];
                                                } else {
                                                        pvContents = [{ role: 'user', parts: [{ text: pvSystemPrompt + '\n\n' + pvUserMsg }] }];
                                                }

                                                try {
                                                        let pvResponse;
                                                        if (pvImageBuffer && pvImageBuffer.length > 0) {
                                                                let pvFinalBuf = pvImageBuffer;
                                                                let pvFinalMime = pvImageMime;
                                                                if (pvImageMime === 'image/webp') {
                                                                        try {
                                                                                const sharp = (await import('sharp')).default;
                                                                                pvFinalBuf = await sharp(pvImageBuffer).jpeg({ quality: 90 }).toBuffer();
                                                                                pvFinalMime = 'image/jpeg';
                                                                        } catch (_) {}
                                                                }
                                                                pvResponse = await gemini.askWithImage(pvSystemPrompt + '\n\n' + pvUserMsg, pvFinalBuf, pvFinalMime);
                                                        } else {
                                                                pvResponse = await gemini.chat({ contents: pvContents });
                                                        }

                                                        if (pvResponse && pvResponse.trim()) {
                                                                const pvClean = await sendAIReply(hisoka, m, pvResponse.trim());
                                                                addToHistory(pvSessKey, pvUserMsg, pvClean || pvResponse.trim());
                                                                console.log(`\x1b[36m[WilyPrivate]\x1b[39m ${pvUserName} | DM | Media: ${pvHasMedia ? pvMediaLabel : 'tidak ada'}`);
                                                        }
                                                } catch (pvErr) {
                                                        console.error('\x1b[31m[WilyPrivate] Error:\x1b[39m', pvErr.message);
                                                }
                                        }
                                }

                        } catch (autoSimiError) {
                                console.error('\x1b[31m[AutoGemini] Error:\x1b[39m', autoSimiError.message);
                        }
                }
                
                if (hisoka?.isMainBot === true) {
                    if (!m.isOwner) return;
                }

                if (hisoka?.isMainBot === false) {
                    if (!isAllowedForJadibot(m, hisoka)) return;
                }

                // Handle pending play choice (user balas 1 atau 2)
                if (pendingPlayChoices.has(m.sender)) {
                        const choice = (m.text || '').trim();
                        if (choice === '1' || choice === '2') {
                                const pending = pendingPlayChoices.get(m.sender);

                                // Cek kalau pilihan yang SAMA sedang diunduh (biar tidak double)
                                if (!pending.downloading) pending.downloading = new Set();
                                if (pending.downloading.has(choice)) {
                                        await m.reply(`⏳ Sedang mengunduh *${choice === '1' ? 'Audio MP3' : 'Video MP4'}*... harap tunggu.`);
                                        return;
                                }

                                // Tandai format ini sedang diunduh, tapi format lain tetap bisa jalan
                                pending.downloading.add(choice);

                                // Reset timeout — perpanjang selama masih ada yang berjalan
                                if (pending.timeout) {
                                        clearTimeout(pending.timeout);
                                        pending.timeout = null;
                                }

                                // Jalankan download secara async tanpa await di sini
                                // supaya pesan handler selesai dan tombol lain bisa langsung diproses
                                (async () => {
                                        try {
                                                await hisoka.sendMessage(m.from, { react: { text: '⏳', key: m.key } });
                                                const loadingMsg = await tolak(hisoka, m, `⏳ Mengunduh ${choice === '1' ? 'audio MP3' : 'video MP4'}...`);

                                                const ytdlpBin = await ensureYtdlp(hisoka, m);
                                                const tmpId = Date.now();

                                                if (choice === '1') {
                                                        const tmpFile = path.join(process.cwd(), 'tmp', `play_${tmpId}.mp3`);
                                                        const tmpTemplate = path.join(process.cwd(), 'tmp', `play_${tmpId}.%(ext)s`);

                                                        await new Promise((resolve, reject) => {
                                                                const cmd = `"${ytdlpBin}" --js-runtimes node --no-playlist -x --audio-format mp3 --audio-quality 5 -o "${tmpTemplate}" "${pending.url}"`;
                                                                exec(cmd, { timeout: 120000 }, (err, stdout, stderr) => {
                                                                        if (err) return reject(new Error(parseYtdlpError(stderr, err.message)));
                                                                        resolve();
                                                                });
                                                        });

                                                        const audioBuffer = fs.readFileSync(tmpFile);
                                                        await hisoka.sendMessage(m.from, {
                                                                audio: audioBuffer,
                                                                mimetype: 'audio/mpeg',
                                                                fileName: `${pending.title.replace(/[^\w\s]/gi, '')}.mp3`,
                                                                ptt: false
                                                        }, { quoted: m });

                                                        await hisoka.sendMessage(m.from, { react: { text: '✅', key: m.key } });
                                                        await m.reply({ edit: loadingMsg.key, text: `✅ *Audio MP3 berhasil dikirim!*\n📌 ${pending.title}` });
                                                        try { fs.unlinkSync(tmpFile); } catch (_) {}

                                                } else {
                                                        if (pending.seconds > 300) {
                                                                await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                                                await m.reply({ edit: loadingMsg.key, text: `❌ Durasi terlalu panjang untuk video! (${pending.duration})\nMaksimal 5 menit untuk MP4.\n\nGunakan pilihan *1* untuk Audio MP3.` });
                                                                return;
                                                        }

                                                        const tmpFile = path.join(process.cwd(), 'tmp', `play_${tmpId}.mp4`);
                                                        const tmpTemplate = path.join(process.cwd(), 'tmp', `play_${tmpId}.%(ext)s`);

                                                        await new Promise((resolve, reject) => {
                                                                const cmd = `"${ytdlpBin}" --js-runtimes node --no-playlist -f "bestvideo[height<=360][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=360]+bestaudio/best[height<=360]" --merge-output-format mp4 -o "${tmpTemplate}" "${pending.url}"`;
                                                                exec(cmd, { timeout: 180000 }, (err, stdout, stderr) => {
                                                                        if (err) return reject(new Error(parseYtdlpError(stderr, err.message)));
                                                                        resolve();
                                                                });
                                                        });

                                                        const videoBuffer = fs.readFileSync(tmpFile);
                                                        await hisoka.sendMessage(m.from, {
                                                                video: videoBuffer,
                                                                mimetype: 'video/mp4',
                                                                caption: `🎬 *${pending.title}*`
                                                        }, { quoted: m });

                                                        await hisoka.sendMessage(m.from, { react: { text: '✅', key: m.key } });
                                                        await m.reply({ edit: loadingMsg.key, text: `✅ *Video MP4 berhasil dikirim!*\n📌 ${pending.title}` });
                                                        try { fs.unlinkSync(tmpFile); } catch (_) {}
                                                }

                                                logCommand(m, hisoka, 'play');
                                        } catch (error) {
                                                await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                                await tolak(hisoka, m, `❌ Gagal mengunduh: ${error.message?.substring(0, 200)}`);
                                        } finally {
                                                // Hapus format ini dari set downloading
                                                if (pendingPlayChoices.has(m.sender)) {
                                                        const p = pendingPlayChoices.get(m.sender);
                                                        if (p.downloading) p.downloading.delete(choice);
                                                        // Kalau sudah tidak ada yang berjalan, set timeout cleanup
                                                        if (!p.downloading || p.downloading.size === 0) {
                                                                if (p.timeout) clearTimeout(p.timeout);
                                                                p.timeout = setTimeout(() => {
                                                                        pendingPlayChoices.delete(m.sender);
                                                                }, 2 * 60 * 1000);
                                                        }
                                                }
                                        }
                                })();

                                return;
                        }

                        // Pending ada tapi bukan pilihan 1/2 — abaikan (biarkan lanjut ke switch)
                }

                switch (m.command) {

                        case 'ht':
                        case 'all': {
                                if (!m.isGroup) return;

                                const group = hisoka.groups.read(m.from);
                                const participants = group.participants.map(v => v.phoneNumber || v.id);

                                const msg = await hisoka.messageModify(m.from, /text|conversation/i.test(m.type) && query ? m : quoted, {
                                        quoted: undefined,
                                        text: `@${m.from}\n\n${query}`.trim(),
                                        mentions: participants.map(v => ({ id: v })).concat({ id: m.from, name: 'everyone' }),
                                });

                                await hisoka.relayMessage(m.from, msg.message);
                                logCommand(m, hisoka, 'hidetag');
                                break;
                        }

                        case 'q':
                        case 'quoted': {
                                if (!m.isQuoted) {
                                        await tolak(hisoka, m, 'No quoted message found.');
                                        return;
                                }

                                const message = hisoka.cacheMsg.get(m.quoted.key.id);
                                if (!message) {
                                        await tolak(hisoka, m, 'Quoted message not found.');
                                        return;
                                }

                                const IMessage = await injectMessage(hisoka, message);
                                if (!IMessage.isQuoted) {
                                        await tolak(hisoka, m, 'Quoted message not found.');
                                        return;
                                }

                                await m.reply({ forward: IMessage.quoted });
                                logCommand(m, hisoka, 'quoted');
                                break;
                        }

                                case 'p':
                                case 'ping' : {
                                try {
                                        const msg = await tolak(hisoka, m, '⏳ _Checking..._');
                                        const latency = Math.abs(Date.now() - m.messageTimestamp * 1000);
                                        const stats = getBotStats();
                                        const sessionUptime = process.uptime();
                                        
                                        const memUsage = process.memoryUsage();
                                        const memUsedMB = (memUsage.heapUsed / 1024 / 1024).toFixed(2);
                                        const memTotalMB = (memUsage.heapTotal / 1024 / 1024).toFixed(2);
                                        
                                        const now = new Date();
                                        const timeStr = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Jakarta' });
                                        const dateStr = now.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'Asia/Jakarta' });
                                        
                                        const jakartaHour = parseInt(now.toLocaleTimeString('id-ID', { hour: '2-digit', hour12: false, timeZone: 'Asia/Jakarta' }));
                                        let greetingTime, greetingEmoji;
                                        if (jakartaHour >= 4 && jakartaHour < 11) {
                                                greetingTime = 'Pagi';
                                                greetingEmoji = '🌅';
                                        } else if (jakartaHour >= 11 && jakartaHour < 15) {
                                                greetingTime = 'Siang';
                                                greetingEmoji = '☀️';
                                        } else if (jakartaHour >= 15 && jakartaHour < 18) {
                                                greetingTime = 'Sore';
                                                greetingEmoji = '🌇';
                                        } else {
                                                greetingTime = 'Malam';
                                                greetingEmoji = '🌙';
                                        }
                                        
                                        const speedText = latency < 100 ? 'Cepat' : latency < 500 ? 'Normal' : 'Lambat';
                                        const speedEmoji = latency < 100 ? '🚀' : latency < 500 ? '⚡' : '🐢';
                                        
                                        const sessSeconds = Math.floor(sessionUptime);
                                        const sessMinutes = Math.floor(sessSeconds / 60);
                                        const sessHours = Math.floor(sessMinutes / 60);
                                        const sessDays = Math.floor(sessHours / 24);
                                        const sessFormatted = `${sessDays}d ${sessHours % 24}h ${sessMinutes % 60}m`;
                                        
                                        const cpuCores = os.cpus().length;
                                        const cpuModel = os.cpus()[0]?.model?.split(' ')[0] || 'Unknown';
                                        const totalMemGB = (os.totalmem() / 1024 / 1024 / 1024).toFixed(1);
                                        const freeMemGB = (os.freemem() / 1024 / 1024 / 1024).toFixed(1);
                                        const usedMemGB = (totalMemGB - freeMemGB).toFixed(1);
                                        const memPercent = ((usedMemGB / totalMemGB) * 100).toFixed(0);
                                        const nodeVersion = process.version;
                                        const platform = process.platform;
                                        
                                        const pingText = `
╭═════════════════════╮
║        🏓 *PONG!* 🏓        
├═════════════════════┤
│ 👋 Selamat  » ${greetingTime} ${greetingEmoji}
│ ${speedEmoji} Speed  » ${speedText}
│ ⚡ Latency  » ${latency}ms
│ 🕐 Waktu  » ${timeStr}
│ 📅 Tanggal  » ${dateStr}
├═════════════════════┤
║        📊 *BOT STATUS*        
├═════════════════════┤
│ ⏱️ Uptime  » ${stats.uptime.days}d ${stats.uptime.hours}h ${stats.uptime.minutes}m
│ 🔄 Session  » ${sessFormatted}
│ 🔁 Restart  » ${stats.totalRestarts}x
│ 🟢 Status  » Online
├═════════════════════┤
║        💻 *SYSTEM INFO*        
├═════════════════════┤
│ 🧠 CPU  » ${cpuCores} Core
│ 📟 RAM  » ${usedMemGB}/${totalMemGB}GB (${memPercent}%)
│ 💾 Bot Mem  » ${memUsedMB}MB
│ 🖥️ Platform  » ${platform}
│ 📦 NodeJS  » ${nodeVersion}
╰═════════════════════╯`;

                                        let ppUrl;
                                        try {
                                                ppUrl = await hisoka.profilePictureUrl(hisoka.user.id, 'image');
                                        } catch {
                                                ppUrl = null;
                                        }

                                        if (ppUrl) {
                                                await hisoka.sendMessage(m.from, {
                                                        image: { url: ppUrl },
                                                        caption: pingText
                                                }, { quoted: m });
                                        } else {
                                                await m.reply({ edit: msg.key, text: pingText });
                                        }
                                        
                                        logCommand(m, hisoka, 'ping');
                                } catch (err) {
                                        console.error('\x1b[31mPing error:\x1b[39m', err.message);
                                }
                                break;
                        }

                        case '>':
                        case 'eval': {
                                let result;
                                try {
                                        const code = query || text;
                                        result = /await/i.test(code) ? await eval('(async() => { ' + code + ' })()') : await eval(code);
                                } catch (error) {
                                        result = error;
                                }

                                await tolak(hisoka, m, util.format(result));
                                logCommand(m, hisoka, 'eval');
                                break;
                        }

                        case '$':
                        case 'bash': {
                                try {
                                        exec(query, (error, stdout, stderr) => {
                                                if (error) {
                                                        return m.throw(util.format(error));
                                                }
                                                if (stderr) {
                                                        return m.throw(stderr);
                                                }
                                                if (stdout) {
                                                        return tolak(hisoka, m, stdout);
                                                }
                                                return m.throw('Command executed successfully, but no output.');
                                        });
                                        logCommand(m, hisoka, 'bash');
                                } catch (error) {
                                        await tolak(hisoka, m, util.format(error));
                                        return;
                                }
                                break;
                        }

                        case 'group':
                        case 'listgroup': {
                                const groups = Object.values(await hisoka.groupFetchAllParticipating());
                                groups.map(g => hisoka.groups.write(g.id, g));

                                let text = `*Total ${groups.length} groups*\n`;
                                text += `\n*Total Participants in all groups:* ${Array.from(groups).reduce(
                                        (a, b) => a + b.participants.length,
                                        0
                                )}\n\n`;
                                groups
                                        .filter(group => isJidGroup(group.id))
                                        .forEach((group, i) => {
                                                text += `${i + 1}. *${group.subject}* - ${group.participants.length} participants\n`;
                                        });

                                await tolak(hisoka, m, text.trim());
                                logCommand(m, hisoka, 'groups');
                                break;
                        }

                        case 'contact':
                        case 'listcontact': {
                                const contacts = Array.from(hisoka.contacts.values()).filter(c => c.id);
                                let text = '*Total:*\n\n';
                                text += `- All Contacts: ${contacts.length}\n`;
                                text += `- Saved Contacts: ${contacts.filter(v => v.isContact).length}\n`;
                                text += `- Not Saved Contacts: ${contacts.filter(v => !v.isContact).length}\n`;
                                await tolak(hisoka, m, text.trim());
                                logCommand(m, hisoka, 'contacts');
                                break;
                        }

                        case 'menu': {
                                const cfg      = loadConfig();
                                const botReply = cfg.botReply || {};
                                const botName  = botReply.botName     || 'Wily Bot';
                                const ownerNum = botReply.ownerNumber || '';
                                const uptime   = process.uptime();
                                const uh = Math.floor(uptime / 3600);
                                const um = Math.floor((uptime % 3600) / 60);
                                const us = Math.floor(uptime % 60);
                                const uptimeStr = `${uh} Jam ${um} Menit ${us} Detik`;
                                const totalCmd = hisoka.loadedCommands?.length || 0;

                                hisoka.sendMessage(m.from, { react: { text: `🌊`, key: m.key } });

                                const teks =
`╭─「 👤 *INFO PENGGUNA* 」
│
├➤ *Nama*   : ${m.pushName}
├➤ *Rank*   : ${m.isOwner ? '👑 Owner' : '🆓 Pengguna'}
├➤ *Fitur*  : ${totalCmd} fitur tersedia
╰➤ *Status* : Online 🟢

╭─「 🤖 *INFO BOT* 」
│
├➤ *Bot*    : ${botName}
├➤ *Uptime* : ${uptimeStr}
╰➤ *Prefix* : Bisa dengan atau tanpa prefix

╭─「 🌐 *KONTAK* 」
│
╰➤ *WA*     : wa.me/${ownerNum}

▸▸▸━━━━━━━━━━━━━━━━━━━━◂◂◂

💬 _"Kami terus berinovasi untuk_
_memberikan pengalaman terbaik!"_ ✨

`;

                                const bet = {
                                        title: `LIST MENU`,
                                        sections: [
                                                {
                                                        title: `List menu yang sering dipakai`,
                                                        highlight_label: `Populer`,
                                                        rows: [
                                                                { title: `All Menu`,      description: `📌 Menampilkan All Menu`,                 id: `allmenu` },
                                                                { title: `🏓 Ping`,       description: `🏓 Cek kecepatan respon bot`,             id: `ping` },
                                                                { title: `ℹ️ Info Bot`,   description: `📋 Informasi total fitur dan lainnya`,    id: `info` },
                                                                { title: `🧠 Memory/RAM`, description: `💾 Menampilkan penggunaan RAM`,            id: `memory` },
                                                        ]
                                                },
                                                {
                                                        title: `List menu yang dipisahkan`,
                                                        highlight_label: ``,
                                                        rows: [
                                                                { title: `⚙️ Setting Menu`,    description: `╰➤ Pengaturan fitur bot otomatis`,      id: `settingmenu` },
                                                                { title: `👥 Group Menu`,      description: `╰➤ Fitur grup & kirim pesan`,            id: `groupmenu` },
                                                                { title: `📡 Status Menu`,     description: `╰➤ Upload status & anti tag story`,      id: `statusmenu` },
                                                                { title: `📥 Download Menu`,   description: `╰➤ Download dari berbagai platform`,     id: `downloadmenu` },
                                                                { title: `🤖 Jadibot Menu`,    description: `╰➤ Clone & kelola jadibot WhatsApp`,     id: `jadibotmenu` },
                                                                { title: `👑 Owner Menu`,      description: `╰➤ Fitur khusus owner & advanced`,       id: `ownermenu` },
                                                        ]
                                                },
                                        ]
                                };

                                await listbut2(m.from, teks, bet, m, hisoka);
                                logCommand(m, hisoka, 'menu');
                                break;
                        }

                        case 'allmenu': {
                                const cfg      = loadConfig();
                                const botReply = cfg.botReply || {};
                                const botName  = botReply.botName || 'Wily Bot';

                                hisoka.sendMessage(m.from, { react: { text: `⏱️`, key: m.key } });

                                const allTeks =
`╭─「 📋 *SEMUA PERINTAH* 」
│
├➤ *.menu*
├➤ *.allmenu*
├➤ *.ping*
├➤ *.info*
├➤ *.memory / .ram*
│
├➤ *.typing*
├➤ *.recording*
├➤ *.online*
├➤ *.readsw*
├➤ *.antidel on/off*
├➤ *.anticall*
├➤ *.anticallvid*
├➤ *.autocleaner*
├➤ *.sessioncleaner*
├➤ *.telegram*
│
├➤ *.hidetag*
├➤ *.ghosttag*
├➤ *.quoted*
├➤ *.rvo*
├➤ *.s*
├➤ *.toimg*
├➤ *.listgroup*
├➤ *.group*
│
├➤ *.upswgc*
├➤ *.antitagsw*
│
├➤ *.tt*
├➤ *.ig*
├➤ *.fb*
├➤ *.ytmp3*
├➤ *.ytmp4*
├➤ *.play*
├➤ *.hd / .remini / .hdr*
├➤ *.hdvid / .vidhd / .hdvideo*
│
├➤ *.react*
├➤ *.cekreact*
├➤ *.setreactapi*
│
├➤ *.jadibot*
├➤ *.stopjadibot*
├➤ *.listjadibot*
│
├➤ *.addemoji*
├➤ *.delemoji*
├➤ *.listemoji*
├➤ *.wily*
├➤ *.simi*
├➤ *.wilyai*
├➤ *.contact*
│
├➤ *.listowner*
├➤ *.addowner*
├➤ *.delowner*
├➤ *.backup*
├➤ *.ceksesi*
├➤ *.eval*
├➤ *.bash*
╰➤ *.cekerror*

`;

                                const betAll = {
                                        title: `LIST MENU`,
                                        sections: [
                                                {
                                                        title: `List menu yang sering dipakai`,
                                                        highlight_label: `Populer`,
                                                        rows: [
                                                                { title: `All Menu`,              description: `📌 Menampilkan All Menu`,           id: `allmenu` },
                                                                { title: `🏠 Kembali ke Menu`,    description: `↩️ Balik ke halaman menu awal`,      id: `menu` },
                                                        ]
                                                },
                                                {
                                                        title: `List menu yang dipisahkan`,
                                                        highlight_label: ``,
                                                        rows: [
                                                                { title: `Ping`,             description: `🏓 Cek kecepatan respon bot`,            id: `ping` },
                                                                { title: `Info Bot`,         description: `📋 Informasi total fitur dan lainnya`,   id: `info` },
                                                                { title: `Memory / RAM`,     description: `🧠 Menampilkan penggunaan RAM`,          id: `memory` },
                                                                { title: `Auto Typing`,      description: `⌨️ Toggle auto-typing`,                  id: `typing` },
                                                                { title: `Auto Recording`,   description: `🎙️ Toggle auto-recording`,               id: `recording` },
                                                                { title: `Auto Online`,      description: `🟢 Toggle selalu online`,                id: `online` },
                                                                { title: `Auto Read Story`,  description: `📖 Toggle baca story otomatis`,          id: `readsw` },
                                                                { title: `Anti Delete`,      description: `🚫 Anti hapus pesan`,                    id: `antidel on` },
                                                                { title: `Anti Call`,        description: `📵 Anti panggilan suara`,                id: `anticall` },
                                                                { title: `Anti Call Video`,  description: `📵 Anti panggilan video`,                id: `anticallvid` },
                                                                { title: `Auto Cleaner`,     description: `🧹 Pembersih file otomatis`,             id: `autocleaner on` },
                                                                { title: `Hidetag`,          description: `📢 Mention semua anggota grup`,          id: `hidetag` },
                                                                { title: `Ghost Tag`,        description: `👻 Ghost tag semua anggota`,             id: `ghosttag` },
                                                                { title: `Quoted`,           description: `💬 Forward pesan quoted`,                id: `quoted` },
                                                                { title: `RVO`,              description: `👁️ Buka pesan view once`,               id: `rvo` },
                                                                { title: `Sticker`,          description: `🎨 Buat sticker dari foto/video`,       id: `s` },
                                                                { title: `To Image`,         description: `🖼️ Sticker jadi gambar`,               id: `toimg` },
                                                                { title: `List Group`,       description: `📋 Daftar semua grup bot`,               id: `listgroup` },
                                                                { title: `TikTok`,           description: `🎵 Download video TikTok`,               id: `tt` },
                                                                { title: `Instagram`,        description: `📸 Download foto/video Instagram`,      id: `ig` },
                                                                { title: `Facebook`,         description: `📘 Download video Facebook`,             id: `fb` },
                                                                { title: `YT MP3`,           description: `🎵 Download audio YouTube`,              id: `ytmp3` },
                                                                { title: `YT MP4`,           description: `🎬 Download video YouTube`,              id: `ytmp4` },
                                                                { title: `Play`,             description: `▶️ Putar lagu YouTube`,                 id: `play` },
                                                                { title: `React Channel`,    description: `⚡ Aktifkan react channel`,              id: `react` },
                                                                { title: `Jadibot`,          description: `🤖 Clone bot ke nomor kamu`,             id: `jadibot` },
                                                                { title: `Stop Jadibot`,     description: `🛑 Hentikan jadibot`,                    id: `stopjadibot` },
                                                                { title: `List Jadibot`,     description: `📋 Daftar jadibot aktif`,                id: `listjadibot` },
                                                                { title: `Wily AI`,          description: `🤖 Chat AI Gemini Vision (analisis gambar/sticker)`, id: `wily` },
                                                                { title: `Simi`,             description: `⚙️ Pengaturan Wily AI Auto`,                id: `simi` },
                                                                { title: `Wily AI Setting`,  description: `🛠️ Setting & reset history AI`,              id: `wilyai` },
                                                        ]
                                                },
                                                {
                                                        title: `Owner & Advanced`,
                                                        highlight_label: ``,
                                                        rows: [
                                                                { title: `List Owner`,  description: `👑 Lihat daftar owner`,                      id: `listowner` },
                                                                { title: `Add Owner`,   description: `➕ Tambah owner baru`,                       id: `addowner` },
                                                                { title: `Del Owner`,   description: `➖ Hapus owner`,                             id: `delowner` },
                                                                { title: `Backup`,      description: `💾 Backup data bot`,                         id: `backup` },
                                                                { title: `Cek Sesi`,    description: `🗂️ Cek isi file sesi bot realtime`,           id: `ceksesi` },
                                                                { title: `Eval`,        description: `🔧 Jalankan kode JavaScript`,                id: `eval` },
                                                                { title: `Bash`,        description: `💻 Jalankan perintah shell`,                  id: `bash` },
                                                                { title: `Cek Error`,   description: `🚨 Lihat log error bot realtime`,             id: `cekerror` },
                                                        ]
                                                },
                                        ]
                                };

                                await listbut2(m.from, allTeks, betAll, m, hisoka);
                                logCommand(m, hisoka, 'allmenu');
                                break;
                        }

                        case 'settingmenu': {
                                const cfg      = loadConfig();
                                const botReply = cfg.botReply || {};
                                const botName  = botReply.botName || 'Wily Bot';

                                hisoka.sendMessage(m.from, { react: { text: `⚙️`, key: m.key } });

                                const settingTeks =
`╭─「 ⚙️ *SETTING MENU* 」
│
├➤ *.typing*
├➤ *.recording*
├➤ *.online*
├➤ *.readsw*
├➤ *.antidel on/off*
├➤ *.anticall*
├➤ *.anticallvid*
├➤ *.autocleaner on/off*
├➤ *.sessioncleaner on/off*
╰➤ *.telegram*

`;

                                const betSetting = {
                                        title: `LIST MENU`,
                                        sections: [
                                                {
                                                        title: `List menu yang sering dipakai`,
                                                        highlight_label: `Populer`,
                                                        rows: [
                                                                { title: `All Menu`,           description: `📌 Menampilkan All Menu`,           id: `allmenu` },
                                                                { title: `🏠 Kembali ke Menu`, description: `↩️ Balik ke halaman menu awal`,      id: `menu` },
                                                        ]
                                                },
                                                {
                                                        title: `Kategori Menu`,
                                                        highlight_label: ``,
                                                        rows: [
                                                                { title: `⚙️ Setting Menu`,  description: `╰➤ Pengaturan fitur bot otomatis`,   id: `settingmenu` },
                                                                { title: `👥 Group Menu`,    description: `╰➤ Fitur grup & kirim pesan`,         id: `groupmenu` },
                                                                { title: `📡 Status Menu`,   description: `╰➤ Upload status & anti tag story`,   id: `statusmenu` },
                                                                { title: `📥 Download Menu`, description: `╰➤ Download dari berbagai platform`,  id: `downloadmenu` },
                                                                { title: `🤖 Jadibot Menu`,  description: `╰➤ Clone & kelola jadibot WhatsApp`,  id: `jadibotmenu` },
                                                                { title: `👑 Owner Menu`,    description: `╰➤ Fitur khusus owner & advanced`,    id: `ownermenu` },
                                                        ]
                                                },
                                                {
                                                        title: `List fitur setting`,
                                                        highlight_label: ``,
                                                        rows: [
                                                                { title: `Auto Typing`,      description: `⌨️ Toggle auto-typing`,                id: `typing` },
                                                                { title: `Auto Recording`,   description: `🎙️ Toggle auto-recording`,             id: `recording` },
                                                                { title: `Auto Online`,      description: `🟢 Toggle selalu online`,              id: `online` },
                                                                { title: `Auto Read Story`,  description: `📖 Toggle baca story otomatis`,        id: `readsw` },
                                                                { title: `Anti Delete`,      description: `🚫 Anti hapus pesan`,                  id: `antidel on` },
                                                                { title: `Anti Call`,        description: `📵 Anti panggilan suara`,              id: `anticall` },
                                                                { title: `Anti Call Video`,  description: `📵 Anti panggilan video`,              id: `anticallvid` },
                                                                { title: `Auto Cleaner`,     description: `🧹 Pembersih file otomatis`,           id: `autocleaner on` },
                                                                { title: `Session Cleaner`,  description: `🗑️ Pembersih sesi otomatis`,           id: `sessioncleaner on` },
                                                                { title: `Telegram Notif`,   description: `📲 Konfigurasi notifikasi Telegram`,   id: `telegram` },
                                                        ]
                                                },
                                        ]
                                };

                                await listbut2(m.from, settingTeks, betSetting, m, hisoka);
                                logCommand(m, hisoka, 'settingmenu');
                                break;
                        }

                        case 'groupmenu': {
                                const cfg      = loadConfig();
                                const botReply = cfg.botReply || {};
                                const botName  = botReply.botName || 'Wily Bot';

                                hisoka.sendMessage(m.from, { react: { text: `👥`, key: m.key } });

                                const groupTeks =
`╭─「 👥 *GROUP & PESAN MENU* 」
│
├➤ *.hidetag [teks]*
├➤ *.ghosttag [teks]*
├➤ *.quoted*
├➤ *.rvo*
├➤ *.s*
├➤ *.toimg*
├➤ *.listgroup*
╰➤ *.group*

`;

                                const betGroup = {
                                        title: `LIST MENU`,
                                        sections: [
                                                {
                                                        title: `List menu yang sering dipakai`,
                                                        highlight_label: `Populer`,
                                                        rows: [
                                                                { title: `All Menu`,           description: `📌 Menampilkan All Menu`,           id: `allmenu` },
                                                                { title: `🏠 Kembali ke Menu`, description: `↩️ Balik ke halaman menu awal`,      id: `menu` },
                                                        ]
                                                },
                                                {
                                                        title: `Kategori Menu`,
                                                        highlight_label: ``,
                                                        rows: [
                                                                { title: `⚙️ Setting Menu`,  description: `╰➤ Pengaturan fitur bot otomatis`,   id: `settingmenu` },
                                                                { title: `👥 Group Menu`,    description: `╰➤ Fitur grup & kirim pesan`,         id: `groupmenu` },
                                                                { title: `📡 Status Menu`,   description: `╰➤ Upload status & anti tag story`,   id: `statusmenu` },
                                                                { title: `📥 Download Menu`, description: `╰➤ Download dari berbagai platform`,  id: `downloadmenu` },
                                                                { title: `🤖 Jadibot Menu`,  description: `╰➤ Clone & kelola jadibot WhatsApp`,  id: `jadibotmenu` },
                                                                { title: `👑 Owner Menu`,    description: `╰➤ Fitur khusus owner & advanced`,    id: `ownermenu` },
                                                        ]
                                                },
                                                {
                                                        title: `List fitur grup & pesan`,
                                                        highlight_label: ``,
                                                        rows: [
                                                                { title: `Hidetag`,          description: `📢 Mention semua anggota tanpa terlihat`, id: `hidetag` },
                                                                { title: `Ghost Tag`,        description: `👻 Ghost tag semua anggota grup`,          id: `ghosttag` },
                                                                { title: `Quoted`,           description: `💬 Forward pesan yang di-reply`,           id: `quoted` },
                                                                { title: `RVO`,              description: `👁️ Buka pesan view once`,                 id: `rvo` },
                                                                { title: `Sticker`,          description: `🎨 Buat sticker dari foto atau video`,     id: `s` },
                                                                { title: `To Image`,         description: `🖼️ Ubah sticker menjadi gambar`,          id: `toimg` },
                                                                { title: `List Group`,       description: `📋 Daftar semua grup yang diikuti bot`,    id: `listgroup` },
                                                                { title: `Group Info`,       description: `👥 Info dan link grup saat ini`,           id: `group` },
                                                        ]
                                                },
                                        ]
                                };

                                await listbut2(m.from, groupTeks, betGroup, m, hisoka);
                                logCommand(m, hisoka, 'groupmenu');
                                break;
                        }

                        case 'statusmenu': {
                                const cfg      = loadConfig();
                                const botReply = cfg.botReply || {};
                                const botName  = botReply.botName || 'Wily Bot';

                                hisoka.sendMessage(m.from, { react: { text: `📡`, key: m.key } });

                                const statusTeks =
`╭─「 📡 *STATUS & ANTI-TAG MENU* 」
│
├➤ *.upswgc [caption]*
├➤ *.antitagsw on*
├➤ *.antitagsw off*
├➤ *.antitagsw reset*
╰➤ *.antitagsw status*

`;

                                const betStatus = {
                                        title: `LIST MENU`,
                                        sections: [
                                                {
                                                        title: `List menu yang sering dipakai`,
                                                        highlight_label: `Populer`,
                                                        rows: [
                                                                { title: `All Menu`,           description: `📌 Menampilkan All Menu`,           id: `allmenu` },
                                                                { title: `🏠 Kembali ke Menu`, description: `↩️ Balik ke halaman menu awal`,      id: `menu` },
                                                        ]
                                                },
                                                {
                                                        title: `Kategori Menu`,
                                                        highlight_label: ``,
                                                        rows: [
                                                                { title: `⚙️ Setting Menu`,  description: `╰➤ Pengaturan fitur bot otomatis`,   id: `settingmenu` },
                                                                { title: `👥 Group Menu`,    description: `╰➤ Fitur grup & kirim pesan`,         id: `groupmenu` },
                                                                { title: `📡 Status Menu`,   description: `╰➤ Upload status & anti tag story`,   id: `statusmenu` },
                                                                { title: `📥 Download Menu`, description: `╰➤ Download dari berbagai platform`,  id: `downloadmenu` },
                                                                { title: `🤖 Jadibot Menu`,  description: `╰➤ Clone & kelola jadibot WhatsApp`,  id: `jadibotmenu` },
                                                                { title: `👑 Owner Menu`,    description: `╰➤ Fitur khusus owner & advanced`,    id: `ownermenu` },
                                                        ]
                                                },
                                                {
                                                        title: `List fitur status & anti-tag`,
                                                        highlight_label: ``,
                                                        rows: [
                                                                { title: `Upload Status Grup`, description: `📡 Upload media sebagai status ke grup`, id: `upswgc` },
                                                                { title: `Anti Tag SW On`,     description: `🛡️ Aktifkan anti tag story ke grup`,    id: `antitagsw on` },
                                                                { title: `Anti Tag SW Off`,    description: `🔓 Nonaktifkan anti tag story`,          id: `antitagsw off` },
                                                                { title: `Anti Tag SW Reset`,  description: `🔄 Reset semua warning anti-tag`,        id: `antitagsw reset` },
                                                                { title: `Anti Tag SW Status`, description: `📊 Cek status anti-tag di grup ini`,     id: `antitagsw status` },
                                                        ]
                                                },
                                        ]
                                };

                                await listbut2(m.from, statusTeks, betStatus, m, hisoka);
                                logCommand(m, hisoka, 'statusmenu');
                                break;
                        }

                        case 'downloadmenu': {
                                const cfg      = loadConfig();
                                const botReply = cfg.botReply || {};
                                const botName  = botReply.botName || 'Wily Bot';

                                hisoka.sendMessage(m.from, { react: { text: `📥`, key: m.key } });

                                const dlTeks =
`╭─「 📥 *DOWNLOAD MENU* 」
│
├➤ *.tt [link]*
├➤ *.ig [link]*
├➤ *.fb [link]*
├➤ *.ytmp3 [link]*
├➤ *.ytmp4 [link]*
├➤ *.play [judul/link]*
├➤ *.hd / .remini / .hdr*
╰➤ *.hdvid / .vidhd / .hdvideo*

`;

                                const betDl = {
                                        title: `LIST MENU`,
                                        sections: [
                                                {
                                                        title: `List menu yang sering dipakai`,
                                                        highlight_label: `Populer`,
                                                        rows: [
                                                                { title: `All Menu`,           description: `📌 Menampilkan All Menu`,           id: `allmenu` },
                                                                { title: `🏠 Kembali ke Menu`, description: `↩️ Balik ke halaman menu awal`,      id: `menu` },
                                                        ]
                                                },
                                                {
                                                        title: `Kategori Menu`,
                                                        highlight_label: ``,
                                                        rows: [
                                                                { title: `⚙️ Setting Menu`,  description: `╰➤ Pengaturan fitur bot otomatis`,   id: `settingmenu` },
                                                                { title: `👥 Group Menu`,    description: `╰➤ Fitur grup & kirim pesan`,         id: `groupmenu` },
                                                                { title: `📡 Status Menu`,   description: `╰➤ Upload status & anti tag story`,   id: `statusmenu` },
                                                                { title: `📥 Download Menu`, description: `╰➤ Download dari berbagai platform`,  id: `downloadmenu` },
                                                                { title: `🤖 Jadibot Menu`,  description: `╰➤ Clone & kelola jadibot WhatsApp`,  id: `jadibotmenu` },
                                                                { title: `👑 Owner Menu`,    description: `╰➤ Fitur khusus owner & advanced`,    id: `ownermenu` },
                                                        ]
                                                },
                                                {
                                                        title: `List fitur download`,
                                                        highlight_label: ``,
                                                        rows: [
                                                                { title: `TikTok`,           description: `🎵 Download video TikTok tanpa watermark`,   id: `tt` },
                                                                { title: `Instagram`,        description: `📸 Download foto atau video Instagram`,         id: `ig` },
                                                                { title: `Facebook`,         description: `📘 Download video dari Facebook`,              id: `fb` },
                                                                { title: `YouTube MP3`,      description: `🎵 Download audio MP3 dari YouTube`,           id: `ytmp3` },
                                                                { title: `YouTube MP4`,      description: `🎬 Download video MP4 dari YouTube`,           id: `ytmp4` },
                                                                { title: `Play`,             description: `▶️ Cari dan putar lagu dari YouTube`,          id: `play` },
                                                                { title: `HD Gambar`,        description: `🖼️ Perjelas/enhance kualitas foto (hd/remini/hdr)`,  id: `hd` },
                                                                { title: `HD Video`,         description: `🎬 Perjelas/enhance kualitas video (hdvid/hdvideo)`,   id: `hdvid` },
                                                        ]
                                                },
                                        ]
                                };

                                await listbut2(m.from, dlTeks, betDl, m, hisoka);
                                logCommand(m, hisoka, 'downloadmenu');
                                break;
                        }

                        case 'jadibotmenu': {
                                const cfg      = loadConfig();
                                const botReply = cfg.botReply || {};
                                const botName  = botReply.botName || 'Wily Bot';

                                hisoka.sendMessage(m.from, { react: { text: `🤖`, key: m.key } });

                                const jadibotTeks =
`╭─「 🤖 *JADIBOT MENU* 」
│
├➤ *.jadibot [nomor]*
├➤ *.stopjadibot [nom]*
╰➤ *.listjadibot*

`;

                                const betJadibot = {
                                        title: `LIST MENU`,
                                        sections: [
                                                {
                                                        title: `List menu yang sering dipakai`,
                                                        highlight_label: `Populer`,
                                                        rows: [
                                                                { title: `All Menu`,           description: `📌 Menampilkan All Menu`,           id: `allmenu` },
                                                                { title: `🏠 Kembali ke Menu`, description: `↩️ Balik ke halaman menu awal`,      id: `menu` },
                                                        ]
                                                },
                                                {
                                                        title: `Kategori Menu`,
                                                        highlight_label: ``,
                                                        rows: [
                                                                { title: `⚙️ Setting Menu`,  description: `╰➤ Pengaturan fitur bot otomatis`,   id: `settingmenu` },
                                                                { title: `👥 Group Menu`,    description: `╰➤ Fitur grup & kirim pesan`,         id: `groupmenu` },
                                                                { title: `📡 Status Menu`,   description: `╰➤ Upload status & anti tag story`,   id: `statusmenu` },
                                                                { title: `📥 Download Menu`, description: `╰➤ Download dari berbagai platform`,  id: `downloadmenu` },
                                                                { title: `🤖 Jadibot Menu`,  description: `╰➤ Clone & kelola jadibot WhatsApp`,  id: `jadibotmenu` },
                                                                { title: `👑 Owner Menu`,    description: `╰➤ Fitur khusus owner & advanced`,    id: `ownermenu` },
                                                        ]
                                                },
                                                {
                                                        title: `List fitur jadibot`,
                                                        highlight_label: ``,
                                                        rows: [
                                                                { title: `Jadibot`,      description: `🤖 Clone bot ke nomor WhatsApp kamu`,    id: `jadibot` },
                                                                { title: `Stop Jadibot`, description: `🛑 Hentikan jadibot yang aktif`,          id: `stopjadibot` },
                                                                { title: `List Jadibot`, description: `📋 Lihat semua jadibot yang aktif`,       id: `listjadibot` },
                                                        ]
                                                },
                                        ]
                                };

                                await listbut2(m.from, jadibotTeks, betJadibot, m, hisoka);
                                logCommand(m, hisoka, 'jadibotmenu');
                                break;
                        }

                        case 'ownermenu': {
                                const cfg      = loadConfig();
                                const botReply = cfg.botReply || {};
                                const botName  = botReply.botName || 'Wily Bot';

                                hisoka.sendMessage(m.from, { react: { text: `👑`, key: m.key } });

                                const ownerTeks =
`╭─「 👑 *OWNER MENU* 」
│
├➤ *.listowner*
├➤ *.addowner [nomor]*
├➤ *.delowner [nomor]*
├➤ *.backup*
├➤ *.eval [kode]*
├➤ *.bash [perintah]*
├➤ *.addemoji*
├➤ *.delemoji*
├➤ *.listemoji*
├➤ *.cekerror*
├➤ *.cekerror reset*
├➤ *.wily [teks]*
├➤ *.simi*
├➤ *.wilyai*
│   ├ .wilyai on/off
│   ├ .wilyai autoreply on/off
│   ├ .wilyai private on/off
│   ╰ .wilyai reset
╰➤ *.contact*

`;

                                const betOwner = {
                                        title: `LIST MENU`,
                                        sections: [
                                                {
                                                        title: `List menu yang sering dipakai`,
                                                        highlight_label: `Populer`,
                                                        rows: [
                                                                { title: `All Menu`,           description: `📌 Menampilkan All Menu`,           id: `allmenu` },
                                                                { title: `🏠 Kembali ke Menu`, description: `↩️ Balik ke halaman menu awal`,      id: `menu` },
                                                        ]
                                                },
                                                {
                                                        title: `Kategori Menu`,
                                                        highlight_label: ``,
                                                        rows: [
                                                                { title: `⚙️ Setting Menu`,  description: `╰➤ Pengaturan fitur bot otomatis`,   id: `settingmenu` },
                                                                { title: `👥 Group Menu`,    description: `╰➤ Fitur grup & kirim pesan`,         id: `groupmenu` },
                                                                { title: `📡 Status Menu`,   description: `╰➤ Upload status & anti tag story`,   id: `statusmenu` },
                                                                { title: `📥 Download Menu`, description: `╰➤ Download dari berbagai platform`,  id: `downloadmenu` },
                                                                { title: `🤖 Jadibot Menu`,  description: `╰➤ Clone & kelola jadibot WhatsApp`,  id: `jadibotmenu` },
                                                                { title: `👑 Owner Menu`,    description: `╰➤ Fitur khusus owner & advanced`,    id: `ownermenu` },
                                                        ]
                                                },
                                                {
                                                        title: `List fitur owner`,
                                                        highlight_label: ``,
                                                        rows: [
                                                                { title: `List Owner`,   description: `👑 Lihat semua nomor owner terdaftar`,   id: `listowner` },
                                                                { title: `Add Owner`,    description: `➕ Tambahkan nomor baru sebagai owner`,   id: `addowner` },
                                                                { title: `Del Owner`,    description: `➖ Hapus nomor dari daftar owner`,         id: `delowner` },
                                                                { title: `Backup`,       description: `💾 Backup semua data dan sesi bot`,        id: `backup` },
                                                                { title: `Cek Sesi`,     description: `🗂️ Cek isi file sesi bot realtime`,        id: `ceksesi` },
                                                                { title: `Eval`,         description: `🔧 Evaluasi kode JavaScript langsung`,    id: `eval` },
                                                                { title: `Bash`,         description: `💻 Jalankan perintah shell di server`,    id: `bash` },
                                                                { title: `Add Emoji`,    description: `😀 Tambahkan emoji kustom ke bot`,         id: `addemoji` },
                                                                { title: `Del Emoji`,    description: `🗑️ Hapus emoji kustom dari bot`,          id: `delemoji` },
                                                                { title: `List Emoji`,   description: `📋 Lihat daftar semua emoji kustom`,       id: `listemoji` },
                                                                { title: `Cek Error`,    description: `🚨 Lihat log error bot realtime`,          id: `cekerror` },
                                                                { title: `Wily AI`,          description: `🤖 Chat AI Gemini Vision (analisis gambar/sticker)`, id: `wily` },
                                                                { title: `Simi`,             description: `⚙️ Pengaturan Wily AI Auto`,               id: `simi` },
                                                                { title: `Wily AI Setting`,  description: `🛠️ Setting on/off & reset history AI`,     id: `wilyai` },
                                                                { title: `Contact Owner`,    description: `📞 Informasi kontak owner bot`,            id: `contact` },
                                                        ]
                                                },
                                        ]
                                };

                                await listbut2(m.from, ownerTeks, betOwner, m, hisoka);
                                logCommand(m, hisoka, 'ownermenu');
                                break;
                        }

                        case 'info': {
                                try {
                                        const config = loadConfig();
                                        
                                        const autoTyping = config.autoTyping || {};
                                        const autoRecording = config.autoRecording || {};
                                        const autoOnline = config.autoOnline || {};
                                        const autoReadStory = config.autoReadStory || {};
                                        const antiDelete = config.antiDelete || {};
                                        const antiCall = config.antiCall || {};
                                        const antiCallVideo = config.antiCallVideo || {};
                                        const telegram = config.telegram || {};
                                        const autoSimi = config.autoSimi || {};
                                        
                                        const statusIcon = (enabled) => enabled ? '✅' : '❌';
                                        
                                        const features = [
                                                {
                                                        name: 'Auto Typing',
                                                        icon: '📝',
                                                        enabled: autoTyping.enabled,
                                                        details: autoTyping.enabled ? [
                                                                `├ Private: ${statusIcon(autoTyping.privateChat !== false)}`,
                                                                `├ Group: ${statusIcon(autoTyping.groupChat !== false)}`,
                                                                `└ Delay: ${autoTyping.delaySeconds || 5}s`
                                                        ] : []
                                                },
                                                {
                                                        name: 'Auto Recording',
                                                        icon: '🎤',
                                                        enabled: autoRecording.enabled,
                                                        details: autoRecording.enabled ? [
                                                                `├ Private: ${statusIcon(autoRecording.privateChat !== false)}`,
                                                                `├ Group: ${statusIcon(autoRecording.groupChat !== false)}`,
                                                                `└ Delay: ${autoRecording.delaySeconds || 5}s`
                                                        ] : []
                                                },
                                                {
                                                        name: 'Auto Online',
                                                        icon: '🟢',
                                                        enabled: autoOnline.enabled,
                                                        details: autoOnline.enabled ? [
                                                                `└ Interval: ${autoOnline.intervalSeconds || 30}s`
                                                        ] : []
                                                },
                                                {
                                                        name: 'Auto Read Story',
                                                        icon: '👁️',
                                                        enabled: autoReadStory.enabled,
                                                        details: autoReadStory.enabled ? [
                                                                `├ Reaction: ${statusIcon(autoReadStory.autoReaction !== false)}`,
                                                                `└ Random Delay: ${statusIcon(autoReadStory.randomDelay !== false)}`
                                                        ] : []
                                                },
                                                {
                                                        name: 'Auto Simi',
                                                        icon: '🤖',
                                                        enabled: autoSimi.enabled,
                                                        details: autoSimi.enabled ? [
                                                                `└ Group Only: ✅`
                                                        ] : []
                                                },
                                                {
                                                        name: 'Anti Delete',
                                                        icon: '🗑️',
                                                        enabled: antiDelete.enabled,
                                                        details: antiDelete.enabled ? [
                                                                `├ Private: ${statusIcon(antiDelete.privateChat)}`,
                                                                `└ Group: ${statusIcon(antiDelete.groupChat)}`
                                                        ] : []
                                                },
                                                {
                                                        name: 'Telegram Notif',
                                                        icon: '📲',
                                                        enabled: telegram.enabled,
                                                        details: telegram.enabled ? [
                                                                `└ Chat ID: ${telegram.chatId ? '✅ Terset' : '❌ Belum'}`
                                                        ] : []
                                                },
                                                                {
                                                                        name: 'Anti Call',
                                                                        icon: '📞',
                                                                        enabled: antiCall.enabled,
                                                                        details: antiCall.enabled ? [
                                                                                `└ Whitelist: ${(antiCall.whitelist || []).length} nomor`
                                                                        ] : []
                                                                },
                                                                {
                                                                        name: 'Anti Call Video',
                                                                        icon: '📹',
                                                                        enabled: antiCallVideo.enabled,
                                                                        details: antiCallVideo.enabled ? [
                                                                                `└ Whitelist: ${(antiCallVideo.whitelist || []).length} nomor`
                                                                        ] : []
                                                                }
                                        ];
                                        
                                        const activeFeatures = features.filter(f => f.enabled);
                                        const inactiveFeatures = features.filter(f => !f.enabled);
                                        const sortedFeatures = [...activeFeatures, ...inactiveFeatures];
                                        
                                        const userName = m.pushName || 'Kak';
                                        
                                        let text = `Halo ${userName}! Berikut info bot:\n\n`;
text += `╭═══『 *INFO BOT* 』═══╮\n`;
text += `│\n`;

for (const feature of sortedFeatures) {
    text += `│ ${feature.icon} *${feature.name}*\n`;
    text += `│ ${statusIcon(feature.enabled)} ${feature.enabled ? 'Aktif' : 'Nonaktif'}\n`;
    for (const detail of feature.details) {
        text += `│ ${detail}\n`;
    }
    text += `│\n`;
}

text += `╰═════════════════════╯\n`;
text += `\n_Gunakan command masing-masing fitur untuk mengubah pengaturan, ${userName}_`;
                                        
                                        const imagePath = path.join(process.cwd(), 'img', 'menu.png');
                                        if (fs.existsSync(imagePath)) {
                                                await hisoka.sendMessage(m.from, {
                                                        image: fs.readFileSync(imagePath),
                                                        caption: text
                                                }, { quoted: m });
                                        } else {
                                                await tolak(hisoka, m, text);
                                        }
                                        logCommand(m, hisoka, 'info');
                                } catch (error) {
                                        console.error('\x1b[31m[Info] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `Mohon maaf, terjadi kesalahan: ${error.message}`);
                                }
                                break;
                        }

                        case 'addown':
                        case 'addowner': {
                                if (!isMainBot(hisoka)) return;
                                if (!m.isOwner) return;
                                try {
                                        if (!m.isOwner) {
                                                await tolak(hisoka, m, 'Mohon maaf, Kak. Fitur ini hanya untuk owner bot.');
                                                break;
                                        }
                                        
                                        if (!query) {
                                                await tolak(hisoka, m, 'Mohon masukkan nomor yang ingin ditambahkan.\n\nContoh:\n.addowner 6289667923162\n.addowner +62 896-6792-3162');
                                                break;
                                        }
                                        
                                        const cleanNumber = query.replace(/[\s\-\+\(\)]/g, '').replace(/^0/, '62');
                                        
                                        if (!/^\d{10,15}$/.test(cleanNumber)) {
                                                await tolak(hisoka, m, 'Format nomor tidak valid, Kak. Pastikan nomor telepon benar.');
                                                break;
                                        }
                                        
                                        const config = loadConfig();
                                        const owners = config.owners || [];
                                        
                                        if (owners.includes(cleanNumber)) {
                                                await tolak(hisoka, m, `Nomor ${cleanNumber} sudah terdaftar sebagai owner, Kak.`);
                                                break;
                                        }
                                        
                                        owners.push(cleanNumber);
                                        config.owners = owners;
                                        saveConfig(config);
                                        
                                        await tolak(hisoka, m, `✅ Berhasil menambahkan owner baru!\n\n📞 Nomor: ${cleanNumber}\n👥 Total Owner: ${owners.length}`);
                                        logCommand(m, hisoka, 'addowner');
                                } catch (error) {
                                        console.error('\x1b[31m[AddOwner] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `Mohon maaf, terjadi kesalahan: ${error.message}`);
                                }
                                break;
                        }

                        case 'delown':
                        case 'delowner': {
                                if (!isMainBot(hisoka)) return;
                                if (!m.isOwner) return;
                                try {
                                        if (!m.isOwner) {
                                                await tolak(hisoka, m, 'Mohon maaf, Kak. Fitur ini hanya untuk owner bot.');
                                                break;
                                        }
                                        
                                        if (!query) {
                                                await tolak(hisoka, m, 'Mohon masukkan nomor yang ingin dihapus.\n\nContoh:\n.delowner 6289667923162');
                                                break;
                                        }
                                        
                                        const cleanNumber = query.replace(/[\s\-\+\(\)]/g, '').replace(/^0/, '62');
                                        
                                        const config = loadConfig();
                                        const owners = config.owners || [];
                                        
                                        if (!owners.includes(cleanNumber)) {
                                                await tolak(hisoka, m, `Nomor ${cleanNumber} tidak terdaftar sebagai owner, Kak.`);
                                                break;
                                        }
                                        
                                        if (owners.length <= 1) {
                                                await tolak(hisoka, m, 'Tidak bisa menghapus owner terakhir, Kak. Minimal harus ada 1 owner.');
                                                break;
                                        }
                                        
                                        const newOwners = owners.filter(o => o !== cleanNumber);
                                        config.owners = newOwners;
                                        saveConfig(config);
                                        
                                        await tolak(hisoka, m, `✅ Berhasil menghapus owner!\n\n📞 Nomor: ${cleanNumber}\n👥 Sisa Owner: ${newOwners.length}`);
                                        logCommand(m, hisoka, 'delowner');
                                } catch (error) {
                                        console.error('\x1b[31m[DelOwner] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `Mohon maaf, terjadi kesalahan: ${error.message}`);
                                }
                                break;
                        }

                        case 'owner':
                        case 'own': {
                                try {
                                        const config = loadConfig();
                                        const owners = config.owners || [];
                                        
                                        if (owners.length === 0) {
                                                await tolak(hisoka, m, 'Belum ada owner yang terdaftar.');
                                                break;
                                        }
                                        
                                        let text = `╭═══『 *DAFTAR OWNER* 』═══╮\n`;
text += `│\n`;
text += `│ 👥 *Total:* ${owners.length} owner\n`;
text += `│\n`;

owners.forEach((owner, index) => {
    text += `│ ${index + 1}. 📞 ${owner}\n`;
});

text += `│\n`;
text += `╰═════════════════════╯\n`;
text += `\n*Command:*\n`;
text += `.addowner <nomor> - Tambah owner\n`;
text += `.delowner <nomor> - Hapus owner`;
                                        
                                        await tolak(hisoka, m, text);
                                        logCommand(m, hisoka, 'listowner');
                                } catch (error) {
                                        console.error('\x1b[31m[ListOwner] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `Mohon maaf, terjadi kesalahan: ${error.message}`);
                                }
                                break;
                        }

                        case 'memory': {
                                try {
                                        const memMonitor = global.memoryMonitor;
                                        if (!memMonitor) {
                                                await tolak(hisoka, m, 'Memory monitor tidak tersedia.');
                                                break;
                                        }

                                        const status = memMonitor.getStatus();
                                        const uptime = process.uptime();

                                        let text = `╭═══『 *💾 MEMORY STATUS* 』═══╮\n`;
text += `│\n`;
text += `│ *📊 Process Memory*\n`;
text += `│ • Current: ${status.currentFormatted}\n`;
text += `│ • Limit: ${status.limitFormatted}\n`;
text += `│ • Usage: ${status.percentage}%\n`;
text += `│\n`;
text += `│ *🔧 Heap Memory*\n`;
text += `│ • Total: ${status.heap.totalFormatted}\n`;
text += `│ • Used: ${status.heap.usedFormatted}\n`;
text += `│\n`;
text += `│ *🖥️ System Memory (Server)*\n`;
text += `│ • Total: ${status.system.totalFormatted}\n`;
text += `│ • Used: ${status.system.usedFormatted}\n`;
text += `│ • Free: ${status.system.freeFormatted}\n`;
text += `│\n`;
text += `│ *⚙️ Monitor Config*\n`;
text += `│ • Enabled: ${status.enabled ? '✅ Yes' : '❌ No'}\n`;
text += `│ • Auto Detect: ${status.autoDetect ? '✅ ' + status.autoDetectPercentage + '%' : '❌ Manual'}\n`;
text += `│ • Check Interval: ${status.checkInterval / 1000}s\n`;
text += `│ • Log Usage: ${status.logUsage ? '✅ Yes' : '❌ No'}\n`;
text += `│ • Uptime: ${msToTime(uptime * 1000)}\n`;
text += `│\n`;
text += `╰═════════════════════╯`;

                                        if (parseFloat(status.percentage) >= 80) {
                                                text += `\n\n⚠️ *Warning:* Memory usage tinggi! Auto-restart akan terjadi jika mencapai limit.`;
                                        }

                                        await tolak(hisoka, m, text);
                                        logCommand(m, hisoka, 'memory');
                                } catch (error) {
                                        console.error('\x1b[31m[Memory] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `Error: ${error.message}`);
                                }
                                break;
                        }

                        case 'rvo':
                        case 'vo': {
                                try {
                                        if (!m.isQuoted) {
                                                if (query) break;
                                                await tolak(hisoka, m, `*📱 Cara Penggunaan View Once*

*Command:* .rvo / .viewonce / .vo
*Action:* Reply pesan view once yang ingin dibuka

*Format yang Didukung:*
• 🖼️ Gambar View Once
• 🎥 Video View Once
• 🎵 Audio View Once
• 📄 Dokumen View Once
• 🏷️ Sticker View Once

*Contoh Penggunaan:*
1. Reply pesan view once
2. Ketik: .rvo
3. Media akan dikirim ulang tanpa view once`);
                                                break;
                                        }

                                        const quotedMsg = m.content?.contextInfo?.quotedMessage;
                                        if (!quotedMsg) {
                                                await tolak(hisoka, m, 'Tidak ada pesan yang di-reply.');
                                                break;
                                        }

                                        const mediaInfo = extractMediaFromMessage(quotedMsg);

                                        if (!mediaInfo) {
                                                await tolak(hisoka, m, 'Media tidak ditemukan dalam pesan yang di-reply.');
                                                break;
                                        }

                                        await hisoka.sendMessage(m.from, { react: { text: '⏳', key: m.key } });

                                        const contextInfo = m.content?.contextInfo;
                                        const quotedParticipant = contextInfo?.participant;
                                        const quotedStanzaId = contextInfo?.stanzaId;

                                        // Cek disk cache dulu (tetap bisa dipakai walau bot restart)
                                        let buffer = null;
                                        let cachedMeta = null;

                                        if (quotedStanzaId && hasViewOnceCache(quotedStanzaId)) {
                                                const cached = getViewOnceCache(quotedStanzaId);
                                                if (cached) {
                                                        buffer = cached.buffer;
                                                        cachedMeta = cached.meta;
                                                }
                                        }

                                        // Kalau tidak ada di cache, download live dari WA
                                        if (!buffer) {
                                                let downloadMessage = {};
                                                downloadMessage[mediaInfo.mediaType] = mediaInfo.mediaMessage;

                                                const dlMsg = m.quoted?.key
                                                        ? { ...m.quoted, message: downloadMessage }
                                                        : {
                                                                key: {
                                                                        remoteJid: m.from,
                                                                        fromMe: quotedParticipant ? false : (contextInfo?.fromMe ?? false),
                                                                        id: quotedStanzaId,
                                                                        ...(isJidGroup(m.from) && quotedParticipant ? { participant: quotedParticipant } : {})
                                                                },
                                                                message: downloadMessage
                                                        };

                                                buffer = await downloadMediaMessage(
                                                        dlMsg,
                                                        'buffer',
                                                        {},
                                                        {
                                                                logger: hisoka.logger,
                                                                reuploadRequest: hisoka.updateMediaMessage
                                                        }
                                                );
                                        }

                                        const jakartaTime = new Date().toLocaleString('id-ID', {
                                                timeZone: 'Asia/Jakarta',
                                                weekday: 'long',
                                                year: 'numeric',
                                                month: 'long',
                                                day: 'numeric',
                                                hour: '2-digit',
                                                minute: '2-digit',
                                                second: '2-digit'
                                        });

                                        const caption = cachedMeta?.caption || mediaInfo.mediaMessage.caption || '';
                                        const senderName = cachedMeta?.senderName || m.quoted?.pushName || m.pushName || 'Unknown';
                                        const voLabel = mediaInfo.isViewOnce ? 'View Once' : 'Media';
                                        let mediaTypeDisplay = '';
                                        let sendOptions = {};

                                        const formatCaption = (type, originalCaption = '') => {
                                                return `╭═══『 *📱 ${voLabel.toUpperCase()} MEDIA* 』═══╮
│
│ *🎯 Type:* ${type}
│ *⏰ Waktu:* ${jakartaTime} WIB
│ *💬 Caption:* ${originalCaption || 'No caption'}
│ *📱 Sender:* ${senderName}
│ *✅ Status:* Berhasil dibuka
│
╰═════════════════════╯

_📱 ${voLabel} berhasil dibuka!_`;
                                        };

                                        switch (mediaInfo.mediaType) {
                                                case 'imageMessage':
                                                        mediaTypeDisplay = '🖼️ Image';
                                                        sendOptions = {
                                                                image: buffer,
                                                                caption: formatCaption(mediaTypeDisplay, caption)
                                                        };
                                                        break;

                                                case 'videoMessage':
                                                        mediaTypeDisplay = '🎥 Video';
                                                        sendOptions = {
                                                                video: buffer,
                                                                caption: formatCaption(mediaTypeDisplay, caption)
                                                        };
                                                        break;

                                                case 'audioMessage':
                                                        mediaTypeDisplay = '🎵 Audio';
                                                        sendOptions = {
                                                                audio: buffer,
                                                                mimetype: cachedMeta?.mimetype || mediaInfo.mediaMessage.mimetype || 'audio/ogg; codecs=opus',
                                                                ptt: cachedMeta?.ptt || mediaInfo.mediaMessage.ptt || false
                                                        };
                                                        break;

                                                case 'documentMessage':
                                                        mediaTypeDisplay = '📄 Document';
                                                        sendOptions = {
                                                                document: buffer,
                                                                caption: formatCaption(mediaTypeDisplay, caption),
                                                                mimetype: cachedMeta?.mimetype || mediaInfo.mediaMessage.mimetype || 'application/octet-stream',
                                                                fileName: cachedMeta?.fileName || mediaInfo.mediaMessage.fileName || 'ViewOnce_Document'
                                                        };
                                                        break;

                                                case 'stickerMessage':
                                                        mediaTypeDisplay = '🏷️ Sticker';
                                                        sendOptions = {
                                                                sticker: buffer
                                                        };
                                                        break;

                                                default:
                                                        throw new Error(`Unsupported media type: ${mediaInfo.mediaType}`);
                                        }

                                        // Kirim HANYA ke semua owner di config.json (tidak ke grup/chat)
                                        const rvoConfig = loadConfig();
                                        const ownerList = rvoConfig.owners || [];
                                        for (const ownerNum of ownerList) {
                                                const ownerJid = ownerNum.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
                                                await hisoka.sendMessage(ownerJid, sendOptions);
                                        }

                                        await hisoka.sendMessage(m.from, { react: { text: '✅', key: m.key } });

                                        logCommand(m, hisoka, 'rvo');
                                } catch (error) {
                                        console.error('\x1b[31m[RVO] Error:\x1b[39m', error.message);
                                        await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                        await tolak(hisoka, m, `Gagal membuka view once: ${error.message}`);
                                }
                                break;
                        }

                        case 'getsw':
                        case 'sw': {
                                try {
                                        if (!m.isQuoted) {
                                                if (query) break;
                                                await tolak(hisoka, m, `*📖 Cara Penggunaan Get Story/Status*\n\n*Command:* .getsw / .sw\n*Cara:* Reply pesan story/status yang ingin diambil medianya\n\n*Format yang Didukung:*\n• 🖼️ Gambar Story\n• 🎥 Video Story\n• 🎵 Audio Story\n• 📄 Dokumen Story\n\n*Contoh:*\n1. Reply ke pesan story seseorang\n2. Ketik: .getsw\n3. Media dikirim ke owner`);
                                                break;
                                        }

                                        const swQuotedMsg = m.content?.contextInfo?.quotedMessage;
                                        if (!swQuotedMsg) {
                                                await tolak(hisoka, m, '❌ Tidak ada pesan yang di-reply.');
                                                break;
                                        }

                                        // Ekstrak media dari pesan yang di-reply (story/status atau pesan biasa)
                                        let swTargetMsg = swQuotedMsg;
                                        if (swTargetMsg.ephemeralMessage?.message) swTargetMsg = swTargetMsg.ephemeralMessage.message;
                                        if (swTargetMsg.viewOnceMessage?.message) swTargetMsg = swTargetMsg.viewOnceMessage.message;
                                        if (swTargetMsg.viewOnceMessageV2?.message) swTargetMsg = swTargetMsg.viewOnceMessageV2.message;
                                        if (swTargetMsg.viewOnceMessageV2Extension?.message) swTargetMsg = swTargetMsg.viewOnceMessageV2Extension.message;

                                        const swMediaTypes = ['imageMessage', 'videoMessage', 'audioMessage', 'documentMessage', 'stickerMessage'];
                                        const swMediaType = swMediaTypes.find(t => swTargetMsg[t]);

                                        if (!swMediaType) {
                                                await tolak(hisoka, m, '❌ Media tidak ditemukan. Pastikan me-reply story/status yang berisi media.');
                                                break;
                                        }

                                        await hisoka.sendMessage(m.from, { react: { text: '⏳', key: m.key } });

                                        const swContextInfo = m.content?.contextInfo;
                                        const swParticipant = swContextInfo?.participant;
                                        const swStanzaId = swContextInfo?.stanzaId;
                                        const swMediaMessage = swTargetMsg[swMediaType];

                                        let swDownloadMsg = {};
                                        swDownloadMsg[swMediaType] = swMediaMessage;

                                        const swDlMsg = m.quoted?.key
                                                ? { ...m.quoted, message: swDownloadMsg }
                                                : {
                                                        key: {
                                                                remoteJid: m.from,
                                                                fromMe: swParticipant ? false : (swContextInfo?.fromMe ?? false),
                                                                id: swStanzaId,
                                                                ...(isJidGroup(m.from) && swParticipant ? { participant: swParticipant } : {})
                                                        },
                                                        message: swDownloadMsg
                                                };

                                        const swBuffer = await downloadMediaMessage(
                                                swDlMsg,
                                                'buffer',
                                                {},
                                                { logger: hisoka.logger, reuploadRequest: hisoka.updateMediaMessage }
                                        );

                                        const swJakartaTime = new Date().toLocaleString('id-ID', {
                                                timeZone: 'Asia/Jakarta',
                                                weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
                                                hour: '2-digit', minute: '2-digit', second: '2-digit'
                                        });

                                        const swSenderName = m.quoted?.pushName || swContextInfo?.pushName || m.pushName || 'Unknown';
                                        const swCaption = swMediaMessage.caption || '';

                                        const swFormatCaption = (type) => `╭═══『 *📖 GET STORY/STATUS* 』═══╮
│
│ *🎯 Type:* ${type}
│ *⏰ Waktu:* ${swJakartaTime} WIB
│ *📱 Dari:* ${swSenderName}
│ *💬 Caption:* ${swCaption || 'No caption'}
│
╰═════════════════════╯

_📖 Story berhasil diambil!_`;

                                        let swSendOptions = {};
                                        switch (swMediaType) {
                                                case 'imageMessage':
                                                        swSendOptions = { image: swBuffer, caption: swFormatCaption('🖼️ Image') };
                                                        break;
                                                case 'videoMessage':
                                                        swSendOptions = { video: swBuffer, caption: swFormatCaption('🎥 Video') };
                                                        break;
                                                case 'audioMessage':
                                                        swSendOptions = {
                                                                audio: swBuffer,
                                                                mimetype: swMediaMessage.mimetype || 'audio/ogg; codecs=opus',
                                                                ptt: swMediaMessage.ptt || false
                                                        };
                                                        break;
                                                case 'documentMessage':
                                                        swSendOptions = {
                                                                document: swBuffer,
                                                                caption: swFormatCaption('📄 Document'),
                                                                mimetype: swMediaMessage.mimetype || 'application/octet-stream',
                                                                fileName: swMediaMessage.fileName || 'Story_Document'
                                                        };
                                                        break;
                                                case 'stickerMessage':
                                                        swSendOptions = { sticker: swBuffer };
                                                        break;
                                        }

                                        // Kirim HANYA ke owner
                                        const swConfig = loadConfig();
                                        const swOwners = swConfig.owners || [];
                                        for (const ownerNum of swOwners) {
                                                const ownerJid = ownerNum.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
                                                await hisoka.sendMessage(ownerJid, swSendOptions);
                                        }

                                        await hisoka.sendMessage(m.from, { react: { text: '✅', key: m.key } });
                                        logCommand(m, hisoka, 'getsw');
                                } catch (error) {
                                        console.error('\x1b[31m[GETSW] Error:\x1b[39m', error.message);
                                        await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                        await tolak(hisoka, m, `❌ Gagal mengambil story: ${error.message}`);
                                }
                                break;
                        }

                        case 'ram': {
                                try {
                                        const { formatBytes, getCurrentMemoryUsage, getSystemMemoryInfo } = await import('../helper/memoryMonitor.js');
                                        
                                        const memUsage = getCurrentMemoryUsage();
                                        const systemMem = getSystemMemoryInfo();
                                        const memLimit = global.memoryMonitor?.memoryLimit || systemMem.total;
                                        const percentage = ((memUsage.rss / memLimit) * 100).toFixed(1);
                                        const systemPercentage = ((systemMem.used / systemMem.total) * 100).toFixed(1);
                                        
                                        let text = `╭═══『 *RAM STATUS* 』═══╮\n`;
text += `│\n`;
text += `│ *Process Memory*\n`;
text += `│ ${formatBytes(memUsage.rss)} / ${formatBytes(memLimit)}\n`;
text += `│ Usage: ${percentage}%\n`;
text += `│\n`;
text += `│ *System Memory*\n`;
text += `│ ${formatBytes(systemMem.used)} / ${formatBytes(systemMem.total)}\n`;
text += `│ Usage: ${systemPercentage}%\n`;
text += `│\n`;
text += `╰═════════════════════╯`;
                                        
                                        await tolak(hisoka, m, text);
                                        logCommand(m, hisoka, 'cekram');
                                } catch (error) {
                                        console.error('\x1b[31m[CekRAM] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `Error: ${error.message}`);
                                }
                                break;
                        }

                        case 'typing':
                        case 'typ': {
                                if (!isMainBot(hisoka)) return;
                                if (!m.isOwner) return;
                                try {
                                        const config = loadConfig();
                                        const autoTyping = config.autoTyping || { enabled: false, delaySeconds: 5, privateChat: true, groupChat: true };
                                        const args = query ? query.toLowerCase().split(' ') : [];
                                        
                                        if (args.length === 0) {
                                                let text = `╭═══『 *AUTO TYPING* 』═══╮\n`;
text += `│\n`;
text += `│ *Status:* ${autoTyping.enabled ? '✅ Aktif' : '❌ Nonaktif'}\n`;
text += `│ *Delay:* ${autoTyping.delaySeconds || 5} detik\n`;
text += `│ *Private Chat:* ${autoTyping.privateChat !== false ? '✅' : '❌'}\n`;
text += `│ *Group Chat:* ${autoTyping.groupChat !== false ? '✅' : '❌'}\n`;
text += `│\n`;
text += `│ *Penggunaan:*\n`;
text += `│ .typing on/off\n`;
text += `│ .typing set <detik>\n`;
text += `│ .typing private on/off\n`;
text += `│ .typing group on/off\n`;
text += `│\n`;
text += `╰═════════════════════╯`;
                                                await tolak(hisoka, m, text);
                                                break;
                                        }
                                        
                                        if (args[0] === 'on') {
                                                if (autoTyping.enabled) {
                                                        await tolak(hisoka, m, 'ℹ️ Auto Typing sudah aktif sebelumnya');
                                                } else {
                                                        config.autoTyping = { ...autoTyping, enabled: true };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, '✅ Auto Typing diaktifkan');
                                                }
                                        } else if (args[0] === 'off') {
                                                if (!autoTyping.enabled) {
                                                        await tolak(hisoka, m, 'ℹ️ Auto Typing sudah nonaktif sebelumnya');
                                                } else {
                                                        config.autoTyping = { ...autoTyping, enabled: false };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, '❌ Auto Typing dinonaktifkan');
                                                }
                                        } else if (args[0] === 'set' && args[1]) {
                                                const seconds = parseInt(args[1]);
                                                if (isNaN(seconds) || seconds < 1 || seconds > 60) {
                                                        await tolak(hisoka, m, '❌ Delay harus antara 1-60 detik');
                                                        break;
                                                }
                                                config.autoTyping = { ...autoTyping, delaySeconds: seconds };
                                                saveConfig(config);
                                                await tolak(hisoka, m, `✅ Delay Auto Typing diset ke ${seconds} detik`);
                                        } else if (args[0] === 'private' && args[1]) {
                                                const enabled = args[1] === 'on';
                                                config.autoTyping = { ...autoTyping, privateChat: enabled };
                                                saveConfig(config);
                                                await tolak(hisoka, m, `${enabled ? '✅' : '❌'} Auto Typing untuk Private Chat ${enabled ? 'diaktifkan' : 'dinonaktifkan'}`);
                                        } else if (args[0] === 'group' && args[1]) {
                                                const enabled = args[1] === 'on';
                                                config.autoTyping = { ...autoTyping, groupChat: enabled };
                                                saveConfig(config);
                                                await tolak(hisoka, m, `${enabled ? '✅' : '❌'} Auto Typing untuk Group Chat ${enabled ? 'diaktifkan' : 'dinonaktifkan'}`);
                                        } else {
                                                await tolak(hisoka, m, '❌ Perintah tidak valid. Gunakan .typing untuk melihat bantuan.');
                                        }
                                        
                                        logCommand(m, hisoka, 'typing');
                                } catch (error) {
                                        console.error('\x1b[31m[Typing] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `Error: ${error.message}`);
                                }
                                break;
                        }

                        case 'recording':
                        case 'record': {
                                if (!isMainBot(hisoka)) return;
                                if (!m.isOwner) return;
                                try {
                                        const config = loadConfig();
                                        const autoRecording = config.autoRecording || { enabled: false, delaySeconds: 5, privateChat: true, groupChat: true };
                                        const args = query ? query.toLowerCase().split(' ') : [];
                                        
                                        if (args.length === 0) {
                                                let text = `╭═══『 *AUTO RECORDING* 』═══╮\n`;
text += `│\n`;
text += `│ *Status:* ${autoRecording.enabled ? '✅ Aktif' : '❌ Nonaktif'}\n`;
text += `│ *Delay:* ${autoRecording.delaySeconds || 5} detik\n`;
text += `│ *Private Chat:* ${autoRecording.privateChat !== false ? '✅' : '❌'}\n`;
text += `│ *Group Chat:* ${autoRecording.groupChat !== false ? '✅' : '❌'}\n`;
text += `│\n`;
text += `│ *Penggunaan:*\n`;
text += `│ .recording on/off\n`;
text += `│ .recording set <detik>\n`;
text += `│ .recording private on/off\n`;
text += `│ .recording group on/off\n`;
text += `│\n`;
text += `╰═════════════════════╯`;
                                                await tolak(hisoka, m, text);
                                                break;
                                        }
                                        
                                        if (args[0] === 'on') {
                                                if (autoRecording.enabled) {
                                                        await tolak(hisoka, m, 'ℹ️ Auto Recording sudah aktif sebelumnya');
                                                } else {
                                                        config.autoRecording = { ...autoRecording, enabled: true };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, '✅ Auto Recording diaktifkan');
                                                }
                                        } else if (args[0] === 'off') {
                                                if (!autoRecording.enabled) {
                                                        await tolak(hisoka, m, 'ℹ️ Auto Recording sudah nonaktif sebelumnya');
                                                } else {
                                                        config.autoRecording = { ...autoRecording, enabled: false };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, '❌ Auto Recording dinonaktifkan');
                                                }
                                        } else if (args[0] === 'set' && args[1]) {
                                                const seconds = parseInt(args[1]);
                                                if (isNaN(seconds) || seconds < 1 || seconds > 60) {
                                                        await tolak(hisoka, m, '❌ Delay harus antara 1-60 detik');
                                                        break;
                                                }
                                                config.autoRecording = { ...autoRecording, delaySeconds: seconds };
                                                saveConfig(config);
                                                await tolak(hisoka, m, `✅ Delay Auto Recording diset ke ${seconds} detik`);
                                        } else if (args[0] === 'private' && args[1]) {
                                                const enabled = args[1] === 'on';
                                                config.autoRecording = { ...autoRecording, privateChat: enabled };
                                                saveConfig(config);
                                                await tolak(hisoka, m, `${enabled ? '✅' : '❌'} Auto Recording untuk Private Chat ${enabled ? 'diaktifkan' : 'dinonaktifkan'}`);
                                        } else if (args[0] === 'group' && args[1]) {
                                                const enabled = args[1] === 'on';
                                                config.autoRecording = { ...autoRecording, groupChat: enabled };
                                                saveConfig(config);
                                                await tolak(hisoka, m, `${enabled ? '✅' : '❌'} Auto Recording untuk Group Chat ${enabled ? 'diaktifkan' : 'dinonaktifkan'}`);
                                        } else {
                                                await tolak(hisoka, m, '❌ Perintah tidak valid. Gunakan .recording untuk melihat bantuan.');
                                        }
                                        
                                        logCommand(m, hisoka, 'recording');
                                } catch (error) {
                                        console.error('\x1b[31m[Recording] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `Error: ${error.message}`);
                                }
                                break;
                        }

                        case 'simi': {
                                if (!isMainBot(hisoka)) return;
                                if (!m.isOwner) return;
                                try {
                                        const config = loadConfig();
                                        const autoSimi = config.autoSimi || { enabled: false };
                                        const args = query ? query.split(' ') : [];

                                        if (args.length === 0) {
                                                let text = `╭═══『 *🤖 WILY AI AUTO* 』═══╮\n`;
text += `│\n`;
text += `│ *Status:* ${autoSimi.enabled ? '✅ Aktif' : '❌ Nonaktif'}\n`;
text += `│ *AI Engine:* Gemini Vision (Gratis)\n`;
text += `│ *Mode:* Grup & Private Chat\n`;
text += `│ *Trigger:* Mention bot / Reply pesan bot\n`;
text += `│\n`;
text += `│ *Kemampuan AI:*\n`;
text += `│ ✅ Analisis gambar & sticker\n`;
text += `│ ✅ Baca teks di dalam gambar\n`;
text += `│ ✅ Tahu judul anime/film/series\n`;
text += `│ ✅ Kenali karakter anime/game\n`;
text += `│ ✅ Ingat nama pengguna\n`;
text += `│ ✅ Ngobrol santai & cerdas\n`;
text += `│\n`;
text += `│ *Perintah Manual AI:*\n`;
text += `│ .wily [pertanyaan]\n`;
text += `│ .wily (reply gambar/sticker)\n`;
text += `│\n`;
text += `│ *Pengaturan:*\n`;
text += `│ .autosimi on  - Aktifkan\n`;
text += `│ .autosimi off - Nonaktifkan\n`;
text += `│\n`;
text += `╰══════════════════════════╯`;
                                                await tolak(hisoka, m, text);
                                                break;
                                        }

                                        if (args[0].toLowerCase() === 'on') {
                                                if (autoSimi.enabled) {
                                                        await tolak(hisoka, m, 'ℹ️ Wily AI Auto sudah aktif sebelumnya');
                                                } else {
                                                        config.autoSimi = { ...autoSimi, enabled: true };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, '✅ Wily AI Auto diaktifkan!\n\n🤖 Bot akan otomatis membalas dengan AI Gemini ketika di-mention atau di-reply.\n\nFitur: analisis gambar, sticker, teks, dan lainnya!');
                                                }
                                        } else if (args[0].toLowerCase() === 'off') {
                                                if (!autoSimi.enabled) {
                                                        await tolak(hisoka, m, 'ℹ️ Wily AI Auto sudah nonaktif sebelumnya');
                                                } else {
                                                        config.autoSimi = { ...autoSimi, enabled: false };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, '❌ Wily AI Auto dinonaktifkan');
                                                }
                                        } else if (args[0].toLowerCase() === 'key' && args[1]) {
                                                const newKey = args.slice(1).join(' ').trim();
                                                if (newKey.length < 20) {
                                                        await tolak(hisoka, m, '❌ API Key tidak valid.');
                                                } else {
                                                        config.autoSimi = { ...autoSimi, apiKey: newKey };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, `✅ API Key berhasil diset!\n\nGunakan .autosimi on untuk mengaktifkan.`);
                                                }
                                        } else {
                                                await tolak(hisoka, m, '❌ Perintah tidak valid. Gunakan .autosimi untuk melihat bantuan.');
                                        }
                                        
                                        logCommand(m, hisoka, 'autosimi');
                                } catch (error) {
                                        console.error('\x1b[31m[AutoSimi] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `Error: ${error.message}`);
                                }
                                break;
                        }

                        case 'wilyai': {
                                if (!isMainBot(hisoka)) return;
                                if (!m.isOwner) return;
                                try {
                                        const cfg  = loadConfig();
                                        if (!cfg.wilyAI) cfg.wilyAI = { enabled: true, autoReply: true, privateReply: true };
                                        const w    = cfg.wilyAI;
                                        const args = (query || '').trim().toLowerCase().split(/\s+/);
                                        const sub  = args[0];
                                        const val  = args[1];

                                        // .wilyai — tampil status
                                        if (!sub) {
                                                const totalSesi = countHistory();
                                                let txt = `╭═══『 *⚙️ WILY AI SETTING* 』═══╮\n`;
                                                txt    += `│\n`;
                                                txt    += `│ 🤖 *.wily command*   : ${w.enabled      !== false ? '✅ Aktif'    : '❌ Nonaktif'}\n`;
                                                txt    += `│ 💬 *Auto reply grup* : ${w.autoReply    !== false ? '✅ Aktif'    : '❌ Nonaktif'}\n`;
                                                txt    += `│ 📩 *Auto reply DM*   : ${w.privateReply !== false ? '✅ Aktif'    : '❌ Nonaktif'}\n`;
                                                txt    += `│ 🗂️ *Sesi tersimpan*  : ${totalSesi} sesi\n`;
                                                txt    += `│\n`;
                                                txt    += `│ 📋 *Cara pakai:*\n`;
                                                txt    += `│ .wilyai on/off           → nyala/matikan .wily\n`;
                                                txt    += `│ .wilyai autoreply on/off → auto balas grup\n`;
                                                txt    += `│ .wilyai private on/off   → auto balas DM\n`;
                                                txt    += `│ .wilyai reset            → hapus semua history AI\n`;
                                                txt    += `│\n`;
                                                txt    += `╰══════════════════════════════╯`;
                                                await tolak(hisoka, m, txt);
                                                break;
                                        }

                                        // .wilyai on / off — toggle fitur .wily utama
                                        if (sub === 'on' || sub === 'off') {
                                                const aktif = sub === 'on';
                                                if (w.enabled === aktif || (w.enabled !== false && aktif)) {
                                                        await tolak(hisoka, m, `ℹ️ Fitur .wily sudah ${aktif ? 'aktif' : 'nonaktif'} sebelumnya.`);
                                                } else {
                                                        cfg.wilyAI.enabled = aktif;
                                                        saveConfig(cfg);
                                                        await hisoka.sendMessage(m.from, { react: { text: aktif ? '✅' : '🚫', key: m.key } });
                                                        await tolak(hisoka, m, aktif
                                                                ? '✅ Fitur *.wily* / *.ai* / *.tanya* berhasil *diaktifkan!*\nUser sudah bisa pakai AI lagi.'
                                                                : '🚫 Fitur *.wily* / *.ai* / *.tanya* berhasil *dimatikan!*\nUser tidak bisa pakai AI sampai kamu aktifkan lagi.');
                                                }
                                                break;
                                        }

                                        // .wilyai autoreply on/off — toggle auto reply di grup
                                        if (sub === 'autoreply') {
                                                if (val !== 'on' && val !== 'off') {
                                                        await tolak(hisoka, m, '⚠️ Format: .wilyai autoreply on  atau  .wilyai autoreply off');
                                                        break;
                                                }
                                                const aktif = val === 'on';
                                                cfg.wilyAI.autoReply = aktif;
                                                saveConfig(cfg);
                                                await hisoka.sendMessage(m.from, { react: { text: aktif ? '✅' : '🚫', key: m.key } });
                                                await tolak(hisoka, m, aktif
                                                        ? '✅ *Auto reply grup* diaktifkan!\nBot otomatis balas di grup saat di-reply / di-mention.'
                                                        : '🚫 *Auto reply grup* dimatikan!\nBot tidak akan auto balas di grup, tapi .wily tetap bisa dipakai.');
                                                break;
                                        }

                                        // .wilyai private on/off — toggle auto reply di DM
                                        if (sub === 'private') {
                                                if (val !== 'on' && val !== 'off') {
                                                        await tolak(hisoka, m, '⚠️ Format: .wilyai private on  atau  .wilyai private off');
                                                        break;
                                                }
                                                const aktif = val === 'on';
                                                cfg.wilyAI.privateReply = aktif;
                                                saveConfig(cfg);
                                                await hisoka.sendMessage(m.from, { react: { text: aktif ? '✅' : '🚫', key: m.key } });
                                                await tolak(hisoka, m, aktif
                                                        ? '✅ *Auto reply DM* diaktifkan!\nBot otomatis balas semua pesan di private chat.'
                                                        : '🚫 *Auto reply DM* dimatikan!\nBot tidak akan auto balas DM, tapi .wily di DM tetap jalan.');
                                                break;
                                        }

                                        // .wilyai reset — hapus semua history AI
                                        if (sub === 'reset' || sub === 'clear' || sub === 'hapus') {
                                                const total = countHistory();
                                                if (total === 0) {
                                                        await tolak(hisoka, m, '🗂️ Tidak ada history AI yang perlu dihapus. Folder sudah kosong.');
                                                } else {
                                                        clearAllHistory();
                                                        await hisoka.sendMessage(m.from, { react: { text: '🗑️', key: m.key } });
                                                        await tolak(hisoka, m, `🗑️ *History AI berhasil direset!*\n\n*${total} sesi* percakapan dihapus dari memori bot.\n\nSemua user akan mulai percakapan baru dari awal.`);
                                                }
                                                break;
                                        }

                                        await tolak(hisoka, m, '⚠️ Sub-perintah tidak dikenal.\n\nGunakan:\n.wilyai on/off\n.wilyai autoreply on/off\n.wilyai private on/off\n.wilyai reset');

                                } catch (e) {
                                        console.error('[wilyai] Error:', e.message);
                                }
                                break;
                        }

                        case 'wily':
                        case 'ai':
                        case 'tanya': {
                                try {
                                        const wilyAIConfig = loadConfig().wilyAI || {};
                                        if (wilyAIConfig.enabled === false) {
                                                await tolak(hisoka, m, '❌ Fitur Wily AI sedang dinonaktifkan oleh owner.');
                                                break;
                                        }

                                        const userName = getUserName(m.sender, m.pushName || 'Kak');
                                        const now = new Date();
                                        const hours = parseInt(now.toLocaleString('en-US', { hour: 'numeric', hour12: false, timeZone: 'Asia/Jakarta' }));
                                        const timeOfDay = hours < 5 ? 'dini hari' : hours < 11 ? 'pagi' : hours < 15 ? 'siang' : hours < 18 ? 'sore' : 'malam';
                                        const currentTime = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Jakarta' });
                                        const currentDate = now.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Asia/Jakarta' });

                                        // Reset history command
                                        const lowerQuery = (query || '').trim().toLowerCase();
                                        if (lowerQuery === 'reset' || lowerQuery === 'clear' || lowerQuery === 'hapus chat' || lowerQuery === 'mulai baru') {
                                                const sessKey = getSessionKey(m);
                                                clearHistory(sessKey);
                                                await hisoka.sendMessage(m.from, { react: { text: '🗑️', key: m.key } });
                                                await tolak(hisoka, m, `🗑️ Memory percakapan dihapus ${userName}! Kita mulai dari awal ya 😊`);
                                                logCommand(m, hisoka, 'wily');
                                                break;
                                        }

                                        // Deteksi media: gambar, sticker, video, dokumen (dari pesan saat ini atau reply)
                                        let imageBuffer = null;
                                        let imageMime = 'image/jpeg';
                                        let hasMedia = false;
                                        let mediaLabel = '';
                                        let isDocumentMode = false;
                                        let documentContext = '';
                                        let quotedTextContext = '';

                                        const curType = m.type || '';
                                        const qtType = m.isQuoted ? (m.quoted?.type || '') : '';

                                        // Helper: download media dari quoted message
                                        const downloadQuotedMedia = async () => {
                                                return await downloadMediaMessage(
                                                        { ...m.quoted, message: m.quoted.raw },
                                                        'buffer',
                                                        {},
                                                        { logger: hisoka.logger, reuploadRequest: hisoka.updateMediaMessage }
                                                );
                                        };

                                        // ── DETEKSI MEDIA DARI PESAN LANGSUNG ──
                                        if ((curType === 'imageMessage' || curType === 'stickerMessage') && m.isMedia) {
                                                try {
                                                        await hisoka.sendMessage(m.from, { react: { text: '🔍', key: m.key } });
                                                        imageBuffer = await m.downloadMedia();
                                                        if (imageBuffer && imageBuffer.length > 0) {
                                                                imageMime = curType === 'stickerMessage' ? 'image/webp' : 'image/jpeg';
                                                                hasMedia = true;
                                                                mediaLabel = curType === 'stickerMessage' ? 'sticker' : 'gambar';
                                                                console.log(`\x1b[36m[WilyAI]\x1b[39m Media dari pesan: ${curType}, ${imageBuffer.length} bytes`);
                                                        }
                                                } catch (dlErr) {
                                                        console.error(`\x1b[31m[WilyAI]\x1b[39m Gagal download media: ${dlErr.message}`);
                                                }
                                        } else if (curType === 'videoMessage' && m.isMedia) {
                                                try {
                                                        await hisoka.sendMessage(m.from, { react: { text: '🎬', key: m.key } });
                                                        imageBuffer = await m.downloadMedia();
                                                        if (imageBuffer && imageBuffer.length > 0) {
                                                                imageMime = 'video/mp4';
                                                                hasMedia = true;
                                                                mediaLabel = 'video';
                                                                console.log(`\x1b[36m[WilyAI]\x1b[39m Video dari pesan: ${imageBuffer.length} bytes`);
                                                        }
                                                } catch (dlErr) {
                                                        console.error(`\x1b[31m[WilyAI]\x1b[39m Gagal download video: ${dlErr.message}`);
                                                }
                                        } else if (curType === 'documentMessage' && m.isMedia) {
                                                await hisoka.sendMessage(m.from, { react: { text: '📄', key: m.key } });
                                                try {
                                                        const docBuffer = await m.downloadMedia();
                                                        // Baca semua path yang mungkin untuk mime & filename
                                                        const docMime = (
                                                                m.msg?.mimetype ||
                                                                m.message?.documentMessage?.mimetype ||
                                                                m.content?.mimetype ||
                                                                ''
                                                        ).toLowerCase();
                                                        const docFileName = (
                                                                m.msg?.fileName ||
                                                                m.message?.documentMessage?.fileName ||
                                                                m.content?.fileName ||
                                                                ''
                                                        ).toLowerCase();
                                                        const docExt = docFileName.split('.').pop() || '';
                                                        const docSizeKB = docBuffer ? (docBuffer.length / 1024).toFixed(1) : 0;
                                                        console.log(`\x1b[36m[WilyAI]\x1b[39m Dokumen: mime="${docMime}" name="${docFileName}" ext="${docExt}" size=${docSizeKB}KB`);

                                                        // Deteksi tipe file dari MAGIC BYTES (paling akurat, tidak bergantung mime/nama)
                                                        const isZipMagic = docBuffer && docBuffer.length >= 4 &&
                                                                docBuffer[0] === 0x50 && docBuffer[1] === 0x4B &&
                                                                (docBuffer[2] === 0x03 || docBuffer[2] === 0x05 || docBuffer[2] === 0x07);
                                                        const isPdfMagic = docBuffer && docBuffer.length >= 4 &&
                                                                docBuffer[0] === 0x25 && docBuffer[1] === 0x50 &&
                                                                docBuffer[2] === 0x44 && docBuffer[3] === 0x46;
                                                        const isRarMagic = docBuffer && docBuffer.length >= 7 &&
                                                                docBuffer[0] === 0x52 && docBuffer[1] === 0x61 &&
                                                                docBuffer[2] === 0x72 && docBuffer[3] === 0x21;
                                                        const is7zMagic = docBuffer && docBuffer.length >= 6 &&
                                                                docBuffer[0] === 0x37 && docBuffer[1] === 0x7A &&
                                                                docBuffer[2] === 0xBC && docBuffer[3] === 0xAF;

                                                        // Deteksi via mime/ekstensi sebagai fallback (magic bytes sudah lebih dulu dicek)
                                                        const isZip = isZipMagic || docMime.includes('zip') ||
                                                                ['zip', 'apk', 'jar', 'docx', 'xlsx', 'pptx', 'odt', 'ods', 'odp'].includes(docExt);
                                                        const isPdf = isPdfMagic || docMime.includes('pdf') || docExt === 'pdf';
                                                        const isRar = isRarMagic || docMime.includes('rar') || docExt === 'rar';
                                                        const is7z = is7zMagic || docExt === '7z' || docMime.includes('7z');
                                                        const isText = docMime.startsWith('text/') ||
                                                                ['txt', 'csv', 'json', 'xml', 'html', 'htm', 'js', 'ts', 'py', 'java', 'cpp', 'c', 'css', 'md', 'yaml', 'yml', 'ini', 'conf', 'log', 'sh', 'bat'].includes(docExt);
                                                        const isImage = docMime.startsWith('image/') || ['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp'].includes(docExt);

                                                        if (isZip && !isRar && !is7z) {
                                                                // ── ZIP / DOCX / APK / JAR ──
                                                                const zipResult = parseZipBuffer(docBuffer);
                                                                if (zipResult.error) {
                                                                        await tolak(hisoka, m, `❌ ${zipResult.error}`);
                                                                        break;
                                                                }
                                                                const isDocxLike = ['docx', 'xlsx', 'pptx', 'odt', 'ods', 'odp'].includes(docExt);
                                                                const isApk = docExt === 'apk';
                                                                const archiveLabel = isApk ? '📱 FILE APK' : isDocxLike ? `📝 FILE ${docExt.toUpperCase()}` : '📦 FILE ZIP';
                                                                const passwordNote = zipResult.isPasswordProtected
                                                                        ? `🔐 *Status:* *BERPASSWORD* (terenkripsi)`
                                                                        : `🔓 *Status:* *Tidak berpassword*`;
                                                                let zipText = `╭═══『 *${archiveLabel}* 』═══╮\n│\n`;
                                                                zipText += `│ 📁 *Total File:* ${zipResult.files.length} file\n`;
                                                                zipText += `│ ${passwordNote}\n│\n`;
                                                                if (!isDocxLike) {
                                                                        zipText += `│ *DAFTAR ISI:*\n`;
                                                                        const displayFiles = zipResult.files.slice(0, 30);
                                                                        for (const f of displayFiles) {
                                                                                const lockIcon = f.encrypted ? '🔐' : '📄';
                                                                                const sizeStr = f.size >= 1024 ? `${(f.size / 1024).toFixed(1)} MB` : `${f.size} KB`;
                                                                                zipText += `│ ${lockIcon} ${f.name} _(${sizeStr})_\n`;
                                                                        }
                                                                        if (zipResult.files.length > 30) {
                                                                                zipText += `│ _(... dan ${zipResult.files.length - 30} file lainnya)_\n`;
                                                                        }
                                                                } else {
                                                                        // Untuk DOCX/XLSX dll, tunjukkan saja ringkasan
                                                                        zipText += `│ _(Format Office — gunakan .wily untuk baca isinya lebih lanjut)_\n`;
                                                                }
                                                                zipText += `│\n╰═══════════════════════╯`;
                                                                await hisoka.sendMessage(m.from, { react: { text: '✅', key: m.key } });
                                                                await tolak(hisoka, m, zipText);
                                                                logCommand(m, hisoka, 'wily');
                                                                break;
                                                        } else if (isRar) {
                                                                // ── RAR FILE ──
                                                                await hisoka.sendMessage(m.from, { react: { text: '✅', key: m.key } });
                                                                await tolak(hisoka, m, `╭═══『 *📦 FILE RAR* 』═══╮\n│\n│ ⚠️ Format RAR terdeteksi!\n│\n│ RAR adalah format arsip yang bisa\n│ berpassword atau tidak.\n│\n│ *Catatan:* Format RAR tidak bisa\n│ dibaca isinya langsung oleh bot.\n│ Coba extract dulu atau kirim\n│ sebagai file ZIP.\n│\n╰═══════════════════════╯`);
                                                                logCommand(m, hisoka, 'wily');
                                                                break;
                                                        } else if (is7z) {
                                                                // ── 7Z FILE ──
                                                                await hisoka.sendMessage(m.from, { react: { text: '✅', key: m.key } });
                                                                await tolak(hisoka, m, `╭═══『 *📦 FILE 7Z* 』═══╮\n│\n│ ⚠️ Format 7-Zip terdeteksi!\n│\n│ Format 7Z tidak bisa dibaca\n│ isinya langsung oleh bot.\n│ Coba kirim sebagai ZIP.\n│\n╰═══════════════════════╯`);
                                                                logCommand(m, hisoka, 'wily');
                                                                break;
                                                        } else if (isPdf) {
                                                                // ── PDF FILE ──
                                                                await tolak(hisoka, m, `📄 Sedang membaca isi PDF...`);
                                                                try {
                                                                        const pdfText = await extractPdfText(docBuffer);
                                                                        if (!pdfText || pdfText.length < 10) {
                                                                                await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                                                                await tolak(hisoka, m, `❌ PDF ini tidak mengandung teks yang bisa dibaca (mungkin berupa scan/gambar). Coba kirim sebagai gambar untuk dianalisis.`);
                                                                                break;
                                                                        }
                                                                        isDocumentMode = true;
                                                                        documentContext = `[ISI PDF]\n${pdfText}`;
                                                                        hasMedia = true;
                                                                        mediaLabel = 'PDF';
                                                                        console.log(`\x1b[36m[WilyAI]\x1b[39m PDF dibaca: ${pdfText.length} karakter`);
                                                                } catch (pdfErr) {
                                                                        await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                                                        await tolak(hisoka, m, `❌ Gagal baca PDF: ${pdfErr.message}`);
                                                                        break;
                                                                }
                                                        } else if (isText) {
                                                                // ── TEKS / CODE / CSV / JSON / dll ──
                                                                const textContent = docBuffer.toString('utf8').substring(0, 5000);
                                                                isDocumentMode = true;
                                                                documentContext = `[ISI FILE ${docExt.toUpperCase() || 'TEKS'}]\n${textContent}`;
                                                                hasMedia = true;
                                                                mediaLabel = `file ${docExt || 'teks'}`;
                                                                console.log(`\x1b[36m[WilyAI]\x1b[39m File teks dibaca: ${textContent.length} karakter`);
                                                        } else if (isImage) {
                                                                // ── GAMBAR YANG DIKIRIM SEBAGAI DOKUMEN ──
                                                                imageBuffer = docBuffer;
                                                                imageMime = docMime || 'image/jpeg';
                                                                hasMedia = true;
                                                                mediaLabel = 'gambar';
                                                        } else {
                                                                // ── FILE TIDAK DIKENAL — Beri info ke AI ──
                                                                isDocumentMode = true;
                                                                documentContext = `[INFO FILE]\nNama: ${docFileName || 'tidak diketahui'}\nEkstensi: ${docExt || 'tidak ada'}\nUkuran: ${docSizeKB} KB\nMIME Type: ${docMime || 'tidak diketahui'}`;
                                                                hasMedia = true;
                                                                mediaLabel = `file ${docExt || 'tidak dikenal'}`;
                                                                console.log(`\x1b[36m[WilyAI]\x1b[39m File tidak dikenal — metadata diteruskan ke AI`);
                                                        }
                                                } catch (docErr) {
                                                        console.error(`\x1b[31m[WilyAI]\x1b[39m Gagal proses dokumen: ${docErr.message}`);
                                                        await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                                        await tolak(hisoka, m, `❌ Gagal proses file: ${docErr.message}`);
                                                        break;
                                                }
                                        }

                                        // ── DETEKSI MEDIA DARI PESAN YANG DI-REPLY ──
                                        if (!hasMedia && m.isQuoted) {
                                                if (qtType === 'imageMessage' || qtType === 'stickerMessage') {
                                                        try {
                                                                await hisoka.sendMessage(m.from, { react: { text: '🔍', key: m.key } });
                                                                imageBuffer = await downloadQuotedMedia();
                                                                if (imageBuffer && imageBuffer.length > 0) {
                                                                        imageMime = qtType === 'stickerMessage' ? 'image/webp' : 'image/jpeg';
                                                                        hasMedia = true;
                                                                        mediaLabel = qtType === 'stickerMessage' ? 'sticker' : 'gambar';
                                                                        console.log(`\x1b[36m[WilyAI]\x1b[39m Media dari quoted: ${qtType}, ${imageBuffer.length} bytes`);
                                                                }
                                                        } catch (dlErr) {
                                                                console.error(`\x1b[31m[WilyAI]\x1b[39m Gagal download quoted media: ${dlErr.message}`);
                                                        }
                                                } else if (qtType === 'videoMessage') {
                                                        try {
                                                                await hisoka.sendMessage(m.from, { react: { text: '🎬', key: m.key } });
                                                                imageBuffer = await downloadQuotedMedia();
                                                                if (imageBuffer && imageBuffer.length > 0) {
                                                                        imageMime = 'video/mp4';
                                                                        hasMedia = true;
                                                                        mediaLabel = 'video';
                                                                        console.log(`\x1b[36m[WilyAI]\x1b[39m Video dari quoted: ${imageBuffer.length} bytes`);
                                                                }
                                                        } catch (dlErr) {
                                                                console.error(`\x1b[31m[WilyAI]\x1b[39m Gagal download quoted video: ${dlErr.message}`);
                                                        }
                                                } else if (qtType === 'documentMessage') {
                                                        await hisoka.sendMessage(m.from, { react: { text: '📄', key: m.key } });
                                                        try {
                                                                const docBuffer = await downloadQuotedMedia();
                                                                const qtMime = (
                                                                        m.quoted?.msg?.mimetype ||
                                                                        m.quoted?.message?.documentMessage?.mimetype ||
                                                                        m.quoted?.content?.mimetype || ''
                                                                ).toLowerCase();
                                                                const qtFileName = (
                                                                        m.quoted?.msg?.fileName ||
                                                                        m.quoted?.message?.documentMessage?.fileName ||
                                                                        m.quoted?.content?.fileName || ''
                                                                ).toLowerCase();
                                                                const qtExt = qtFileName.split('.').pop() || '';
                                                                const qtSizeKB = docBuffer ? (docBuffer.length / 1024).toFixed(1) : 0;
                                                                console.log(`\x1b[36m[WilyAI]\x1b[39m Quoted doc: mime="${qtMime}" name="${qtFileName}" size=${qtSizeKB}KB`);

                                                                // Magic bytes detection
                                                                const qtIsZip = docBuffer && docBuffer.length >= 4 &&
                                                                        docBuffer[0] === 0x50 && docBuffer[1] === 0x4B &&
                                                                        (docBuffer[2] === 0x03 || docBuffer[2] === 0x05 || docBuffer[2] === 0x07);
                                                                const qtIsPdf = docBuffer && docBuffer.length >= 4 &&
                                                                        docBuffer[0] === 0x25 && docBuffer[1] === 0x50 &&
                                                                        docBuffer[2] === 0x44 && docBuffer[3] === 0x46;
                                                                const qtIsRar = docBuffer && docBuffer.length >= 4 &&
                                                                        docBuffer[0] === 0x52 && docBuffer[1] === 0x61 &&
                                                                        docBuffer[2] === 0x72 && docBuffer[3] === 0x21;
                                                                const qtIs7z = docBuffer && docBuffer.length >= 6 &&
                                                                        docBuffer[0] === 0x37 && docBuffer[1] === 0x7A &&
                                                                        docBuffer[2] === 0xBC && docBuffer[3] === 0xAF;

                                                                const isZip = qtIsZip || qtMime.includes('zip') ||
                                                                        ['zip', 'apk', 'jar', 'docx', 'xlsx', 'pptx', 'odt', 'ods', 'odp'].includes(qtExt);
                                                                const isPdf = qtIsPdf || qtMime.includes('pdf') || qtExt === 'pdf';
                                                                const isRar = qtIsRar || qtMime.includes('rar') || qtExt === 'rar';
                                                                const is7z = qtIs7z || qtExt === '7z';
                                                                const isText = qtMime.startsWith('text/') ||
                                                                        ['txt', 'csv', 'json', 'xml', 'html', 'htm', 'js', 'ts', 'py', 'java', 'cpp', 'c', 'css', 'md', 'yaml', 'yml', 'ini', 'conf', 'log', 'sh', 'bat'].includes(qtExt);

                                                                if (isZip && !isRar && !is7z) {
                                                                        const zipResult = parseZipBuffer(docBuffer);
                                                                        if (zipResult.error) {
                                                                                await tolak(hisoka, m, `❌ ${zipResult.error}`);
                                                                                break;
                                                                        }
                                                                        const isDocxLike = ['docx', 'xlsx', 'pptx', 'odt'].includes(qtExt);
                                                                        const archiveLabel = qtExt === 'apk' ? '📱 FILE APK' : isDocxLike ? `📝 FILE ${qtExt.toUpperCase()}` : '📦 FILE ZIP';
                                                                        const passwordNote = zipResult.isPasswordProtected ? `🔐 *BERPASSWORD*` : `🔓 *Tidak berpassword*`;
                                                                        let zipText = `╭═══『 *${archiveLabel}* 』═══╮\n│\n│ 📁 *Total File:* ${zipResult.files.length}\n│ ${passwordNote}\n│\n│ *DAFTAR ISI:*\n`;
                                                                        for (const f of zipResult.files.slice(0, 30)) {
                                                                                const lockIcon = f.encrypted ? '🔐' : '📄';
                                                                                const sizeStr = f.size >= 1024 ? `${(f.size / 1024).toFixed(1)} MB` : `${f.size} KB`;
                                                                                zipText += `│ ${lockIcon} ${f.name} _(${sizeStr})_\n`;
                                                                        }
                                                                        if (zipResult.files.length > 30) zipText += `│ _(... dan ${zipResult.files.length - 30} lainnya)_\n`;
                                                                        zipText += `│\n╰═══════════════════════╯`;
                                                                        await hisoka.sendMessage(m.from, { react: { text: '✅', key: m.key } });
                                                                        await tolak(hisoka, m, zipText);
                                                                        logCommand(m, hisoka, 'wily');
                                                                        break;
                                                                } else if (isRar) {
                                                                        await hisoka.sendMessage(m.from, { react: { text: '✅', key: m.key } });
                                                                        await tolak(hisoka, m, `📦 *File RAR terdeteksi.*\nBot tidak bisa baca isi RAR langsung. Coba extract dulu atau kirim sebagai ZIP.`);
                                                                        logCommand(m, hisoka, 'wily');
                                                                        break;
                                                                } else if (is7z) {
                                                                        await hisoka.sendMessage(m.from, { react: { text: '✅', key: m.key } });
                                                                        await tolak(hisoka, m, `📦 *File 7Z terdeteksi.*\nBot tidak bisa baca isi 7Z. Coba kirim sebagai ZIP.`);
                                                                        logCommand(m, hisoka, 'wily');
                                                                        break;
                                                                } else if (isPdf) {
                                                                        await tolak(hisoka, m, `📄 Sedang membaca PDF...`);
                                                                        const pdfText = await extractPdfText(docBuffer);
                                                                        if (!pdfText || pdfText.length < 10) {
                                                                                await tolak(hisoka, m, `❌ PDF tidak mengandung teks yang bisa dibaca.`);
                                                                                break;
                                                                        }
                                                                        isDocumentMode = true;
                                                                        documentContext = `[ISI PDF]\n${pdfText}`;
                                                                        hasMedia = true;
                                                                        mediaLabel = 'PDF';
                                                                } else if (isText) {
                                                                        const textContent = docBuffer.toString('utf8').substring(0, 5000);
                                                                        isDocumentMode = true;
                                                                        documentContext = `[ISI FILE ${qtExt.toUpperCase() || 'TEKS'}]\n${textContent}`;
                                                                        hasMedia = true;
                                                                        mediaLabel = `file ${qtExt || 'teks'}`;
                                                                } else {
                                                                        isDocumentMode = true;
                                                                        documentContext = `[INFO FILE]\nNama: ${qtFileName || 'tidak diketahui'}\nEkstensi: ${qtExt || 'tidak ada'}\nUkuran: ${qtSizeKB} KB\nMIME Type: ${qtMime || 'tidak diketahui'}`;
                                                                        hasMedia = true;
                                                                        mediaLabel = `file ${qtExt || 'tidak dikenal'}`;
                                                                }
                                                        } catch (docErr) {
                                                                await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                                                await tolak(hisoka, m, `❌ Gagal proses file: ${docErr.message}`);
                                                                break;
                                                        }
                                                } else if (qtType === 'conversation' || qtType === 'extendedTextMessage') {
                                                        // Reply ke pesan teks orang lain — beri konteks pengirim + isi pesan
                                                        const senderName = m.quoted?.pushName || m.quoted?.key?.participant?.split('@')[0] || 'seseorang';
                                                        const quotedText = m.quoted?.text || m.quoted?.body || '';
                                                        if (quotedText) {
                                                                quotedTextContext = `\n📩 KONTEKS PESAN YANG DI-REPLY:\nPengirim: ${senderName}\nIsi pesan: "${quotedText.substring(0, 500)}"`;
                                                        }
                                                }
                                        }

                                        let userQuestion = query?.trim() || '';

                                        if (!userQuestion && !hasMedia && !quotedTextContext) {
                                                let helpText = `╭═══『 *🤖 WILY AI* 』═══╮\n`;
                                                helpText += `│\n`;
                                                helpText += `│ Halo ${userName}! Aku Wily Bot AI 🤖\n`;
                                                helpText += `│ AI cerdas berbasis Gemini Vision\n`;
                                                helpText += `│\n`;
                                                helpText += `│ *CARA PAKAI:*\n`;
                                                helpText += `│\n`;
                                                helpText += `│ 💬 *Tanya sesuatu:*\n`;
                                                helpText += `│ .wily [pertanyaan kamu]\n`;
                                                helpText += `│\n`;
                                                helpText += `│ 🖼️ *Analisis gambar/sticker:*\n`;
                                                helpText += `│ Kirim/reply gambar + .wily\n`;
                                                helpText += `│\n`;
                                                helpText += `│ 🎬 *Analisis video:*\n`;
                                                helpText += `│ Kirim/reply video + .wily\n`;
                                                helpText += `│\n`;
                                                helpText += `│ 📄 *Baca PDF:*\n`;
                                                helpText += `│ Kirim/reply PDF + .wily [pertanyaan]\n`;
                                                helpText += `│\n`;
                                                helpText += `│ 📦 *Cek isi ZIP:*\n`;
                                                helpText += `│ Kirim/reply file ZIP + .wily\n`;
                                                helpText += `│\n`;
                                                helpText += `│ 🔍 *Cari & kirim gambar:*\n`;
                                                helpText += `│ .wily cari gambar naruto\n`;
                                                helpText += `│\n`;
                                                helpText += `│ 💬 *Reply pesan + tanya:*\n`;
                                                helpText += `│ Reply pesan siapapun + .wily [pertanyaan]\n`;
                                                helpText += `│\n`;
                                                helpText += `│ 🧠 *Memory percakapan:*\n`;
                                                helpText += `│ • Private: langsung lanjut otomatis\n`;
                                                helpText += `│ • Grup: reply pesan bot untuk lanjut\n`;
                                                helpText += `│ • .wily reset - hapus memory\n`;
                                                helpText += `│\n`;
                                                helpText += `│ *KEMAMPUAN AI:*\n`;
                                                helpText += `│ ✅ Ingat percakapan sebelumnya\n`;
                                                helpText += `│ ✅ Cari dan kirim gambar otomatis\n`;
                                                helpText += `│ ✅ Baca teks di dalam gambar\n`;
                                                helpText += `│ ✅ Tahu judul anime/film/series\n`;
                                                helpText += `│ ✅ Kenali karakter/artis dari foto\n`;
                                                helpText += `│ ✅ Baca isi file PDF\n`;
                                                helpText += `│ ✅ Cek isi file ZIP + deteksi password\n`;
                                                helpText += `│ ✅ Analisis video\n`;
                                                helpText += `│ ✅ Jawab pertanyaan umum\n`;
                                                helpText += `│\n`;
                                                helpText += `╰══════════════════════╯`;
                                                await tolak(hisoka, m, helpText);
                                                break;
                                        }

                                        if (!userQuestion && hasMedia) {
                                                if (isDocumentMode && mediaLabel === 'PDF') {
                                                        userQuestion = `Tolong rangkum dan jelaskan isi dokumen PDF ini secara lengkap dan terstruktur.`;
                                                } else {
                                                        userQuestion = `Tolong analisis ${mediaLabel} ini secara lengkap dan detail. Sebutkan: judul anime/film/series jika ada, nama karakter atau orang jika ada, semua teks yang tertulis, dan deskripsi konten secara akurat.`;
                                                }
                                        }
                                        if (!userQuestion && quotedTextContext) {
                                                userQuestion = `Bantu aku tentang pesan ini.`;
                                        }

                                        // ── SESSION KEY & HISTORY (harus sebelum imgSearch maupun Gemini) ──
                                        const sessKey = getSessionKey(m);
                                        const isReplyToBot = m.isQuoted && m.quoted?.key?.fromMe;
                                        const useHistory = !m.isGroup || isReplyToBot;

                                        // ── DETEKSI PERMINTAAN CARI GAMBAR ──
                                        const imgSearchQuery = !hasMedia ? detectImageSearchQuery(userQuestion) : null;

                                        if (imgSearchQuery) {
                                                // Ekstrak jumlah gambar yang diminta (max 5)
                                                const imgCount = Math.min(extractImageCount(userQuestion), 5);
                                                await hisoka.sendMessage(m.from, { react: { text: '🔍', key: m.key } });
                                                const countLabel = imgCount > 1 ? ` ${imgCount} gambar` : '';
                                                await tolak(hisoka, m, `🔍 Mencari${countLabel}: *${imgSearchQuery}*...`);
                                                let imgBotReply = '';
                                                try {
                                                        const imgResults = await searchAndGetImages(imgSearchQuery, imgCount);
                                                        for (let i = 0; i < imgResults.length; i++) {
                                                                const r = imgResults[i];
                                                                const cap = imgResults.length > 1
                                                                        ? `🖼️ *${imgSearchQuery}* (${i + 1}/${imgResults.length})\n🔗 ${r.url}`
                                                                        : `🖼️ *${r.title || imgSearchQuery}*\n🔗 ${r.url}`;
                                                                await hisoka.sendMessage(m.from, { image: r.buffer, caption: cap }, { quoted: i === 0 ? m : undefined });
                                                        }
                                                        await hisoka.sendMessage(m.from, { react: { text: '✅', key: m.key } });
                                                        console.log(`\x1b[36m[WilyAI]\x1b[39m Image search: "${imgSearchQuery}" → ${imgResults.length} gambar`);
                                                        imgBotReply = imgResults.length > 1
                                                                ? `Ini ${imgResults.length} gambar "${imgSearchQuery}" yang aku cariin! 🖼️`
                                                                : `Ini gambar "${imgSearchQuery}" yang aku cariin buat kamu! 🖼️ Kalau mau gambar lain atau lebih spesifik, bilang aja ya!`;
                                                } catch (searchErr) {
                                                        console.error(`\x1b[31m[WilyAI]\x1b[39m Image search error: ${searchErr.message}`);
                                                        await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                                        imgBotReply = `Maaf aku gagal cariin gambar "${imgSearchQuery}" tadi. Coba minta lagi dengan kata kunci yang lebih spesifik ya!`;
                                                        await tolak(hisoka, m, `❌ Maaf ${userName}, gagal cariin gambar "${imgSearchQuery}".\n\nCoba kata kunci yang lebih spesifik ya!`);
                                                }
                                                if (useHistory && imgBotReply) {
                                                        addToHistory(sessKey, userQuestion, imgBotReply);
                                                }
                                                logCommand(m, hisoka, 'wily');
                                                break;
                                        }

                                        // ── MEMORY PERCAKAPAN ──
                                        const historyMessages = useHistory ? getHistory(sessKey) : [];
                                        const hasHistory = historyMessages.length > 0;

                                        // Gabungkan konteks dokumen atau teks quoted ke chatContext
                                        let extraContext = `CATATAN: Kalau user minta "cari gambar X" atau "cariin foto X", jawab "Ok aku cariin gambar X untuk kamu ${userName}! 🔍" — bot akan otomatis mengirimkannya.`;
                                        if (documentContext) extraContext += `\n\n${documentContext}`;
                                        if (quotedTextContext) extraContext += `\n${quotedTextContext}`;

                                        const systemPrompt = buildWilySystemPrompt({
                                                userName, currentTime, currentDate, timeOfDay,
                                                hasHistory,
                                                chatContext: extraContext,
                                        });

                                        // Bangun final user message (gabung pertanyaan + konteks dokumen jika ada)
                                        const finalUserMsg = isDocumentMode && documentContext
                                                ? `${documentContext}\n\n${userQuestion}`
                                                : quotedTextContext
                                                ? `${quotedTextContext}\n\nPertanyaan user: ${userQuestion}`
                                                : userQuestion;

                                        // Bangun contents array untuk Gemini
                                        let contents;
                                        if (!hasHistory) {
                                                // Percakapan baru: sistem prompt + pertanyaan sekarang
                                                if (imageBuffer && imageBuffer.length > 0 && !isDocumentMode) {
                                                        contents = null; // handled below via askWithImage
                                                } else {
                                                        contents = [{ role: 'user', parts: [{ text: systemPrompt + '\n\n' + finalUserMsg }] }];
                                                }
                                        } else {
                                                // Lanjut percakapan: sistem prompt sebagai pembuka, lalu history, lalu pertanyaan sekarang
                                                if (imageBuffer && imageBuffer.length > 0 && !isDocumentMode) {
                                                        contents = null; // handled below, history passed separately
                                                } else {
                                                        contents = [
                                                                { role: 'user', parts: [{ text: systemPrompt }] },
                                                                { role: 'model', parts: [{ text: `Halo ${userName}! Aku Wily Bot, siap membantu kamu 🤖` }] },
                                                                ...historyMessages,
                                                                { role: 'user', parts: [{ text: finalUserMsg }] },
                                                        ];
                                                }
                                                console.log(`\x1b[36m[WilyAI]\x1b[39m Melanjutkan percakapan (${historyMessages.length / 2} pesan sebelumnya) untuk ${m.sender}`);
                                        }

                                        let response;

                                        if (imageBuffer && imageBuffer.length > 0 && !isDocumentMode) {
                                                console.log(`\x1b[36m[WilyAI]\x1b[39m Vision request - buffer: ${imageBuffer.length} bytes, mime: ${imageMime}`);
                                                let finalBuffer = imageBuffer;
                                                let finalMime = imageMime;
                                                if (imageMime === 'image/webp') {
                                                        try {
                                                                const sharp = (await import('sharp')).default;
                                                                finalBuffer = await sharp(imageBuffer).jpeg({ quality: 90 }).toBuffer();
                                                                finalMime = 'image/jpeg';
                                                                console.log(`\x1b[36m[WilyAI]\x1b[39m Sticker dikonversi ke JPEG: ${finalBuffer.length} bytes`);
                                                        } catch (sharpErr) {
                                                                console.error(`\x1b[31m[WilyAI]\x1b[39m Gagal konversi sticker: ${sharpErr.message}`);
                                                        }
                                                }
                                                // Untuk gambar/video, gabungkan history teks + pesan media terakhir
                                                if (hasHistory) {
                                                        const visionContents = [
                                                                { role: 'user', parts: [{ text: systemPrompt }] },
                                                                { role: 'model', parts: [{ text: `Halo ${userName}! Aku Wily Bot, siap membantu kamu 🤖` }] },
                                                                ...historyMessages,
                                                                {
                                                                        role: 'user',
                                                                        parts: [
                                                                                { inlineData: { mimeType: finalMime, data: finalBuffer.toString('base64') } },
                                                                                { text: finalUserMsg },
                                                                        ],
                                                                },
                                                        ];
                                                        const models = ['gemini-flash-latest', 'gemini-2.0-flash', 'gemini-pro'];
                                                        let lastErr = null;
                                                        for (const model of models) {
                                                                try {
                                                                        response = await gemini.chat({ model, contents: visionContents });
                                                                        console.log(`\x1b[36m[Gemini Vision]\x1b[0m ✅ Berhasil dengan model: ${model}`);
                                                                        break;
                                                                } catch (err) {
                                                                        console.error(`\x1b[31m[Gemini Vision]\x1b[0m ❌ Model ${model} gagal: ${err.message}`);
                                                                        lastErr = err;
                                                                }
                                                        }
                                                        if (!response) throw lastErr || new Error('Semua model gagal');
                                                } else {
                                                        response = await gemini.askWithImage(systemPrompt + '\n\n' + finalUserMsg, finalBuffer, finalMime);
                                                }
                                        } else {
                                                response = await gemini.chat({ contents });
                                        }

                                        if (response && response.trim()) {
                                                const wilyClean = await sendAIReply(hisoka, m, response.trim());
                                                if (useHistory) {
                                                        addToHistory(sessKey, userQuestion, wilyClean || response.trim());
                                                }
                                        } else {
                                                await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                                await tolak(hisoka, m, '❌ AI tidak merespons, coba lagi.');
                                        }

                                        logCommand(m, hisoka, 'wily');
                                } catch (error) {
                                        console.error('\x1b[31m[WilyAI] Error:\x1b[39m', error.message);
                                        await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                        await tolak(hisoka, m, `❌ Error AI: ${error.message}`);
                                }
                                break;
                        }

                        case 'antidel':
                        case 'ad': {
                                if (!isMainBot(hisoka)) return;
                                if (!m.isOwner) return;
                                try {
                                        const config = loadConfig();
                                        const antiDelete = config.antiDelete || { enabled: false, privateChat: false, groupChat: false, sendTo: 'self' };
                                        const args = query ? query.toLowerCase().split(' ') : [];
                                        const sendTo = antiDelete.sendTo || 'self';

                                        const sendToLabel = {
                                                self: '📲 Saved Messages (bot)',
                                                chat: '💬 Chat / Grup Asal',
                                                both: '📲 Saved Messages + 💬 Chat Asal'
                                        };

                                        if (args.length === 0) {
                                                const text =
                                                        `╔═══════════════════════╗\n` +
                                                        `║  🗑️  *ANTI DELETE*  🗑️  ║\n` +
                                                        `╚═══════════════════════╝\n\n` +
                                                        `📊 *Status:* ${antiDelete.enabled ? '✅ Aktif' : '❌ Nonaktif'}\n` +
                                                        `💬 *Private Chat:* ${antiDelete.privateChat ? '✅' : '❌'}\n` +
                                                        `👥 *Group Chat:* ${antiDelete.groupChat ? '✅' : '❌'}\n` +
                                                        `📤 *Kirim ke:* ${sendToLabel[sendTo] || sendToLabel.self}\n\n` +
                                                        `📋 *Perintah:*\n` +
                                                        `• *.antidel on/off* — Aktifkan/nonaktifkan\n` +
                                                        `• *.antidel private on/off* — Untuk chat pribadi\n` +
                                                        `• *.antidel group on/off* — Untuk grup\n` +
                                                        `• *.antidel all on/off* — Private + Group\n` +
                                                        `• *.antidel sendto self* — Kirim ke saved messages bot\n` +
                                                        `• *.antidel sendto chat* — Kirim balik ke chat/grup asal\n` +
                                                        `• *.antidel sendto both* — Kirim ke keduanya\n\n` +
                                                        `📦 *Didukung:* Teks, Gambar, Video, Audio, Sticker, Dokumen`;

                                                await tolak(hisoka, m, text);
                                                break;
                                        }

                                        if (args[0] === 'on') {
                                                if (antiDelete.enabled) {
                                                        await tolak(hisoka, m, 'ℹ️ Anti Delete sudah aktif.');
                                                } else {
                                                        config.antiDelete = { ...antiDelete, enabled: true };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, 
                                                                `✅ *Anti Delete diaktifkan!*\n\n` +
                                                                `📤 Pesan dihapus akan dikirim ke:\n` +
                                                                `*${sendToLabel[sendTo] || sendToLabel.self}*\n\n` +
                                                                `💡 Atur tujuan dengan: *.antidel sendto self/chat/both*`
                                                        );
                                                }

                                        } else if (args[0] === 'off') {
                                                if (!antiDelete.enabled) {
                                                        await tolak(hisoka, m, 'ℹ️ Anti Delete sudah nonaktif.');
                                                } else {
                                                        config.antiDelete = { ...antiDelete, enabled: false };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, '✅ *Anti Delete dinonaktifkan.*');
                                                }

                                        } else if (args[0] === 'private' && args[1]) {
                                                const enabled = args[1] === 'on';
                                                config.antiDelete = { ...antiDelete, privateChat: enabled };
                                                saveConfig(config);
                                                await tolak(hisoka, m, 
                                                        `${enabled ? '✅' : '❌'} Anti Delete *Private Chat* ${enabled ? 'diaktifkan' : 'dinonaktifkan'}.`
                                                );

                                        } else if (args[0] === 'group' && args[1]) {
                                                const enabled = args[1] === 'on';
                                                config.antiDelete = { ...antiDelete, groupChat: enabled };
                                                saveConfig(config);
                                                await tolak(hisoka, m, 
                                                        `${enabled ? '✅' : '❌'} Anti Delete *Group Chat* ${enabled ? 'diaktifkan' : 'dinonaktifkan'}.`
                                                );

                                        } else if (args[0] === 'all' && args[1]) {
                                                const enabled = args[1] === 'on';
                                                config.antiDelete = { ...antiDelete, privateChat: enabled, groupChat: enabled };
                                                saveConfig(config);
                                                await tolak(hisoka, m, 
                                                        `${enabled ? '✅' : '❌'} Anti Delete *Private + Group* ${enabled ? 'diaktifkan' : 'dinonaktifkan'}.`
                                                );

                                        } else if (args[0] === 'sendto' && args[1]) {
                                                const valid = ['self', 'chat', 'both'];
                                                const val = args[1];
                                                if (!valid.includes(val)) {
                                                        return await tolak(hisoka, m, 
                                                                `❌ Nilai tidak valid!\n\n` +
                                                                `Gunakan salah satu:\n` +
                                                                `• *.antidel sendto self* — Kirim ke saved messages bot\n` +
                                                                `• *.antidel sendto chat* — Kirim balik ke chat/grup asal\n` +
                                                                `• *.antidel sendto both* — Kirim ke keduanya`
                                                        );
                                                }
                                                config.antiDelete = { ...antiDelete, sendTo: val };
                                                saveConfig(config);
                                                await tolak(hisoka, m, 
                                                        `✅ *Tujuan pengiriman anti delete diubah!*\n\n` +
                                                        `📤 Sekarang dikirim ke:\n` +
                                                        `*${sendToLabel[val]}*\n\n` +
                                                        `${val === 'chat' ? '⚠️ Semua orang di grup/chat bisa melihat pesan yang dihapus.' : ''}`
                                                );

                                        } else {
                                                await tolak(hisoka, m, 
                                                        `❌ Perintah tidak valid.\n` +
                                                        `Ketik *.antidel* untuk melihat bantuan.`
                                                );
                                        }

                                        logCommand(m, hisoka, 'antidel');
                                } catch (error) {
                                        console.error('\x1b[31m[AntiDelete] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `Terjadi kesalahan: ${error.message}`);
                                }
                                break;
                        }

                        case 'readsw': {
                                if (!isMainBot(hisoka)) return;
                                if (!m.isOwner) return;
                                try {
                                        const config = loadConfig();
                                        const storyConfig = config.autoReadStory || {
                                                enabled: true,
                                                autoReaction: true,
                                                randomDelay: true,
                                                delayMinMs: 1000,
                                                delayMaxMs: 20000,
                                                fixedDelayMs: 3000
                                        };
                                        const args = query ? query.toLowerCase().split(' ') : [];
                                        
                                        if (args.length === 0) {
                                                let statusText = '';
                                                if (!storyConfig.enabled) {
                                                        statusText = '❌ Nonaktif';
                                                } else if (storyConfig.autoReaction !== false) {
                                                        statusText = '✅ Read + Reaction';
                                                } else {
                                                        statusText = '✅ Read Only';
                                                }
                                                
                                                let text = `╭═══『 *AUTO READ STORY* 』═══╮\n`;
text += `│\n`;
text += `│ *Status:* ${statusText}\n`;
text += `│ *Reaction:* ${storyConfig.autoReaction !== false ? '✅ Aktif' : '❌ Nonaktif'}\n`;
text += `│ *Random Delay:* ${storyConfig.randomDelay !== false ? '✅' : '❌'}\n`;
text += `│ *Delay Min:* ${(storyConfig.delayMinMs || 1000) / 1000} detik\n`;
text += `│ *Delay Max:* ${(storyConfig.delayMaxMs || 20000) / 1000} detik\n`;
text += `│ *Fixed Delay:* ${(storyConfig.fixedDelayMs || 3000) / 1000} detik\n`;
text += `│\n`;
text += `│ *Penggunaan:*\n`;
text += `│ .readsw true - Read + Reaction\n`;
text += `│ .readsw false - Read Only\n`;
text += `│ .readsw off - Nonaktifkan\n`;
text += `│ .readsw delay <min> <max>\n`;
text += `│   (dalam detik, contoh: delay 1 20)\n`;
text += `│\n`;
text += `╰═════════════════════╯`;
                                                await tolak(hisoka, m, text);
                                                break;
                                        }
                                        
                                        const buildStatusReply = (cfg, action) => {
                                                const delayMin = (cfg.delayMinMs || 1000) / 1000;
                                                const delayMax = (cfg.delayMaxMs || 20000) / 1000;
                                                const fixedDelay = (cfg.fixedDelayMs || 3000) / 1000;
                                                const isRandom = cfg.randomDelay !== false;
                                                const modeText = cfg.autoReaction !== false ? 'Read + Reaction' : 'Read Only';
                                                
                                                let text = `╭═══『 *AUTO READ STORY* 』═══╮\n`;
text += `│\n`;
text += `│ ${action}\n`;
text += `│\n`;
text += `│ *Mode:* ${modeText}\n`;
text += `│ *Delay:* ${isRandom ? `${delayMin}-${delayMax}s (random)` : `${fixedDelay}s (fixed)`}\n`;
text += `│\n`;
text += `╰═════════════════════╯`;
                                                return text;
                                        };
                                        
                                        if (args[0] === 'true' || args[0] === 'on') {
                                                if (storyConfig.enabled && storyConfig.autoReaction !== false) {
                                                        await tolak(hisoka, m, 'ℹ️ Auto Read Story + Reaction sudah aktif sebelumnya');
                                                } else {
                                                        config.autoReadStory = { ...storyConfig, enabled: true, autoReaction: true };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, buildStatusReply(config.autoReadStory, '✅ *Diaktifkan!*'));
                                                }
                                        } else if (args[0] === 'false') {
                                                if (storyConfig.enabled && storyConfig.autoReaction === false) {
                                                        await tolak(hisoka, m, 'ℹ️ Auto Read Story (tanpa reaction) sudah aktif sebelumnya');
                                                } else {
                                                        config.autoReadStory = { ...storyConfig, enabled: true, autoReaction: false };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, buildStatusReply(config.autoReadStory, '✅ *Diaktifkan (Read Only)!*'));
                                                }
                                        } else if (args[0] === 'off') {
                                                if (!storyConfig.enabled) {
                                                        await tolak(hisoka, m, 'ℹ️ Auto Read Story sudah nonaktif sebelumnya');
                                                } else {
                                                        config.autoReadStory = { ...storyConfig, enabled: false };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, '❌ Auto Read Story dinonaktifkan');
                                                }
                                        } else if (args[0] === 'delay' && args[1] && args[2]) {
                                                const minDelay = parseInt(args[1]);
                                                const maxDelay = parseInt(args[2]);
                                                
                                                if (isNaN(minDelay) || isNaN(maxDelay)) {
                                                        await tolak(hisoka, m, '❌ Delay harus berupa angka. Contoh: .readsw delay 1 20');
                                                        break;
                                                }
                                                
                                                if (minDelay < 1 || maxDelay > 60) {
                                                        await tolak(hisoka, m, '❌ Delay min harus >= 1 detik dan max <= 60 detik');
                                                        break;
                                                }
                                                
                                                if (minDelay >= maxDelay) {
                                                        await tolak(hisoka, m, '❌ Delay min harus lebih kecil dari delay max');
                                                        break;
                                                }
                                                
                                                config.autoReadStory = {
                                                        ...storyConfig,
                                                        delayMinMs: minDelay * 1000,
                                                        delayMaxMs: maxDelay * 1000,
                                                        randomDelay: true
                                                };
                                                saveConfig(config);
                                                await tolak(hisoka, m, buildStatusReply(config.autoReadStory, `✅ *Delay diubah!*`));
                                        } else if (args[0] === 'delay' && args[1] && !args[2]) {
                                                const fixedDelay = parseInt(args[1]);
                                                
                                                if (isNaN(fixedDelay) || fixedDelay < 1 || fixedDelay > 60) {
                                                        await tolak(hisoka, m, '❌ Delay harus antara 1-60 detik');
                                                        break;
                                                }
                                                
                                                config.autoReadStory = {
                                                        ...storyConfig,
                                                        fixedDelayMs: fixedDelay * 1000,
                                                        randomDelay: false
                                                };
                                                saveConfig(config);
                                                await tolak(hisoka, m, buildStatusReply(config.autoReadStory, `✅ *Fixed delay diubah!*`));
                                        } else {
                                                await tolak(hisoka, m, '❌ Perintah tidak valid. Gunakan .readsw untuk melihat bantuan.');
                                        }
                                        
                                        logCommand(m, hisoka, 'readsw');
                                } catch (error) {
                                        console.error('\x1b[31m[ReadSW] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `Error: ${error.message}`);
                                }
                                break;
                        }

                        case 'telegram':
                        case 'tele': {
                                if (!isMainBot(hisoka)) return;
                                if (!m.isOwner) return;
                                try {
                                        const config = loadConfig();
                                        const telegramConfig = config.telegram || {
                                                enabled: true,
                                                token: '',
                                                chatId: ''
                                        };
                                        const telegramQuery = m.query ? m.query.toLowerCase().trim() : '';
                                        const args = telegramQuery ? telegramQuery.split(' ') : [];
                                        const validCommands = ['on', 'off', 'true', 'false', 'token', 'chatid', 'chat_id', 'id', 'tutorial', 'help', 'test', 'cek', 'check'];
                                        
                                        const validateToken = async (token) => {
                                                try {
                                                        const res = await fetch(`https://api.telegram.org/bot${token}/getMe`);
                                                        const data = await res.json();
                                                        if (data.ok) {
                                                                return { valid: true, botName: data.result.first_name, username: data.result.username };
                                                        }
                                                        return { valid: false, error: data.description };
                                                } catch (e) {
                                                        return { valid: false, error: e.message };
                                                }
                                        };
                                        
                                        const validateChatId = async (token, chatId) => {
                                                try {
                                                        const res = await fetch(`https://api.telegram.org/bot${token}/getChat?chat_id=${chatId}`);
                                                        const data = await res.json();
                                                        if (data.ok) {
                                                                return { valid: true, chatType: data.result.type, chatTitle: data.result.first_name || data.result.title };
                                                        }
                                                        return { valid: false, error: data.description };
                                                } catch (e) {
                                                        return { valid: false, error: e.message };
                                                }
                                        };
                                        
                                        const showHelp = async () => {
                                                const statusText = telegramConfig.enabled ? '✅ Aktif' : '❌ Nonaktif';
                                                
                                                let tokenStatus = '❌ Belum diset';
                                                let botInfo = '';
                                                if (telegramConfig.token) {
                                                        const tokenCheck = await validateToken(telegramConfig.token);
                                                        if (tokenCheck.valid) {
                                                                tokenStatus = `✅ Valid`;
                                                                botInfo = `\n┃ *Bot:* @${tokenCheck.username}`;
                                                        } else {
                                                                tokenStatus = `❌ Invalid`;
                                                        }
                                                }
                                                
                                                let chatIdStatus = '❌ Belum diset';
                                                let chatInfo = '';
                                                if (telegramConfig.chatId && telegramConfig.token) {
                                                        const chatCheck = await validateChatId(telegramConfig.token, telegramConfig.chatId);
                                                        if (chatCheck.valid) {
                                                                chatIdStatus = `✅ Valid`;
                                                                chatInfo = `\n┃ *Chat:* ${chatCheck.chatTitle}`;
                                                        } else {
                                                                chatIdStatus = `❌ Invalid`;
                                                        }
                                                } else if (telegramConfig.chatId && !telegramConfig.token) {
                                                        chatIdStatus = '⚠️ Set token dulu';
                                                }
                                                
                                                let text = `╭═══『 *TELEGRAM NOTIF* 』═══╮\n`;
text += `│\n`;
text += `│ *Status:* ${statusText}\n`;
text += `│ *Token:* ${tokenStatus}${botInfo}\n`;
text += `│ *Chat ID:* ${chatIdStatus}${chatInfo}\n`;
text += `│\n`;
text += `│ *Penggunaan:*\n`;
text += `│ .telegram on - Aktifkan\n`;
text += `│ .telegram off - Nonaktifkan\n`;
text += `│ .telegram token <token>\n`;
text += `│ .telegram chatid <id>\n`;
text += `│ .telegram test - Test kirim\n`;
text += `│ .telegram tutorial - Cara dapat\n`;
text += `│\n`;
text += `│ *Info:*\n`;
text += `│ Fitur ini mengirim story WA\n`;
text += `│ ke bot Telegram kamu\n`;
text += `│\n`;
text += `│ _Multi-prefix, tanpa titik_\n`;
text += `│ _bot tetap merespon_\n`;
text += `╰═════════════════╯`;
                                                return text;
                                        };
                                        
                                        const showTutorial = () => {
                                                let text = `╭═══『 *TUTORIAL TELEGRAM* 』═══╮\n`;
text += `│\n`;
text += `│ *📱 CARA DAPAT BOT TOKEN:*\n`;
text += `│\n`;
text += `│ 1. Buka Telegram\n`;
text += `│ 2. Cari @BotFather\n`;
text += `│ 3. Ketik /newbot\n`;
text += `│ 4. Masukkan nama bot\n`;
text += `│ 5. Masukkan username bot\n`;
text += `│    (harus diakhiri 'bot')\n`;
text += `│ 6. Copy token yang diberikan\n`;
text += `│ 7. Gunakan:\n`;
text += `│    .telegram token <token>\n`;
text += `│\n`;
text += `│ *🆔 CARA DAPAT CHAT ID:*\n`;
text += `│\n`;
text += `│ 1. Buka Telegram\n`;
text += `│ 2. Cari @userinfobot\n`;
text += `│ 3. Klik Start\n`;
text += `│ 4. Bot akan kirim ID kamu\n`;
text += `│ 5. Copy angka ID tersebut\n`;
text += `│ 6. Gunakan:\n`;
text += `│    .telegram chatid <id>\n`;
text += `│\n`;
text += `│ *⚠️ PENTING:*\n`;
text += `│ Setelah dapat token, kamu\n`;
text += `│ HARUS chat bot kamu dulu\n`;
text += `│ (klik Start) agar bot bisa\n`;
text += `│ mengirim pesan ke kamu!\n`;
text += `│\n`;
text += `╰═════════════════════╯`;
                                                return text;
                                        };
                                        
                                        if (args.length === 0 || !validCommands.includes(args[0])) {
                                                await tolak(hisoka, m, await showHelp());
                                                break;
                                        }
                                        
                                        if (args[0] === 'tutorial' || args[0] === 'help') {
                                                await tolak(hisoka, m, showTutorial());
                                        } else if (args[0] === 'test' || args[0] === 'cek' || args[0] === 'check') {
                                                if (!telegramConfig.token || !telegramConfig.chatId) {
                                                        await tolak(hisoka, m, '❌ Token dan Chat ID harus diset dulu!\n\nGunakan .telegram tutorial untuk panduan.');
                                                        break;
                                                }
                                                
                                                try {
                                                        const testMsg = `✅ *Test Berhasil!*\n\nBot WhatsApp kamu berhasil terhubung ke Telegram.\n\n_Pesan ini dikirim pada ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}_`;
                                                        const res = await fetch(`https://api.telegram.org/bot${telegramConfig.token}/sendMessage`, {
                                                                method: 'POST',
                                                                headers: { 'Content-Type': 'application/json' },
                                                                body: JSON.stringify({
                                                                        chat_id: telegramConfig.chatId,
                                                                        text: testMsg,
                                                                        parse_mode: 'Markdown'
                                                                })
                                                        });
                                                        const data = await res.json();
                                                        
                                                        if (data.ok) {
                                                                await tolak(hisoka, m, '✅ Test berhasil! Cek Telegram kamu.');
                                                        } else {
                                                                await tolak(hisoka, m, `❌ Gagal: ${data.description}\n\nPastikan kamu sudah Start bot di Telegram.`);
                                                        }
                                                } catch (e) {
                                                        await tolak(hisoka, m, `❌ Error: ${e.message}`);
                                                }
                                        } else if (args[0] === 'on' || args[0] === 'true') {
                                                if (telegramConfig.enabled) {
                                                        await tolak(hisoka, m, 'ℹ️ Telegram notifikasi sudah aktif sebelumnya');
                                                } else {
                                                        config.telegram = { ...telegramConfig, enabled: true };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, '✅ Telegram notifikasi diaktifkan');
                                                }
                                        } else if (args[0] === 'off' || args[0] === 'false') {
                                                if (!telegramConfig.enabled) {
                                                        await tolak(hisoka, m, 'ℹ️ Telegram notifikasi sudah nonaktif sebelumnya');
                                                } else {
                                                        config.telegram = { ...telegramConfig, enabled: false };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, '❌ Telegram notifikasi dinonaktifkan');
                                                }
                                        } else if (args[0] === 'token' && args[1]) {
                                                const token = (m.query || '').replace(/^token\s*/i, '').trim();
                                                config.telegram = { ...telegramConfig, token: token };
                                                saveConfig(config);
                                                await tolak(hisoka, m, '✅ Token Telegram berhasil diupdate');
                                        } else if ((args[0] === 'chatid' || args[0] === 'chat_id' || args[0] === 'id') && args[1]) {
                                                const chatIdValue = (m.query || '').replace(/^(chatid|chat_id|id)\s*/i, '').trim();
                                                config.telegram = { ...telegramConfig, chatId: chatIdValue };
                                                saveConfig(config);
                                                await tolak(hisoka, m, '✅ Chat ID Telegram berhasil diupdate');
                                        } else if (args[0] === 'token' && !args[1]) {
                                                await tolak(hisoka, m, '❌ Format: .telegram token <bot_token>');
                                        } else if ((args[0] === 'chatid' || args[0] === 'chat_id' || args[0] === 'id') && !args[1]) {
                                                await tolak(hisoka, m, '❌ Format: .telegram chatid <chat_id>');
                                        } else {
                                                await tolak(hisoka, m, showHelp());
                                        }
                                        
                                        logCommand(m, hisoka, 'telegram');
                                } catch (error) {
                                        console.error('\x1b[31m[Telegram] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `Error: ${error.message}`);
                                }
                                break;
                        }

                        case 'add': {
                                if (!isMainBot(hisoka)) return;
                                if (!m.isOwner) return;
                                if (!query || !query.toLowerCase().startsWith('emoji')) break;
                                try {
                                        const { addEmojis, listEmojis } = await import('../helper/emoji.js');
                                        
                                        const emojiInput = query.replace(/^emoji\s*/i, '').trim();
                                        
                                        if (!emojiInput) {
                                                await tolak(hisoka, m, `❌ Format: add emoji 😊,😄,😁\n\nContoh:\nadd emoji 😊\nadd emoji 😊,😄,😁`);
                                                break;
                                        }

                                        const emojisToAdd = emojiInput.split(',').map(e => e.trim()).filter(e => e);
                                        
                                        if (emojisToAdd.length === 0) {
                                                await tolak(hisoka, m, '❌ Tidak ada emoji yang valid untuk ditambahkan');
                                                break;
                                        }

                                        const results = addEmojis(emojisToAdd);
                                        const newList = listEmojis();
                                        
                                        let response = `╭═══『 *ADD EMOJI* 』═══╮\n│\n`;

if (results.added.length > 0) {
    response += `│ ✅ *Berhasil (${results.added.length}):* ${results.added.join(',')}\n`;
}

if (results.alreadyExists.length > 0) {
    response += `│ ⚠️ *Sudah ada (${results.alreadyExists.length}):* ${results.alreadyExists.join(',')}\n`;
}

response += `│\n│ 📊 *Total:* ${newList.count} emoji\n`;
response += `│ *Daftar:* ${newList.emojis.join(',')}\n`;
response += `╰═════════════════╯`;
                                        
                                        await tolak(hisoka, m, response);
                                        logCommand(m, hisoka, 'add emoji');
                                } catch (error) {
                                        console.error('\x1b[31m[AddEmoji] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `Error: ${error.message}`);
                                }
                                break;
                        }

                        case 'del': {
                                if (!isMainBot(hisoka)) return;
                                if (!m.isOwner) return;
                                if (!query || !query.toLowerCase().startsWith('emoji')) break;
                                try {
                                        const { deleteEmojis, listEmojis } = await import('../helper/emoji.js');
                                        
                                        const emojiInput = query.replace(/^emoji\s*/i, '').trim();
                                        
                                        if (!emojiInput) {
                                                await tolak(hisoka, m, `❌ Format: del emoji 😊,😄\n\nContoh:\ndel emoji 😊\ndel emoji 😊,😄,😁`);
                                                break;
                                        }

                                        const emojisToDelete = emojiInput.split(',').map(e => e.trim()).filter(e => e);
                                        
                                        if (emojisToDelete.length === 0) {
                                                await tolak(hisoka, m, '❌ Tidak ada emoji yang valid untuk dihapus');
                                                break;
                                        }

                                        const results = deleteEmojis(emojisToDelete);
                                        const newList = listEmojis();
                                        
                                        let response = `╭═══『 *DEL EMOJI* 』═══╮\n│\n`;

if (results.deleted.length > 0) {
    response += `│ ✅ *Dihapus (${results.deleted.length}):* ${results.deleted.join(',')}\n`;
}

if (results.notFound.length > 0) {
    response += `│ ⚠️ *Tidak ada (${results.notFound.length}):* ${results.notFound.join(',')}\n`;
}

response += `│\n│ 📊 *Sisa:* ${newList.count} emoji\n`;
if (newList.emojis.length > 0) {
    response += `│ *Daftar:* ${newList.emojis.join(',')}\n`;
}
response += `╰═════════════════╯`;
                                        
                                        await tolak(hisoka, m, response);
                                        logCommand(m, hisoka, 'del emoji');
                                } catch (error) {
                                        console.error('\x1b[31m[DelEmoji] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `Error: ${error.message}`);
                                }
                                break;
                        }

                        case 'list': {
                                if (!isMainBot(hisoka)) return;
                                if (!m.isOwner) return;
                                if (!query || !query.toLowerCase().startsWith('emoji')) break;
                                try {
                                        const { listEmojis } = await import('../helper/emoji.js');
                                        const data = listEmojis();
                                        
                                        let response = `╭═══『 *LIST EMOJI* 』═══╮\n│\n`;
response += `│ 📊 *Total:* ${data.count} emoji\n│\n`;

if (data.emojis.length > 0) {
    response += `│ *Daftar:* ${data.emojis.join(',')}\n`;
} else {
    response += `│ ❌ Belum ada emoji tersimpan\n`;
}

response += `│\n│ *Command:*\n`;
response += `│ add emoji 😊,😄\n`;
response += `│ del emoji 😊,😄\n`;
response += `╰═════════════════╯`;
                                        
                                        await tolak(hisoka, m, response);
                                        logCommand(m, hisoka, 'list emoji');
                                } catch (error) {
                                        console.error('\x1b[31m[ListEmoji] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `Error: ${error.message}`);
                                }
                                break;
                        }

                        case 'addemoji': {
                                if (!isMainBot(hisoka)) return;
                                if (!m.isOwner) return;
                                try {
                                        const { addEmojis, listEmojis } = await import('../helper/emoji.js');

                                        if (!query) {
                                                await tolak(hisoka, m, `❌ Format salah!\n\nContoh:\n.addemoji 😊\n.addemoji 😊,😄,😁`);
                                                break;
                                        }

                                        const emojisToAdd = query.split(',').map(e => e.trim()).filter(e => e);

                                        if (emojisToAdd.length === 0) {
                                                await tolak(hisoka, m, '❌ Tidak ada emoji yang valid untuk ditambahkan');
                                                break;
                                        }

                                        const results = addEmojis(emojisToAdd);
                                        const newList = listEmojis();

                                        let response = `╭═══『 *ADD EMOJI* 』═══╮\n│\n`;
                                        if (results.added.length > 0) response += `│ ✅ *Ditambah (${results.added.length}):* ${results.added.join(' ')}\n`;
                                        if (results.alreadyExists.length > 0) response += `│ ⚠️ *Sudah ada (${results.alreadyExists.length}):* ${results.alreadyExists.join(' ')}\n`;
                                        response += `│\n│ 📊 *Total:* ${newList.count} emoji\n`;
                                        if (newList.emojis.length > 0) response += `│ *Daftar:* ${newList.emojis.join(' ')}\n`;
                                        response += `╰═════════════════╯`;

                                        await tolak(hisoka, m, response);
                                        logCommand(m, hisoka, 'addemoji');
                                } catch (error) {
                                        console.error('\x1b[31m[AddEmoji] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `❌ Error: ${error.message}`);
                                }
                                break;
                        }

                        case 'delemoji': {
                                if (!isMainBot(hisoka)) return;
                                if (!m.isOwner) return;
                                try {
                                        const { deleteEmojis, listEmojis } = await import('../helper/emoji.js');

                                        if (!query) {
                                                await tolak(hisoka, m, `❌ Format salah!\n\nContoh:\n.delemoji 😊\n.delemoji 😊,😄,😁`);
                                                break;
                                        }

                                        const emojisToDelete = query.split(',').map(e => e.trim()).filter(e => e);

                                        if (emojisToDelete.length === 0) {
                                                await tolak(hisoka, m, '❌ Tidak ada emoji yang valid untuk dihapus');
                                                break;
                                        }

                                        const results = deleteEmojis(emojisToDelete);
                                        const newList = listEmojis();

                                        let response = `╭═══『 *DEL EMOJI* 』═══╮\n│\n`;
                                        if (results.deleted.length > 0) response += `│ ✅ *Dihapus (${results.deleted.length}):* ${results.deleted.join(' ')}\n`;
                                        if (results.notFound.length > 0) response += `│ ⚠️ *Tidak ada (${results.notFound.length}):* ${results.notFound.join(' ')}\n`;
                                        response += `│\n│ 📊 *Sisa:* ${newList.count} emoji\n`;
                                        if (newList.emojis.length > 0) response += `│ *Daftar:* ${newList.emojis.join(' ')}\n`;
                                        response += `╰═════════════════╯`;

                                        await tolak(hisoka, m, response);
                                        logCommand(m, hisoka, 'delemoji');
                                } catch (error) {
                                        console.error('\x1b[31m[DelEmoji] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `❌ Error: ${error.message}`);
                                }
                                break;
                        }

                        case 'listemoji': {
                                if (!isMainBot(hisoka)) return;
                                if (!m.isOwner) return;
                                try {
                                        const { listEmojis } = await import('../helper/emoji.js');
                                        const data = listEmojis();

                                        let response = `╭═══『 *LIST EMOJI* 』═══╮\n│\n`;
                                        response += `│ 📊 *Total:* ${data.count} emoji\n│\n`;
                                        if (data.emojis.length > 0) {
                                                response += `│ *Daftar:* ${data.emojis.join(' ')}\n`;
                                        } else {
                                                response += `│ ❌ Belum ada emoji tersimpan\n`;
                                        }
                                        response += `│\n│ *Command:*\n`;
                                        response += `│ .addemoji 😊,😄\n`;
                                        response += `│ .delemoji 😊,😄\n`;
                                        response += `╰═════════════════╯`;

                                        await tolak(hisoka, m, response);
                                        logCommand(m, hisoka, 'listemoji');
                                } catch (error) {
                                        console.error('\x1b[31m[ListEmoji] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `❌ Error: ${error.message}`);
                                }
                                break;
                        }

                        case 'online': {
                                if (!isMainBot(hisoka)) return;
                                if (!m.isOwner) return;
                                try {
                                        const config = loadConfig();
                                        const autoOnline = config.autoOnline || { enabled: false, intervalSeconds: 30 };
                                        const args = query ? query.toLowerCase().split(' ') : [];
                                        
                                        if (args.length === 0) {
                                                let text = `╭═══『 *AUTO PRESENCE* 』═══╮\n│\n`;
text += `│ *Mode:* ${autoOnline.enabled ? '✅ ONLINE' : '🙈 OFFLINE (Stealth)'}\n`;
text += `│ *Interval:* ${autoOnline.intervalSeconds || 30} detik\n`;
text += `│ *Running:* ${global.autoOnlineInterval ? '✅ Yes' : '❌ No'}\n`;
text += `│\n`;
text += `│ *Penggunaan:*\n`;
text += `│ .online on - Terlihat Online\n`;
text += `│ .online off - Terlihat Offline\n`;
text += `│ .online set <detik> - Set interval\n`;
text += `│\n`;
text += `│ *Info:* Mode OFFLINE mengirim\n`;
text += `│ unavailable setiap ${autoOnline.intervalSeconds || 30}s agar\n`;
text += `│ tetap tersembunyi walaupun WA\n`;
text += `│ dibuka di HP\n`;
text += `│\n`;
text += `╰═════════════════╯`;
                                                await tolak(hisoka, m, text);
                                                break;
                                        }
                                        
                                        if (args[0] === 'on') {
                                                if (autoOnline.enabled) {
                                                        await tolak(hisoka, m, 'ℹ️ Auto Online sudah aktif sebelumnya');
                                                } else {
                                                        config.autoOnline = { ...autoOnline, enabled: true };
                                                        saveConfig(config);
                                                        if (global.startAutoOnline) {
                                                                global.startAutoOnline();
                                                        } else if (global.hisokaClient) {
                                                                global.hisokaClient.sendPresenceUpdate('available');
                                                        }
                                                        await tolak(hisoka, m, '✅ Auto Online diaktifkan - Anda terlihat online');
                                                }
                                        } else if (args[0] === 'off') {
                                                if (!autoOnline.enabled) {
                                                        await tolak(hisoka, m, 'ℹ️ Auto Online sudah nonaktif sebelumnya - Anda terlihat offline');
                                                } else {
                                                        config.autoOnline = { ...autoOnline, enabled: false };
                                                        saveConfig(config);
                                                        if (global.startAutoOnline) {
                                                                global.startAutoOnline();
                                                        } else {
                                                                if (global.autoOnlineInterval) {
                                                                        clearInterval(global.autoOnlineInterval);
                                                                        global.autoOnlineInterval = null;
                                                                }
                                                                if (global.hisokaClient) {
                                                                        global.hisokaClient.sendPresenceUpdate('unavailable');
                                                                }
                                                        }
                                                        console.log(`\x1b[33m[AutoOnline]\x1b[39m Switched to OFFLINE mode`);
                                                        await tolak(hisoka, m, '🙈 Auto Online dinonaktifkan - Mode stealth aktif, status terus tersembunyi');
                                                }
                                        } else if (args[0] === 'set' && args[1]) {
                                                const seconds = parseInt(args[1]);
                                                if (isNaN(seconds) || seconds < 10 || seconds > 300) {
                                                        await tolak(hisoka, m, '❌ Interval harus antara 10-300 detik');
                                                        break;
                                                }
                                                config.autoOnline = { ...autoOnline, intervalSeconds: seconds };
                                                saveConfig(config);
                                                let timerStatus = '';
                                                if (config.autoOnline.enabled) {
                                                        if (global.startAutoOnline) {
                                                                global.startAutoOnline();
                                                                timerStatus = ' (timer restarted)';
                                                        } else {
                                                                timerStatus = ' (akan aktif saat reconnect)';
                                                        }
                                                }
                                                await tolak(hisoka, m, `✅ Interval Auto Online diset ke ${seconds} detik${timerStatus}`);
                                        } else {
                                                await tolak(hisoka, m, '❌ Perintah tidak valid. Gunakan .online untuk melihat bantuan.');
                                        }
                                        
                                        logCommand(m, hisoka, 'online');
                                } catch (error) {
                                        console.error('\x1b[31m[Online] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `Error: ${error.message}`);
                                }
                                break;
                        }

                        case 'anticall':
                        case 'ac': {
                                if (!isMainBot(hisoka)) return;
                                if (!m.isOwner) return;
                                try {
                                        const config = loadConfig();
                                        const antiCall = config.antiCall || { enabled: false, message: '', whitelist: [] };
                                        const args = query ? query.split(' ') : [];
                                        const argLower = args[0] ? args[0].toLowerCase() : '';
                                        
                                        if (args.length === 0) {
                                                let text = `╭═══『 *ANTI CALL* 』═══╮\n│\n`;
text += `│ *Status:* ${antiCall.enabled ? '✅ Aktif' : '❌ Nonaktif'}\n`;
text += `│ *Pesan:* ${antiCall.message || '(kosong)'}\n`;
text += `│ *Whitelist:* ${(antiCall.whitelist || []).length} nomor\n`;
text += `│\n`;
text += `│ *Penggunaan:*\n`;
text += `│ .anticall on/off\n`;
text += `│ .anticall msg <pesan>\n`;
text += `│ .anticall list\n`;
text += `│ .anticall add <nomor>\n`;
text += `│ .anticall del <nomor>\n`;
text += `│ .anticall reset\n`;
text += `│\n`;
text += `│ *Info:* Nomor whitelist tidak\n`;
text += `│ akan di-reject panggilannya\n`;
text += `│\n`;
text += `╰═════════════════╯`;
                                                await tolak(hisoka, m, text);
                                                break;
                                        }
                                        
                                        if (argLower === 'on') {
                                                if (antiCall.enabled) {
                                                        await tolak(hisoka, m, 'ℹ️ Anti Call sudah aktif sebelumnya');
                                                } else {
                                                        config.antiCall = { ...antiCall, enabled: true };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, '✅ Anti Call diaktifkan - Panggilan suara akan otomatis ditolak');
                                                }
                                        } else if (argLower === 'off') {
                                                if (!antiCall.enabled) {
                                                        await tolak(hisoka, m, 'ℹ️ Anti Call sudah nonaktif sebelumnya');
                                                } else {
                                                        config.antiCall = { ...antiCall, enabled: false };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, '❌ Anti Call dinonaktifkan');
                                                }
                                        } else if (argLower === 'msg' || argLower === 'message' || argLower === 'pesan') {
                                                const newMsg = args.slice(1).join(' ');
                                                if (!newMsg) {
                                                        await tolak(hisoka, m, `📝 Pesan saat ini:\n\n${antiCall.message || '(kosong)'}\n\nGunakan: .anticall msg <pesan baru>`);
                                                } else {
                                                        config.antiCall = { ...antiCall, message: newMsg };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, `✅ Pesan Anti Call diubah menjadi:\n\n${newMsg}`);
                                                }
                                        } else if (argLower === 'list') {
                                                const whitelist = antiCall.whitelist || [];
                                                if (whitelist.length === 0) {
                                                        await tolak(hisoka, m, '📋 Whitelist Anti Call kosong\n\nGunakan .anticall add <nomor> untuk menambahkan');
                                                } else {
                                                        let text = `╭═══『 *WHITELIST ANTICALL* 』═══╮\n│\n`;
whitelist.forEach((num, i) => {
    text += `│ ${i + 1}. ${num}\n`;
});
text += `│\n╰═════════════════╯`;
                                                        await tolak(hisoka, m, text);
                                                }
                                        } else if (argLower === 'add') {
                                                const number = args[1] ? args[1].replace(/[^0-9]/g, '') : '';
                                                if (!number) {
                                                        await tolak(hisoka, m, '❌ Masukkan nomor!\n\nContoh: .anticall add 628123456789');
                                                        break;
                                                }
                                                const whitelist = antiCall.whitelist || [];
                                                if (whitelist.includes(number)) {
                                                        await tolak(hisoka, m, `ℹ️ Nomor ${number} sudah ada di whitelist`);
                                                } else {
                                                        whitelist.push(number);
                                                        config.antiCall = { ...antiCall, whitelist };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, `✅ Nomor ${number} ditambahkan ke whitelist Anti Call`);
                                                }
                                        } else if (argLower === 'del' || argLower === 'delete' || argLower === 'hapus') {
                                                const number = args[1] ? args[1].replace(/[^0-9]/g, '') : '';
                                                if (!number) {
                                                        await tolak(hisoka, m, '❌ Masukkan nomor!\n\nContoh: .anticall del 628123456789');
                                                        break;
                                                }
                                                const whitelist = antiCall.whitelist || [];
                                                const idx = whitelist.findIndex(n => n === number);
                                                if (idx === -1) {
                                                        await tolak(hisoka, m, `ℹ️ Nomor ${number} tidak ditemukan di whitelist`);
                                                } else {
                                                        whitelist.splice(idx, 1);
                                                        config.antiCall = { ...antiCall, whitelist };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, `✅ Nomor ${number} dihapus dari whitelist Anti Call`);
                                                }
                                        } else if (argLower === 'reset' || argLower === 'clear') {
                                                config.antiCall = { ...antiCall, whitelist: [] };
                                                saveConfig(config);
                                                await tolak(hisoka, m, '✅ Whitelist Anti Call direset');
                                        } else {
                                                await tolak(hisoka, m, '❌ Perintah tidak valid. Gunakan .anticall untuk melihat bantuan.');
                                        }
                                        
                                        logCommand(m, hisoka, 'anticall');
                                } catch (error) {
                                        console.error('\x1b[31m[AntiCall] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `Error: ${error.message}`);
                                }
                                break;
                        }

                        case 'anticallvid':
                        case 'acv': {
                                if (!isMainBot(hisoka)) return;
                                if (!m.isOwner) return;
                                try {
                                        const config = loadConfig();
                                        const antiCallVideo = config.antiCallVideo || { enabled: false, message: '', whitelist: [] };
                                        const args = query ? query.split(' ') : [];
                                        const argLower = args[0] ? args[0].toLowerCase() : '';
                                        
                                        if (args.length === 0) {
                                                let text = `╭═══『 *ANTI CALL VIDEO* 』═══╮\n│\n`;
text += `│ *Status:* ${antiCallVideo.enabled ? '✅ Aktif' : '❌ Nonaktif'}\n`;
text += `│ *Pesan:* ${antiCallVideo.message || '(kosong)'}\n`;
text += `│ *Whitelist:* ${(antiCallVideo.whitelist || []).length} nomor\n`;
text += `│\n`;
text += `│ *Penggunaan:*\n`;
text += `│ .anticallvid on/off\n`;
text += `│ .anticallvid msg <pesan>\n`;
text += `│ .anticallvid list\n`;
text += `│ .anticallvid add <nomor>\n`;
text += `│ .anticallvid del <nomor>\n`;
text += `│ .anticallvid reset\n`;
text += `│\n`;
text += `│ *Info:* Nomor whitelist tidak\n`;
text += `│ akan di-reject panggilannya\n`;
text += `│\n`;
text += `╰═════════════════╯`;
                                                await tolak(hisoka, m, text);
                                                break;
                                        }
                                        
                                        if (argLower === 'on') {
                                                if (antiCallVideo.enabled) {
                                                        await tolak(hisoka, m, 'ℹ️ Anti Call Video sudah aktif sebelumnya');
                                                } else {
                                                        config.antiCallVideo = { ...antiCallVideo, enabled: true };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, '✅ Anti Call Video diaktifkan - Panggilan video akan otomatis ditolak');
                                                }
                                        } else if (argLower === 'off') {
                                                if (!antiCallVideo.enabled) {
                                                        await tolak(hisoka, m, 'ℹ️ Anti Call Video sudah nonaktif sebelumnya');
                                                } else {
                                                        config.antiCallVideo = { ...antiCallVideo, enabled: false };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, '❌ Anti Call Video dinonaktifkan');
                                                }
                                        } else if (argLower === 'msg' || argLower === 'message' || argLower === 'pesan') {
                                                const newMsg = args.slice(1).join(' ');
                                                if (!newMsg) {
                                                        await tolak(hisoka, m, `📝 Pesan saat ini:\n\n${antiCallVideo.message || '(kosong)'}\n\nGunakan: .anticallvid msg <pesan baru>`);
                                                } else {
                                                        config.antiCallVideo = { ...antiCallVideo, message: newMsg };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, `✅ Pesan Anti Call Video diubah menjadi:\n\n${newMsg}`);
                                                }
                                        } else if (argLower === 'list') {
                                                const whitelist = antiCallVideo.whitelist || [];
                                                if (whitelist.length === 0) {
                                                        await tolak(hisoka, m, '📋 Whitelist Anti Call Video kosong\n\nGunakan .anticallvid add <nomor> untuk menambahkan');
                                                } else {
                                                        let text = `╭═══『 *WHITELIST ANTICALL VIDEO* 』═══╮\n│\n`;
whitelist.forEach((num, i) => {
    text += `│ ${i + 1}. ${num}\n`;
});
text += `│\n╰═════════════════╯`;
                                                        await tolak(hisoka, m, text);
                                                }
                                        } else if (argLower === 'add') {
                                                const number = args[1] ? args[1].replace(/[^0-9]/g, '') : '';
                                                if (!number) {
                                                        await tolak(hisoka, m, '❌ Masukkan nomor!\n\nContoh: .anticallvid add 628123456789');
                                                        break;
                                                }
                                                const whitelist = antiCallVideo.whitelist || [];
                                                if (whitelist.includes(number)) {
                                                        await tolak(hisoka, m, `ℹ️ Nomor ${number} sudah ada di whitelist`);
                                                } else {
                                                        whitelist.push(number);
                                                        config.antiCallVideo = { ...antiCallVideo, whitelist };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, `✅ Nomor ${number} ditambahkan ke whitelist Anti Call Video`);
                                                }
                                        } else if (argLower === 'del' || argLower === 'delete' || argLower === 'hapus') {
                                                const number = args[1] ? args[1].replace(/[^0-9]/g, '') : '';
                                                if (!number) {
                                                        await tolak(hisoka, m, '❌ Masukkan nomor!\n\nContoh: .anticallvid del 628123456789');
                                                        break;
                                                }
                                                const whitelist = antiCallVideo.whitelist || [];
                                                const idx = whitelist.findIndex(n => n === number);
                                                if (idx === -1) {
                                                        await tolak(hisoka, m, `ℹ️ Nomor ${number} tidak ditemukan di whitelist`);
                                                } else {
                                                        whitelist.splice(idx, 1);
                                                        config.antiCallVideo = { ...antiCallVideo, whitelist };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, `✅ Nomor ${number} dihapus dari whitelist Anti Call Video`);
                                                }
                                        } else if (argLower === 'reset' || argLower === 'clear') {
                                                config.antiCallVideo = { ...antiCallVideo, whitelist: [] };
                                                saveConfig(config);
                                                await tolak(hisoka, m, '✅ Whitelist Anti Call Video direset');
                                        } else {
                                                await tolak(hisoka, m, '❌ Perintah tidak valid. Gunakan .anticallvid untuk melihat bantuan.');
                                        }
                                        
                                        logCommand(m, hisoka, 'anticallvid');
                                } catch (error) {
                                        console.error('\x1b[31m[AntiCallVideo] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `Error: ${error.message}`);
                                }
                                break;
                        }

                        case 'autocleaner': {
                                if (!isMainBot(hisoka)) return;
                                if (!m.isOwner) return;
                                try {
                                        const config = loadConfig();
                                        const ac = config.autoCleaner || { enabled: true, intervalHours: 6 };
                                        const args = query ? query.toLowerCase().split(' ') : [];

                                        if (args.length === 0) {
                                                const statusText =
                                                        `╔════════════════════════╗\n` +
                                                        `║  🧹 *AUTO CLEANER*  🧹  ║\n` +
                                                        `╚════════════════════════╝\n\n` +
                                                        `📊 *Status:* ${ac.enabled !== false ? '✅ Aktif' : '❌ Nonaktif'}\n` +
                                                        `⏱️ *Interval:* Setiap ${ac.intervalHours || 6} jam\n\n` +
                                                        `📋 *Fungsi:*\n` +
                                                        `Hapus otomatis file sementara (hasil download) di folder tmp/ setiap beberapa jam.\n\n` +
                                                        `📋 *Perintah:*\n` +
                                                        `• *.autocleaner on* — Aktifkan\n` +
                                                        `• *.autocleaner off* — Nonaktifkan\n` +
                                                        `• *.autocleaner now* — Jalankan pembersihan sekarang`;
                                                await tolak(hisoka, m, statusText);
                                                break;
                                        }

                                        if (args[0] === 'on') {
                                                if (ac.enabled !== false) {
                                                        await tolak(hisoka, m, 'ℹ️ Auto Cleaner sudah aktif.');
                                                } else {
                                                        config.autoCleaner = { ...ac, enabled: true };
                                                        saveConfig(config);
                                                        restartAutoCleaner();
                                                        await tolak(hisoka, m, `✅ *Auto Cleaner diaktifkan!*\n\nFile tmp/ akan dibersihkan otomatis setiap ${ac.intervalHours || 6} jam.`);
                                                }
                                        } else if (args[0] === 'off') {
                                                if (ac.enabled === false) {
                                                        await tolak(hisoka, m, 'ℹ️ Auto Cleaner sudah nonaktif.');
                                                } else {
                                                        config.autoCleaner = { ...ac, enabled: false };
                                                        saveConfig(config);
                                                        stopAutoCleaner();
                                                        await tolak(hisoka, m, `✅ *Auto Cleaner dinonaktifkan.*\n\nFile tmp/ tidak akan dibersihkan otomatis.`);
                                                }
                                        } else if (args[0] === 'now') {
                                                const result = clearOldFiles(0);
                                                await tolak(hisoka, m, 
                                                        `✅ *Pembersihan selesai!*\n\n` +
                                                        `🗑️ File dihapus: ${result.deleted}\n` +
                                                        `💾 Ruang dibebaskan: ${result.sizeFormatted || '0 B'}`
                                                );
                                        } else {
                                                await tolak(hisoka, m, '❌ Perintah tidak valid.\n\nKetik *.autocleaner* untuk melihat bantuan.');
                                        }

                                        logCommand(m, hisoka, 'autocleaner');
                                } catch (error) {
                                        console.error('\x1b[31m[AutoCleaner Cmd] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `Terjadi kesalahan: ${error.message}`);
                                }
                                break;
                        }

                        case 'sessioncleaner': {
                                if (!isMainBot(hisoka)) return;
                                if (!m.isOwner) return;
                                try {
                                        const config = loadConfig();
                                        const sc = config.sessionCleaner || { enabled: true };
                                        const args = query ? query.toLowerCase().split(' ') : [];

                                        if (args.length === 0) {
                                                const statusText =
                                                        `╔══════════════════════════╗\n` +
                                                        `║  🔑 *SESSION CLEANER*  🔑  ║\n` +
                                                        `╚══════════════════════════╝\n\n` +
                                                        `📊 *Status:* ${sc.enabled !== false ? '✅ Aktif' : '❌ Nonaktif'}\n\n` +
                                                        `📋 *Fungsi:*\n` +
                                                        `Hapus otomatis pre-key & session WhatsApp yang sudah usang saat bot mulai. Menghemat memori dan storage.\n\n` +
                                                        `📋 *Perintah:*\n` +
                                                        `• *.sessioncleaner on* — Aktifkan\n` +
                                                        `• *.sessioncleaner off* — Nonaktifkan\n` +
                                                        `• *.sessioncleaner now* — Jalankan pembersihan session sekarang`;
                                                await tolak(hisoka, m, statusText);
                                                break;
                                        }

                                        if (args[0] === 'on') {
                                                if (sc.enabled !== false) {
                                                        await tolak(hisoka, m, 'ℹ️ Session Cleaner sudah aktif.');
                                                } else {
                                                        config.sessionCleaner = { enabled: true };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, `✅ *Session Cleaner diaktifkan!*\n\nPre-key & session lama akan dibersihkan otomatis saat bot mulai.`);
                                                }
                                        } else if (args[0] === 'off') {
                                                if (sc.enabled === false) {
                                                        await tolak(hisoka, m, 'ℹ️ Session Cleaner sudah nonaktif.');
                                                } else {
                                                        config.sessionCleaner = { enabled: false };
                                                        saveConfig(config);
                                                        await tolak(hisoka, m, `✅ *Session Cleaner dinonaktifkan.*\n\nPre-key & session lama tidak akan dibersihkan otomatis.`);
                                                }
                                        } else if (args[0] === 'now') {
                                                const sessionDir = global.sessionDir || '';
                                                if (!sessionDir) {
                                                        await tolak(hisoka, m, '❌ Direktori session tidak ditemukan.');
                                                        break;
                                                }
                                                cleanStaleSessionFiles(sessionDir, { skipConfigCheck: true });
                                                await tolak(hisoka, m, `✅ *Pembersihan session selesai!*\n\nPre-key & session lama sudah dibersihkan.`);
                                        } else {
                                                await tolak(hisoka, m, '❌ Perintah tidak valid.\n\nKetik *.sessioncleaner* untuk melihat bantuan.');
                                        }

                                        logCommand(m, hisoka, 'sessioncleaner');
                                } catch (error) {
                                        console.error('\x1b[31m[SessionCleaner Cmd] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `Terjadi kesalahan: ${error.message}`);
                                }
                                break;
                        }

                        case 'react':
                        case 'reaksi': {
                                try {
                                        const config = loadConfig();
                                        const reactConfig = config.reactApi || {};
                                        
                                        if (!reactConfig.enabled) {
                                                await tolak(hisoka, m, 'Mohon maaf, fitur react sedang tidak aktif saat ini. Silakan hubungi admin untuk mengaktifkannya.');
                                                break;
                                        }
                                        
                                        const apiKey = process.env.REACT_API_KEY || reactConfig.apiKey;
                                        if (!apiKey) {
                                                await tolak(hisoka, m, 'Mohon maaf, API key untuk fitur react belum dikonfigurasi. Silakan hubungi admin untuk mengaturnya.');
                                                break;
                                        }
                                        
                                        if (!query) {
                                                await tolak(hisoka, m, `╭═══ *REACT CHANNEL* ═══╮
│
│ 📌 *Kirim Reaksi ke Saluran/Channel*
│
│ *Format:*
│ .react [link] [emoji]
│
│ *Contoh Penggunaan:*
│ .react https://whatsapp.com/
│ channel/0029xxx/264 ♥️ 🙏🏻
│
│ *Keterangan:*
│ • Link: URL postingan channel
│ • Emoji: Reaksi (bisa lebih dari 1)
│
│ *Command Lainnya:*
│ • .cekreact - Cek saldo coin
│ • .setreactapi - Atur API key
│
╰══════════════════════╯`);
                                                break;
                                        }
                                        
                                        const [postLink, ...reactsArray] = query.split(' ');
                                        const reacts = reactsArray.join(', ');
                                        
                                        if (!postLink || !reacts) {
                                                await tolak(hisoka, m, `⚠️ *Format Tidak Lengkap!*

Gunakan format:
.react [link_post] [emoji1] [emoji2]

Contoh:
.react https://whatsapp.com/channel/xxx/123 ♥️ 🙏🏻`);
                                                break;
                                        }
                                        
                                        const loadingMsg = await tolak(hisoka, m, '⏳ Sedang memproses reaksi, mohon tunggu sebentar...');
                                        
                                        const axios = (await import('axios')).default;
                                        const apiUrl = reactConfig.apiUrl || 'https://foreign-marna-sithaunarathnapromax-9a005c2e.koyeb.app/api/channel/react-to-post';
                                        
                                        const requestData = {
                                                post_link: postLink,
                                                reacts: reacts
                                        };
                                        
                                        const headers = {
                                                'Accept': 'application/json, text/plain, */*',
                                                'Content-Type': 'application/json',
                                                'Authorization': `Bearer ${apiKey}`
                                        };
                                        
                                        const response = await axios.post(apiUrl, requestData, { headers, timeout: 30000 });
                                        const data = response.data;
                                        
                                        const emojiList = reacts.split(',').map(e => e.trim()).filter(e => e);
                                        const totalReactions = emojiList.length;
                                        
                                        let coinUsed = data.coinsUsed || data.coinUsed || data.coins_used || null;
                                        if (!coinUsed && data.message) {
                                                const coinMatch = data.message.match(/(\d+)\s*COIN/i);
                                                if (coinMatch) coinUsed = parseInt(coinMatch[1]);
                                        }
                                        if (!coinUsed) coinUsed = totalReactions;
                                        
                                        let coinRemaining = data.coinsRemaining || data.coinRemaining || data.coins_remaining || data.balance || data.remainingCoins || null;
                                        if (!coinRemaining && data.message) {
                                                const remainMatch = data.message.match(/remaining[:\s]*(\d+)/i) || data.message.match(/sisa[:\s]*(\d+)/i);
                                                if (remainMatch) coinRemaining = parseInt(remainMatch[1]);
                                        }
                                        
                                        let hasil = `╭═══ *REACT BERHASIL* ═══╮\n`;
hasil += `│\n`;
hasil += `│ ✅ *Status:* Sukses!\n`;
hasil += `│\n`;
hasil += `│ 📊 *Detail Reaksi:*\n`;
hasil += `│ ├ Emoji: ${emojiList.join(' ')}\n`;
hasil += `│ ├ Jumlah: ${totalReactions} reaksi\n`;
hasil += `│ └ Post: ...${postLink.slice(-20)}\n`;
hasil += `│\n`;
hasil += `│ 💰 *Info Coin:*\n`;
hasil += `│ ├ Terpakai: ${coinUsed} coin\n`;
hasil += `│ └ Sisa: ${coinRemaining !== null ? coinRemaining + ' coin' : 'Gunakan .cekreact'}\n`;
if (data.botResponse) {
    hasil += `│\n`;
    hasil += `│ 🤖 *Respon:* ${data.botResponse}\n`;
}
hasil += `│\n`;
hasil += `╰══════════════════════╯`;
                                        
                                        await m.reply({ edit: loadingMsg.key, text: hasil.trim() });
                                        logCommand(m, hisoka, 'react');
                                        
                                } catch (error) {
                                        console.error('\x1b[31m[React API] Error:\x1b[39m', error.message);
                                        
                                        let errorMessage = '';
                                        
                                        if (error.response) {
                                                const status = error.response.status;
                                                const responseData = error.response.data;
                                                
                                                if (status === 401 || status === 403) {
                                                        errorMessage = `🔐 *Akses Ditolak*\n\nMohon maaf, sepertinya ada masalah dengan otorisasi API. Silakan hubungi admin untuk memeriksa API key.\n\n💡 *Tips:* Pastikan API key masih valid dan belum kadaluarsa.`;
                                                } else if (status === 429) {
                                                        errorMessage = `⏰ *Batas Penggunaan Tercapai*\n\nMohon maaf, layanan sedang sibuk atau batas penggunaan sudah tercapai. Silakan coba lagi dalam beberapa saat.\n\n💡 *Tips:* Tunggu beberapa menit sebelum mencoba kembali.`;
                                                } else if (status === 400) {
                                                        errorMessage = `📋 *Format Tidak Valid*\n\nMohon maaf, format permintaan tidak sesuai.\n\n📝 *Pesan Server:* ${responseData?.message || 'Format tidak valid'}\n\n💡 *Tips:* Pastikan link dan emoji yang dimasukkan sudah benar.`;
                                                } else if (status === 404) {
                                                        errorMessage = `🔍 *Tidak Ditemukan*\n\nMohon maaf, layanan API tidak dapat ditemukan. Silakan hubungi admin untuk memeriksa konfigurasi.`;
                                                } else if (status >= 500) {
                                                        errorMessage = `🔧 *Server Sedang Bermasalah*\n\nMohon maaf, server sedang mengalami gangguan sementara. Silakan coba lagi dalam beberapa saat.\n\n💡 *Tips:* Jika masalah berlanjut, silakan hubungi admin.`;
                                                } else {
                                                        errorMessage = `⚠️ *Terjadi Kesalahan*\n\n📊 *Status:* ${status}\n📝 *Pesan:* ${responseData?.message || 'Terjadi kesalahan tidak diketahui'}\n\n💡 *Tips:* Silakan coba lagi atau hubungi admin jika masalah berlanjut.`;
                                                }
                                        } else if (error.code === 'ECONNABORTED' || error.message.includes('timeout')) {
                                                errorMessage = `⏱️ *Waktu Habis*\n\nMohon maaf, permintaan memakan waktu terlalu lama. Server mungkin sedang sibuk.\n\n💡 *Tips:* Silakan coba lagi dalam beberapa saat.`;
                                        } else if (error.request) {
                                                errorMessage = `🌐 *Tidak Dapat Terhubung*\n\nMohon maaf, tidak dapat terhubung ke server. Kemungkinan ada masalah jaringan atau server sedang tidak aktif.\n\n💡 *Tips:* Periksa koneksi internet atau coba lagi nanti.`;
                                        } else {
                                                errorMessage = `❌ *Terjadi Kesalahan*\n\nMohon maaf, terjadi kesalahan teknis: ${error.message}\n\n💡 *Tips:* Silakan coba lagi atau hubungi admin jika masalah berlanjut.`;
                                        }
                                        
                                        await tolak(hisoka, m, errorMessage);
                                }
                                break;
                        }

                        case 'cekreact':
                        case 'reactinfo': {
                                try {
                                        const config = loadConfig();
                                        const reactConfig = config.reactApi || {};
                                        
                                        const apiKey = process.env.REACT_API_KEY || reactConfig.apiKey;
                                        if (!apiKey) {
                                                await tolak(hisoka, m, 'Mohon maaf, API key untuk fitur react belum dikonfigurasi.');
                                                break;
                                        }
                                        
                                        const loadingMsg = await tolak(hisoka, m, '⏳ Mengambil informasi saldo...');
                                        
                                        const axios = (await import('axios')).default;
                                        const baseUrl = reactConfig.apiUrl || 'https://foreign-marna-sithaunarathnapromax-9a005c2e.koyeb.app/api/channel/react-to-post';
                                        const balanceUrl = baseUrl.replace('/react-to-post', '/balance') || 'https://foreign-marna-sithaunarathnapromax-9a005c2e.koyeb.app/api/channel/balance';
                                        
                                        const headers = {
                                                'Accept': 'application/json, text/plain, */*',
                                                'Content-Type': 'application/json',
                                                'Authorization': `Bearer ${apiKey}`
                                        };
                                        
                                        try {
                                                const response = await axios.get(balanceUrl, { headers, timeout: 15000 });
                                                const data = response.data;
                                                
                                                const balance = data.balance || data.coins || data.coin || data.saldo || 0;
                                                const used = data.used || data.totalUsed || data.coins_used || 0;
                                                const plan = data.plan || data.subscription || data.package || 'Standard';
                                                const expiry = data.expiry || data.expired || data.expiryDate || '-';
                                                
                                                let hasil = `╭═══ *INFO SALDO REACT* ═══╮\n`;
hasil += `│\n`;
hasil += `│ 💰 *Saldo Coin:* ${balance} coin\n`;
hasil += `│ 📊 *Total Terpakai:* ${used} coin\n`;
hasil += `│ 📦 *Paket:* ${plan}\n`;
if (expiry !== '-') {
    hasil += `│ 📅 *Berlaku Hingga:* ${expiry}\n`;
}
hasil += `│\n`;
hasil += `│ ✅ Status: Aktif\n`;
hasil += `│\n`;
hasil += `╰════════════════════════╯`;
                                                
                                                await m.reply({ edit: loadingMsg.key, text: hasil.trim() });
                                        } catch (balanceError) {
                                                const maskedKey = apiKey.slice(0, 10) + '...' + apiKey.slice(-5);
                                                let hasil = `╭═══ *INFO REACT API* ═══╮\n`;
hasil += `│\n`;
hasil += `│ 🔑 *API Key:* ${maskedKey}\n`;
hasil += `│ ✅ *Status:* ${reactConfig.enabled ? 'Aktif' : 'Nonaktif'}\n`;
hasil += `│ 🌐 *Server:* Terhubung\n`;
hasil += `│\n`;
hasil += `│ ℹ️ *Info:*\n`;
hasil += `│ Endpoint cek saldo tidak tersedia\n`;
hasil += `│ atau sedang dalam pemeliharaan.\n`;
hasil += `│ Silakan coba fitur .react\n`;
hasil += `│\n`;
hasil += `╰════════════════════════╯`;
                                                
                                                await m.reply({ edit: loadingMsg.key, text: hasil.trim() });
                                        }
                                        
                                        logCommand(m, hisoka, 'cekreact');
                                        
                                } catch (error) {
                                        console.error('\x1b[31m[CekReact] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `Mohon maaf, terjadi kesalahan saat mengecek saldo: ${error.message}`);
                                }
                                break;
                        }

                        case 'setreactapi':
                        case 'reactapi': {
                                try {
                                        if (!m.isOwner) {
                                                await tolak(hisoka, m, 'Mohon maaf, perintah ini hanya dapat digunakan oleh owner bot.');
                                                break;
                                        }
                                        
                                        if (!query) {
                                                const config = loadConfig();
                                                const reactConfig = config.reactApi || {};
                                                const currentKey = process.env.REACT_API_KEY || reactConfig.apiKey;
                                                const maskedKey = currentKey ? currentKey.slice(0, 10) + '...' + currentKey.slice(-5) : 'Belum diatur';
                                                
                                                await tolak(hisoka, m, `╭═══ *SETTING REACT API* ═══╮
│
│ 📌 *Cara Penggunaan:*
│ .setreactapi [api_key]
│
│ 📊 *Status Saat Ini:*
│ ├ Status: ${reactConfig.enabled ? '✅ Aktif' : '❌ Nonaktif'}
│ ├ API Key: ${maskedKey}
│ └ Server: Default
│
╰════════════════════════════╯`);
                                                break;
                                        }
                                        
                                        const newApiKey = query.trim();
                                        const config = loadConfig();
                                        
                                        if (!config.reactApi) {
                                                config.reactApi = {
                                                        enabled: true,
                                                        apiKey: '',
                                                        apiUrl: 'https://foreign-marna-sithaunarathnapromax-9a005c2e.koyeb.app/api/channel/react-to-post'
                                                };
                                        }
                                        
                                        config.reactApi.apiKey = newApiKey;
                                        saveConfig(config);
                                        
                                        const maskedKey = newApiKey.slice(0, 10) + '...' + newApiKey.slice(-5);
                                        await tolak(hisoka, m, `╭═══ *API KEY UPDATED* ═══╮
│
│ ✅ *Berhasil Diperbarui!*
│
│ 🔑 Key: ${maskedKey}
│ 📊 Status: Aktif
│
│ 💡 Fitur react siap digunakan
│
╰═════════════════════════╯`);
                                        logCommand(m, hisoka, 'setreactapi');
                                        
                                } catch (error) {
                                        console.error('\x1b[31m[SetReactAPI] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `Mohon maaf, terjadi kesalahan saat mengatur API key: ${error.message}`);
                                }
                                break;
                        }

                        case 'tt': {
                                try {
                                        if (!query) {
                                                await tolak(hisoka, m, '❌ Masukkan link TikTok!\n\nContoh: .tt https://vt.tiktok.com/xxx\nAtau: .tt https://www.tiktok.com/@user/video/xxx');
                                                break;
                                        }
                                        
                                        const ttUrl = query.trim();
                                        if (!ttUrl.includes('tiktok.com') && !ttUrl.includes('tiktok')) {
                                                await tolak(hisoka, m, '❌ Link tidak valid! Pastikan link dari TikTok.');
                                                break;
                                        }
                                        
                                        const loadingMsg = await tolak(hisoka, m, '⏳ Sedang mengunduh dari TikTok...');
                                        
                                        const { Downloader } = await import('@tobyg74/tiktok-api-dl');
                                        
                                        let result = null;
                                        let lastError = null;
                                        
                                        // Coba v3 dulu (URL paling bersih), lalu v2, lalu v1
                                        const versions = ['v3', 'v2', 'v1'];
                                        for (const version of versions) {
                                                try {
                                                        const res = await Downloader(ttUrl, { version });
                                                        if (res && res.status === 'success' && res.result) {
                                                                result = res;
                                                                console.log('[TikTok] Success with version:', version);
                                                                break;
                                                        }
                                                } catch (e) {
                                                        lastError = e;
                                                        continue;
                                                }
                                        }
                                        
                                        if (!result || result.status !== 'success') {
                                                await m.reply({ edit: loadingMsg.key, text: '❌ Gagal mengunduh. Video mungkin privat atau link tidak valid.' });
                                                break;
                                        }
                                        
                                        const data = result.result;
                                        const author = data.author || {};
                                        const stats = data.statistics || data.stats || {};
                                        const desc = data.description || data.desc || '';
                                        
                                        const formatNum = (num) => {
                                                if (!num || num === 0) return null;
                                                const n = parseInt(num) || 0;
                                                if (isNaN(n) || n === 0) return null;
                                                return n.toLocaleString('id-ID');
                                        };
                                        
                                        const playCount = formatNum(stats.playCount || stats.play_count || stats.views || data.playCount);
                                        const likeCount = formatNum(stats.likeCount || stats.like_count || stats.likes || stats.diggCount || data.likeCount);
                                        const commentCount = formatNum(stats.commentCount || stats.comment_count || stats.comments || data.commentCount);
                                        const shareCount = formatNum(stats.shareCount || stats.share_count || stats.shares || data.shareCount);
                                        
                                        let infoText = `╭═══ *TIKTOK DOWNLOADER* ═══╮\n`;
infoText += `│ 👤 @${author.nickname || author.username || author.unique_id || data.author?.nickname || 'Unknown'}\n`;
if (playCount) infoText += `│ 👁️ ${playCount} views\n`;
if (likeCount) infoText += `│ ❤️ ${likeCount} likes\n`;
if (commentCount) infoText += `│ 💬 ${commentCount} comments\n`;
if (shareCount) infoText += `│ 🔄 ${shareCount} shares\n`;
if (desc) {
    const shortDesc = desc.length > 300 ? desc.substring(0, 300) + '...' : desc;
    infoText += `│\n│ 📝 ${shortDesc}\n`;
}
infoText += `╰════════════════════════╯`;
                                        
                                        await m.reply({ edit: loadingMsg.key, text: '✅ Berhasil! Mengirim media...' });
                                        
                                        // Ekstrak video URL — handle format v3 (videoHD/videoSD) dan v2 (video.playAddr sebagai array)
                                        const pickUrl = (val) => {
                                                if (!val) return null;
                                                if (typeof val === 'string') return val;
                                                if (Array.isArray(val)) return val[0] || null;
                                                return null;
                                        };
                                        
                                        let videoUrl = null;
                                        
                                        // v3 format: videoHD / videoSD / videoWatermark langsung di root
                                        videoUrl = pickUrl(data.videoHD) || pickUrl(data.videoSD) || pickUrl(data.videoWatermark);
                                        
                                        // v2/v1 format: nested di dalam data.video
                                        if (!videoUrl && data.video) {
                                                if (typeof data.video === 'string') {
                                                        videoUrl = data.video;
                                                } else if (Array.isArray(data.video)) {
                                                        videoUrl = data.video[0];
                                                } else {
                                                        videoUrl = pickUrl(data.video.playAddr)
                                                                || pickUrl(data.video.downloadAddr)
                                                                || pickUrl(data.video.noWatermark);
                                                }
                                        }
                                        
                                        if (videoUrl) {
                                                try {
                                                        await hisoka.sendMessage(m.from, {
                                                                video: { url: videoUrl },
                                                                caption: infoText
                                                        }, { quoted: m });
                                                } catch (videoErr) {
                                                        console.log('[TikTok] Video send failed:', videoErr.message);
                                                        await tolak(hisoka, m, '⚠️ Gagal mengirim video. Coba lagi nanti.');
                                                }
                                        }
                                        
                                        if (!videoUrl) {
                                                const images = data.images || data.image || [];
                                                if (images.length > 0) {
                                                        await tolak(hisoka, m, `📸 Slide TikTok ditemukan (${images.length} gambar)`);
                                                        for (let i = 0; i < Math.min(images.length, 10); i++) {
                                                                const imgUrl = pickUrl(images[i]) || images[i];
                                                                if (!imgUrl) continue;
                                                                try {
                                                                        await hisoka.sendMessage(m.from, {
                                                                                image: { url: imgUrl },
                                                                                caption: i === 0 ? infoText : `📷 ${i + 1}/${images.length}`
                                                                        }, { quoted: m });
                                                                } catch (imgErr) {
                                                                        console.log('[TikTok] Image send failed:', imgErr.message);
                                                                }
                                                        }
                                                } else {
                                                        await tolak(hisoka, m, '❌ Media tidak ditemukan dalam video ini.');
                                                }
                                        }
                                        
                                        logCommand(m, hisoka, 'tiktok');
                                } catch (error) {
                                        console.error('\x1b[31m[TikTok] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `❌ Error: ${error.message}`);
                                }
                                break;
                        }

                        case 'ig': {
                                try {
                                        if (!query) {
                                                await tolak(hisoka, m, '❌ Masukkan link Instagram!\n\nContoh: .ig https://www.instagram.com/reel/xxx');
                                                break;
                                        }
                                        
                                        const igRaw = query.trim();
                                        if (!igRaw.includes('instagram.com')) {
                                                await tolak(hisoka, m, '❌ Link tidak valid! Pastikan link dari Instagram.');
                                                break;
                                        }
                                        
                                        // Clean URL: strip query params & trailing slash to get a clean link
                                        let igUrl = igRaw;
                                        try {
                                                const parsed = new URL(igRaw);
                                                igUrl = parsed.origin + parsed.pathname.replace(/\/$/, '') + '/';
                                        } catch (_) {}
                                        
                                        const loadingMsg = await tolak(hisoka, m, '⏳ Sedang mengunduh dari Instagram...');
                                        
                                        // Try multiple APIs in order until one succeeds
                                        const igApis = [
                                                `https://archive.lick.eu.org/api/download/instagram?url=${encodeURIComponent(igUrl)}`,
                                                `https://api.cenedril.net/api/dl/ig?url=${encodeURIComponent(igUrl)}`,
                                                `https://api.agatz.xyz/api/instagram?url=${encodeURIComponent(igUrl)}`,
                                        ];
                                        
                                        let data = null;
                                        for (const apiUrl of igApis) {
                                                try {
                                                        const res = await fetch(apiUrl, { signal: AbortSignal.timeout(12000) });
                                                        const json = await res.json();
                                                        if (json.status && json.result) {
                                                                data = json;
                                                                break;
                                                        }
                                                } catch (_) {}
                                        }
                                        
                                        if (!data || !data.result) {
                                                await m.reply({ edit: loadingMsg.key, text: '❌ Gagal mengunduh. Pastikan link benar dan akun tidak private, lalu coba lagi.' });
                                                break;
                                        }
                                        
                                        const result = data.result;
                                        const mediaUrls = result.url || [];
                                        const caption = result.caption || '';
                                        const username = result.username || 'Unknown';
                                        const likes = result.like || 0;
                                        const comments = result.comment || 0;
                                        const isVideo = result.isVideo;
                                        
                                        let infoText = `╭═══ *INSTAGRAM DOWNLOADER* ═══╮\n`;
infoText += `│ 👤 @${username}\n`;
infoText += `│ ❤️ ${likes.toLocaleString()} likes\n`;
infoText += `│ 💬 ${comments.toLocaleString()} comments\n`;
if (caption) {
    const shortCaption = caption.length > 200 ? caption.substring(0, 200) + '...' : caption;
    infoText += `│\n│ 📝 ${shortCaption}\n`;
}
infoText += `╰════════════════════════╯`;
                                        
                                        if (mediaUrls.length === 0) {
                                                await m.reply({ edit: loadingMsg.key, text: '❌ Media tidak ditemukan.' });
                                                break;
                                        }
                                        
                                        await m.reply({ edit: loadingMsg.key, text: '✅ Berhasil! Mengirim media...' });
                                        
                                        for (let i = 0; i < mediaUrls.length; i++) {
                                                const mediaItem = mediaUrls[i];
                                                const isFirstMedia = i === 0;
                                                
                                                // Support both string URLs and object items {url, type}
                                                const mediaUrl = typeof mediaItem === 'object' ? (mediaItem.url || mediaItem.src || mediaItem) : mediaItem;
                                                
                                                // Detect per-item type: check object type property, else check URL extension, else fall back to global isVideo
                                                let itemIsVideo = isVideo;
                                                if (typeof mediaItem === 'object' && mediaItem.type) {
                                                        itemIsVideo = mediaItem.type === 'video' || mediaItem.type === 'GraphVideo';
                                                } else {
                                                        const urlStr = String(mediaUrl).toLowerCase().split('?')[0];
                                                        if (urlStr.endsWith('.mp4') || urlStr.endsWith('.mov') || urlStr.endsWith('.webm')) {
                                                                itemIsVideo = true;
                                                        } else if (urlStr.endsWith('.jpg') || urlStr.endsWith('.jpeg') || urlStr.endsWith('.png') || urlStr.endsWith('.webp')) {
                                                                itemIsVideo = false;
                                                        }
                                                }
                                                
                                                try {
                                                        if (itemIsVideo) {
                                                                await hisoka.sendMessage(m.from, {
                                                                        video: { url: mediaUrl },
                                                                        caption: isFirstMedia ? infoText : ''
                                                                }, { quoted: m });
                                                        } else {
                                                                await hisoka.sendMessage(m.from, {
                                                                        image: { url: mediaUrl },
                                                                        caption: isFirstMedia ? infoText : ''
                                                                }, { quoted: m });
                                                        }
                                                } catch (sendErr) {
                                                        console.error(`[IG] Failed to send media ${i + 1}:`, sendErr.message);
                                                }
                                        }
                                        
                                        logCommand(m, hisoka, 'instagram');
                                } catch (error) {
                                        console.error('\x1b[31m[Instagram] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `❌ Error: ${error.message}`);
                                }
                                break;
                        }

                        case 'fb': {
                                try {
                                        if (!query) {
                                                await tolak(hisoka, m, '❌ Masukkan link Facebook!\n\nContoh:\n.fb https://www.facebook.com/watch?v=xxx\n.fb https://fb.watch/xxx\n.fb https://www.facebook.com/reel/xxx\n.fb https://www.facebook.com/stories/xxx');
                                                break;
                                        }
                                        
                                        const fbUrl = query.trim();
                                        if (!fbUrl.includes('facebook.com') && !fbUrl.includes('fb.watch') && !fbUrl.includes('fb.com')) {
                                                await tolak(hisoka, m, '❌ Link tidak valid! Pastikan link dari Facebook.');
                                                break;
                                        }
                                        
                                        const loadingMsg = await tolak(hisoka, m, '⏳ Sedang mengunduh dari Facebook...');
                                        
                                        const isStory = fbUrl.includes('/stories/') || fbUrl.includes('story.php') || fbUrl.includes('/story/');
                                        
                                        let mediaData = null;
                                        
                                        // Method 1: archive.lick.eu.org (primary)
                                        try {
                                                const apiUrl = `https://archive.lick.eu.org/api/download/facebook?url=${encodeURIComponent(fbUrl)}`;
                                                const response = await fetch(apiUrl, { signal: AbortSignal.timeout(20000) });
                                                const data = await response.json();
                                                
                                                if (data.status && data.result && data.result.media && data.result.media.length > 0) {
                                                        const mediaList = data.result.media;
                                                        const hdMedia = mediaList.find(m => m.quality && (m.quality.toLowerCase().includes('hd') || m.quality.toLowerCase().includes('high')));
                                                        const bestMedia = hdMedia || mediaList[0];
                                                        if (bestMedia && bestMedia.url) {
                                                                mediaData = {
                                                                        url: bestMedia.url,
                                                                        quality: hdMedia ? 'HD' : 'SD',
                                                                        isHD: !!hdMedia,
                                                                        title: data.result.metadata?.title || '',
                                                                        isVideo: true
                                                                };
                                                        }
                                                }
                                        } catch (e) {
                                                console.log('[FB] archive.lick failed:', e.message);
                                        }
                                        
                                        // Method 2: direct page scraping via axios (Chrome user-agent, allow redirects)
                                        if (!mediaData) {
                                                try {
                                                        const axios = (await import('axios')).default;
                                                        const { data: pageData } = await axios.get(fbUrl, {
                                                                maxRedirects: 10,
                                                                headers: {
                                                                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                                                                        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                                                        'accept-language': 'en-US,en;q=0.5',
                                                                        'sec-fetch-dest': 'document',
                                                                        'sec-fetch-mode': 'navigate',
                                                                        'sec-fetch-site': 'none',
                                                                },
                                                                timeout: 20000
                                                        });
                                                        
                                                        const cleaned = pageData.replace(/&quot;/g, '"').replace(/&amp;/g, '&');
                                                        
                                                        const hdMatch = cleaned.match(/"browser_native_hd_url":"([^"]+)"/) || cleaned.match(/"playable_url_quality_hd":"([^"]+)"/);
                                                        const sdMatch = cleaned.match(/"browser_native_sd_url":"([^"]+)"/) || cleaned.match(/"playable_url":"([^"]+)"/);
                                                        
                                                        const hdUrl = hdMatch ? hdMatch[1].replace(/\\/g, '') : null;
                                                        const sdUrl = sdMatch ? sdMatch[1].replace(/\\/g, '') : null;
                                                        
                                                        const videoUrl = hdUrl || sdUrl;
                                                        if (videoUrl && videoUrl.startsWith('https://')) {
                                                                mediaData = {
                                                                        url: videoUrl,
                                                                        quality: hdUrl ? 'HD' : 'SD',
                                                                        isHD: !!hdUrl,
                                                                        isVideo: true
                                                                };
                                                                console.log('[FB] direct scraping success:', hdUrl ? 'HD' : 'SD');
                                                        }
                                                } catch (e) {
                                                        console.log('[FB] direct scraping failed:', e.message);
                                                }
                                        }
                                        
                                        if (!mediaData || !mediaData.url) {
                                                await m.reply({ edit: loadingMsg.key, text: '❌ Gagal mengunduh. Video/story mungkin private, perlu login, atau link tidak valid.' });
                                                break;
                                        }
                                        
                                        let infoText = `╭═══ *FACEBOOK DOWNLOADER* ═══╮\n`;
infoText += `│ 📌 Tipe: ${isStory ? 'Story' : 'Video/Reel'}\n`;
infoText += `│ 🎬 Kualitas: ${mediaData.quality}\n`;
if (mediaData.duration) {
    infoText += `│ ⏱️ Durasi: ${mediaData.duration}\n`;
}
if (mediaData.title) {
    const shortTitle = mediaData.title.length > 50 ? mediaData.title.substring(0, 50) + '...' : mediaData.title;
    infoText += `│ 📝 ${shortTitle}\n`;
}
infoText += `╰════════════════════════╯`;
                                        
                                        await m.reply({ edit: loadingMsg.key, text: '✅ Berhasil! Mengirim media...' });
                                        
                                        if (mediaData.isVideo !== false) {
                                                await hisoka.sendMessage(m.from, {
                                                        video: { url: mediaData.url },
                                                        caption: infoText
                                                }, { quoted: m });
                                        } else {
                                                await hisoka.sendMessage(m.from, {
                                                        image: { url: mediaData.url },
                                                        caption: infoText
                                                }, { quoted: m });
                                        }
                                        
                                        logCommand(m, hisoka, 'facebook');
                                } catch (error) {
                                        console.error('\x1b[31m[Facebook] Error:\x1b[39m', error.message);
                                        await tolak(hisoka, m, `❌ Error: ${error.message}`);
                                }
                                break;
                        }

                        case 's': {
                                try {
                                        const sharp = (await import('sharp')).default;
                                        const config = loadConfig();
                                        const stickerConfig = config.sticker || { pack: 'WhatsApp Bot', author: 'Wilykun' };
                                        
                                        const args = query ? query.split(' ') : [];
                                        
                                        if (args[0] === 'author' || args[0] === 'pack') {
                                                const type = args[0];
                                                let value = args.slice(1).join(' ').trim();
                                                
                                                if (!value) {
                                                        await tolak(hisoka, m, `❌ Masukkan nama ${type}!\n\nContoh: .s ${type} ${type === 'author' ? 'Wily' : 'Bot Pack'}`);
                                                        break;
                                                }
                                                
                                                if (value.length > 50) {
                                                        value = value.substring(0, 50);
                                                }
                                                
                                                const freshConfig = loadConfig();
                                                if (!freshConfig.sticker) {
                                                        freshConfig.sticker = { pack: 'WhatsApp Bot', author: 'Wilykun' };
                                                }
                                                freshConfig.sticker[type] = value;
                                                saveConfig(freshConfig);
                                                
                                                await tolak(hisoka, m, `✅ Sticker ${type} berhasil diubah menjadi: *${value}*`);
                                                logCommand(m, hisoka, `sticker-set-${type}`);
                                                break;
                                        }
                                        
                                        if (!m.isQuoted && !m.isMedia) {
                                                if (query) break;
                                                const freshConfig = loadConfig();
                                                const freshStickerConfig = freshConfig.sticker || { pack: 'WhatsApp Bot', author: 'Wilykun' };
                                                let text = `╭═══『 *STICKER MAKER* 』═══╮\n│\n`;
text += `│ *Pack:* ${freshStickerConfig.pack}\n`;
text += `│ *Author:* ${freshStickerConfig.author}\n`;
text += `│\n`;
text += `│ *Cara Pakai:*\n`;
text += `│ • Kirim/reply gambar/video dengan .s\n`;
text += `│ • .s author <nama> - Set author\n`;
text += `│ • .s pack <nama> - Set pack name\n`;
text += `│\n`;
text += `╰═════════════════╯`;
                                                await tolak(hisoka, m, text);
                                                break;
                                        }
                                        
                                        await hisoka.sendMessage(m.from, { react: { text: '⏳', key: m.key } });
                                        
                                        let mediaBuffer;
                                        let mediaType;
                                        
                                        if (m.isMedia && (m.type === 'imageMessage' || m.type === 'videoMessage')) {
                                                mediaBuffer = await m.downloadMedia();
                                                mediaType = m.type;
                                        } else if (m.isQuoted && quoted.isMedia && (quoted.type === 'imageMessage' || quoted.type === 'videoMessage')) {
                                                mediaBuffer = await downloadMediaMessage(
                                                        { ...m.quoted, message: m.quoted.raw },
                                                        'buffer',
                                                        {},
                                                        { logger: hisoka.logger, reuploadRequest: hisoka.updateMediaMessage }
                                                );
                                                mediaType = quoted.type;
                                        } else {
                                                await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                                await tolak(hisoka, m, '❌ Reply/kirim gambar atau video untuk membuat sticker!');
                                                break;
                                        }
                                        
                                        if (!mediaBuffer || mediaBuffer.length === 0) {
                                                await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                                await tolak(hisoka, m, '❌ Gagal download media');
                                                break;
                                        }
                                        
                                        const freshConfig = loadConfig();
                                        const freshStickerConfig = freshConfig.sticker || { pack: 'WhatsApp Bot', author: 'Wilykun' };
                                        
                                        const { Sticker, StickerTypes } = await import('wa-sticker-formatter');
                                        
                                        const sticker = new Sticker(mediaBuffer, {
                                                pack: freshStickerConfig.pack,
                                                author: freshStickerConfig.author,
                                                type: StickerTypes.FULL,
                                                categories: ['😀'],
                                                id: 'com.wilykun.wabot',
                                                quality: 80
                                        });
                                        
                                        const stickerBuffer = await sticker.toBuffer();
                                        
                                        if (!stickerBuffer || stickerBuffer.length === 0) {
                                                await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                                await tolak(hisoka, m, '❌ Gagal membuat sticker');
                                                break;
                                        }
                                        
                                        await hisoka.sendMessage(m.from, {
                                                sticker: stickerBuffer
                                        }, { quoted: m });
                                        
                                        await hisoka.sendMessage(m.from, { react: { text: '✅', key: m.key } });
                                        logCommand(m, hisoka, 'sticker');
                                } catch (error) {
                                        console.error('\x1b[31m[Sticker] Error:\x1b[39m', error.message);
                                        await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                        await tolak(hisoka, m, `❌ Error: ${error.message}`);
                                }
                                break;
                        }

                        case 'toimg': {
                                try {
                                        const sharp = (await import('sharp')).default;
                                        
                                        if (!m.isQuoted || quoted.type !== 'stickerMessage') {
                                                if (query) break;
                                                await tolak(hisoka, m, '❌ Reply sticker untuk dijadikan gambar!');
                                                break;
                                        }
                                        
                                        await hisoka.sendMessage(m.from, { react: { text: '⏳', key: m.key } });
                                        
                                        const stickerBuffer = await downloadMediaMessage(
                                                { ...m.quoted, message: m.quoted.raw },
                                                'buffer',
                                                {},
                                                { logger: hisoka.logger, reuploadRequest: hisoka.updateMediaMessage }
                                        );
                                        
                                        if (!stickerBuffer || stickerBuffer.length === 0) {
                                                await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                                await tolak(hisoka, m, '❌ Gagal download sticker');
                                                break;
                                        }
                                        
                                        let imageBuffer;
                                        
                                        try {
                                                imageBuffer = await sharp(stickerBuffer)
                                                        .png()
                                                        .toBuffer();
                                        } catch (sharpError) {
                                                console.log('[Toimg] Sharp failed, trying ffmpeg:', sharpError.message);
                                                const ffmpegExec = util.promisify(exec);
                                                const timestamp = Date.now();
                                                const tempInput = `/tmp/toimg_input_${timestamp}.webp`;
                                                const tempOutput = `/tmp/toimg_output_${timestamp}.png`;
                                                
                                                fs.writeFileSync(tempInput, stickerBuffer);
                                                
                                                try {
                                                        await ffmpegExec(
                                                                `ffmpeg -y -i "${tempInput}" -vframes 1 "${tempOutput}"`,
                                                                { timeout: 30000 }
                                                        );
                                                        if (fs.existsSync(tempOutput)) {
                                                                imageBuffer = fs.readFileSync(tempOutput);
                                                        }
                                                } finally {
                                                        if (fs.existsSync(tempInput)) fs.unlinkSync(tempInput);
                                                        if (fs.existsSync(tempOutput)) fs.unlinkSync(tempOutput);
                                                }
                                        }
                                        
                                        if (!imageBuffer || imageBuffer.length === 0) {
                                                await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                                await tolak(hisoka, m, '❌ Gagal convert sticker ke gambar. Sticker mungkin dalam format yang tidak didukung.');
                                                break;
                                        }
                                        
                                        await hisoka.sendMessage(m.from, {
                                                image: imageBuffer,
                                                caption: '✅ Sticker berhasil diconvert ke gambar!'
                                        }, { quoted: m });
                                        
                                        await hisoka.sendMessage(m.from, { react: { text: '✅', key: m.key } });
                                        logCommand(m, hisoka, 'toimg');
                                } catch (error) {
                                        console.error('\x1b[31m[Toimg] Error:\x1b[39m', error.message);
                                        await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                        await tolak(hisoka, m, `❌ Error: ${error.message}`);
                                }
                                break;
                        }
                                
                        case 'jadibot': {
                                if (!isMainBot(hisoka)) return;
                                if (!m.isOwner) return;

                                const jbPfx = m.prefix || '.';
                                const jbCtx = {
                                        stanzaId: m.key.id,
                                        participant: m.sender,
                                        quotedMessage: m.message
                                };

                                const sendJbBtn = async (bodyText, addBtns = (b) => b) => {
                                        try {
                                                await addBtns(
                                                        new Button()
                                                                .setBody(bodyText)
                                                                .setFooter(`🤖 Wily Bot · Jadibot Manager`)
                                                                .setContextInfo(jbCtx)
                                                )
                                                        .addReply('📋 List Jadibot', `${jbPfx}listjadibot`)
                                                        .run(m.from, hisoka, m);
                                        } catch {
                                                await tolak(hisoka, m, bodyText);
                                        }
                                };

                                let number = (query || '').replace(/[^0-9]/g, '');

                                if (!number) {
                                        const activeList = [...jadibotMap.keys()];
                                        const activeInfo = activeList.length
                                                ? `📊 *Bot aktif sekarang: ${activeList.length}*`
                                                : `📭 Belum ada jadibot aktif.`;
                                        await sendJbBtn(
                                                `╔══════════════════════╗\n` +
                                                `║   🤖  *J A D I B O T*  ║\n` +
                                                `╚══════════════════════╝\n\n` +
                                                `❌ *Nomor tidak boleh kosong!*\n\n` +
                                                `📌 *Cara pakai:*\n` +
                                                `_${jbPfx}jadibot 628xxxxxxxxxx_\n\n` +
                                                `${activeInfo}`
                                        );
                                        break;
                                }

                                if (number.startsWith('08'))
                                        number = '62' + number.slice(1);

                                if (jadibotMap.has(number)) {
                                        await sendJbBtn(
                                                `╔══════════════════════╗\n` +
                                                `║   🤖  *J A D I B O T*  ║\n` +
                                                `╚══════════════════════╝\n\n` +
                                                `⚠️ *Nomor sudah aktif!*\n` +
                                                `+${maskNumber(number)} sedang berjalan sebagai jadibot.\n\n` +
                                                `💡 Hentikan dulu sebelum mulai ulang.`,
                                                (b) => b.addReply('🛑 Stop Bot Ini', `${jbPfx}stopjadibot ${number}`)
                                        );
                                        break;
                                }

                                const mainNum = hisoka.mainBotNumber
                                        || hisoka.user?.id?.split(':')[0]
                                        || '';

                                await tolak(hisoka, m, 
                                        `╔══════════════════════╗\n` +
                                        `║   🤖  *J A D I B O T*  ║\n` +
                                        `╚══════════════════════╝\n\n` +
                                        `⏳ Sedang menghubungkan *+${number}*...\n` +
                                        `Kode pairing akan segera dikirim.`
                                );

                                await startJadibot(
                                        number,
                                        async (msg) => tolak(hisoka, m, msg),
                                        mainNum,
                                        async (key, text) => {
                                                try {
                                                        await hisoka.sendMessage(m.from, { edit: key, text })
                                                } catch {}
                                        },
                                        async (code, num) => {
                                                const fmt = formatPairingCode(code)
                                                const masked = maskNumber(num)
                                                const footerText = `📲 Tap tombol untuk salin kode · +${num}`

                                                // Reply (quote) pesan pengguna langsung dengan tombol salin
                                                let sentInfo = null
                                                try {
                                                        sentInfo = await m.reply({
                                                                interactiveMessage: {
                                                                        contextInfo: {
                                                                                stanzaId: m.key.id,
                                                                                participant: m.sender,
                                                                                quotedMessage: m.message
                                                                        },
                                                                        title:
                                                                                `╔══════════════════════╗\n` +
                                                                                `║   🤖  *J A D I B O T*   ║\n` +
                                                                                `╚══════════════════════╝\n\n` +
                                                                                `📱 *Nomor:* ${masked}\n\n` +
                                                                                `📋 *Cara Memasukkan Kode Pairing:*\n\n` +
                                                                                `1️⃣ Ketuk tombol *"Salin Kode"* di bawah\n` +
                                                                                `2️⃣ Buka *WhatsApp* → ketuk ⋮ (titik tiga)\n` +
                                                                                `3️⃣ Pilih *Perangkat Tertaut*\n` +
                                                                                `4️⃣ Ketuk *Tautkan Perangkat*\n` +
                                                                                `5️⃣ Pilih *Tautkan dengan nomor telepon*\n` +
                                                                                `6️⃣ Masukkan kode yang sudah disalin\n\n` +
                                                                                `⏳ Kode berlaku *3 menit*\n` +
                                                                                `⚠️ Gagal? Ketik *.jadibot* lagi`,
                                                                        footer: `📲 Salin kode lalu masukkan di WhatsApp · +${num}`,
                                                                        buttons: [{
                                                                                name: 'cta_copy',
                                                                                buttonParamsJson: JSON.stringify({
                                                                                        display_text: '🔑 Salin Kode Pairing Jadibot',
                                                                                        copy_code: fmt
                                                                                })
                                                                        }]
                                                                }
                                                        })
                                                } catch {
                                                        sentInfo = await tolak(hisoka, m, 
                                                                `╔══════════════════════╗\n` +
                                                                `║   🤖  *J A D I B O T*   ║\n` +
                                                                `╚══════════════════════╝\n\n` +
                                                                `📱 *Nomor:* ${masked}\n\n` +
                                                                `🔑 *Kode Pairing:*\n` +
                                                                `┌─────────────────┐\n` +
                                                                `│   *${fmt}*   │\n` +
                                                                `└─────────────────┘\n\n` +
                                                                `📋 Cara masukkan kode:\n` +
                                                                `1️⃣ Buka WhatsApp → ⋮ → Perangkat Tertaut\n` +
                                                                `2️⃣ Tautkan Perangkat → Tautkan dengan nomor\n` +
                                                                `3️⃣ Masukkan kode di atas\n\n` +
                                                                `⏳ Berlaku *3 menit* · Gagal? ketik *.jadibot* lagi\n\n` +
                                                                `\`\`\`${fmt}\`\`\``
                                                        )
                                                }

                                                if (sentInfo?.key) {
                                                        try {
                                                                await hisoka.sendMessage(m.from, {
                                                                        react: { text: '🔑', key: sentInfo.key }
                                                                })
                                                        } catch {}
                                                }

                                                return sentInfo
                                        }
                                );
                        }
                                break;

                        case 'stopjadibot': {
                                if (!isMainBot(hisoka)) return;
                                if (!m.isOwner) return;

                                const pfx = m.prefix || '.';
                                const rawQuery = (query || '').trim();

                                const stopCtxInfo = {
                                        stanzaId: m.key.id,
                                        participant: m.sender,
                                        quotedMessage: m.message
                                };

                                const sendStopBtn = async (bodyText, addBtns = (b) => b) => {
                                        try {
                                                const btn = addBtns(
                                                        new Button()
                                                                .setBody(bodyText)
                                                                .setFooter(`🤖 Wily Bot · Jadibot Manager`)
                                                                .setContextInfo(stopCtxInfo)
                                                )
                                                        .addReply('📋 List Jadibot', `${pfx}listjadibot`);
                                                await btn.run(m.from, hisoka, m);
                                        } catch {
                                                await tolak(hisoka, m, bodyText);
                                        }
                                };

                                // Handle batal
                                if (rawQuery.toLowerCase() === 'batal') {
                                        await sendStopBtn(
                                                `╔══════════════════════╗\n` +
                                                `║  🛑  *STOP JADIBOT*  ║\n` +
                                                `╚══════════════════════╝\n\n` +
                                                `✅ *Dibatalkan!*\n` +
                                                `Bot tidak dihentikan.\n\n` +
                                                `💡 Ketik *${pfx}listjadibot* untuk lihat bot aktif.`
                                        );
                                        break;
                                }

                                // Handle confirm: ".stopjadibot <nomor> confirm"
                                const confirmMatch = rawQuery.match(/^(\d+)\s+confirm$/i);
                                if (confirmMatch) {
                                        let number = confirmMatch[1];
                                        if (number.startsWith('08')) number = '62' + number.slice(1);
                                        await stopJadibot(number, async (text) => {
                                                await sendStopBtn(text);
                                        });
                                        break;
                                }

                                // No number — show realtime picker list
                                let number = rawQuery.replace(/[^0-9]/g, '');
                                if (!number) {
                                        const list = [...jadibotMap.keys()];

                                        if (!list.length) {
                                                await sendStopBtn(
                                                        `╔══════════════════════╗\n` +
                                                        `║  🛑  *STOP JADIBOT*  ║\n` +
                                                        `╚══════════════════════╝\n\n` +
                                                        `📭 *Tidak ada jadibot yang aktif.*\n\n` +
                                                        `💡 Ketik *${pfx}jadibot <nomor>* untuk tambah bot.`
                                                );
                                                break;
                                        }

                                        const bodyText =
                                                `╔══════════════════════╗\n` +
                                                `║  🛑  *STOP JADIBOT*  ║\n` +
                                                `╚══════════════════════╝\n\n` +
                                                `📊 *Bot aktif: ${list.length}*\n\n` +
                                                `👇 *Pilih nomor yang ingin dihentikan:*`;

                                        const btn = new Button()
                                                .setBody(bodyText)
                                                .setFooter(`🤖 Wily Bot · Jadibot Manager · Realtime`)
                                                .setContextInfo(stopCtxInfo)
                                                .addSelection('🛑 Pilih Jadibot')
                                                .makeSections(`🤖 Jadibot Aktif (${list.length})`);

                                        for (const [i, num] of list.entries()) {
                                                btn.makeRow(`Bot ${i + 1}`, `+${num}`, '🟢 Aktif · Ketuk untuk pilih', `${pfx}stopjadibot ${num}`);
                                        }

                                        await btn.run(m.from, hisoka, m);
                                        break;
                                }

                                if (number.startsWith('08')) number = '62' + number.slice(1);

                                const isRunning = jadibotMap.has(number);
                                const maskedNum = maskNumber(number);

                                // Show confirmation with buttons
                                await sendStopBtn(
                                        `╔══════════════════════╗\n` +
                                        `║  🛑  *STOP JADIBOT*  ║\n` +
                                        `╚══════════════════════╝\n\n` +
                                        `📱 *Nomor:* +${maskedNum}\n` +
                                        `📶 *Status:* ${isRunning ? '🟢 Aktif' : '🔴 Tidak aktif'}\n\n` +
                                        `⚠️ Apakah kamu yakin ingin\n*menghentikan bot ini?*\n\n` +
                                        `_Pilih salah satu tombol di bawah_ 👇`,
                                        (b) => b
                                                .addReply('✅ Ya, Hentikan Bot', `${pfx}stopjadibot ${number} confirm`)
                                                .addReply('❌ Batal', `${pfx}stopjadibot batal`)
                                );
                        }
                                break;

                        case 'backup': {
                                if (!isMainBot(hisoka)) return;
                                if (!m.isOwner) return;

                                const archiver = (await import('archiver')).default;
                                const config = loadConfig();
                                const owners = config.owners || [];

                                const EXCLUDED = new Set([
                                        'attached_assets', '.git', '.agents', 'sessions', 'jadibot',
                                        '.upm', 'node_modules', 'package-lock.json',
                                        '.cache', '.local'
                                ]);
                                const EXCLUDED_FILES = new Set([
                                        'bin/yt-dlp'
                                ]);

                                const rootDir = process.cwd();

                                // Kumpulkan semua item top-level yang akan di-backup
                                const allItems = fs.readdirSync(rootDir);
                                const includedItems = allItems.filter(i => !EXCLUDED.has(i));
                                const excludedItems = allItems.filter(i => EXCLUDED.has(i));

                                // Hitung total file rekursif (real-time)
                                function countFilesRecursive(dir, relBase = '') {
                                        let count = 0;
                                        try {
                                                const items = fs.readdirSync(dir, { withFileTypes: true });
                                                for (const item of items) {
                                                        if (EXCLUDED.has(item.name)) continue;
                                                        const relPath = relBase ? `${relBase}/${item.name}` : item.name;
                                                        if (EXCLUDED_FILES.has(relPath)) continue;
                                                        if (item.isDirectory()) {
                                                                count += countFilesRecursive(path.join(dir, item.name), relPath);
                                                        } else {
                                                                count++;
                                                        }
                                                }
                                        } catch {}
                                        return count;
                                }

                                const totalFiles = countFilesRecursive(rootDir);

                                // Pisahkan folder dan file untuk tampilan
                                const includedFolders = includedItems.filter(i => {
                                        try { return fs.statSync(path.join(rootDir, i)).isDirectory(); } catch { return false; }
                                });
                                const includedFiles = includedItems.filter(i => {
                                        try { return fs.statSync(path.join(rootDir, i)).isFile(); } catch { return false; }
                                });

                                // Hitung isi tiap folder (file & subfolder langsung di dalamnya)
                                function getFolderStats(dirPath) {
                                        try {
                                                const items = fs.readdirSync(dirPath, { withFileTypes: true });
                                                const files = items.filter(i => i.isFile()).length;
                                                const folders = items.filter(i => i.isDirectory()).length;
                                                return { files, folders };
                                        } catch { return { files: 0, folders: 0 }; }
                                }

                                const folderLines = includedFolders.map((f, i) => {
                                        const isLast = i === includedFolders.length - 1;
                                        const prefix = isLast ? '└─' : '├─';
                                        const { files, folders } = getFolderStats(path.join(rootDir, f));
                                        const detail = [
                                                files ? `${files} file` : '',
                                                folders ? `${folders} folder` : ''
                                        ].filter(Boolean).join(', ') || 'kosong';
                                        return `${prefix} 📂 *${f}/* → _${detail}_`;
                                });

                                const fileLines = includedFiles.map((f, i) => {
                                        const isLast = i === includedFiles.length - 1;
                                        const prefix = isLast ? '└─' : '├─';
                                        return `${prefix} 📄 ${f}`;
                                });

                                // Reaction ⏳ dulu
                                await hisoka.sendMessage(m.from, { react: { text: '⏳', key: m.key } });

                                await tolak(hisoka, m, 
                                        `╭─「 🗜️ *BACKUP BOT* 」\n` +
                                        `│\n` +
                                        `│ ⏳ _Sedang memproses backup..._\n` +
                                        `│\n` +
                                        `├─ 📁 *Folder (${includedFolders.length})*\n` +
                                        folderLines.map(l => `│  ${l}`).join('\n') + '\n' +
                                        `│\n` +
                                        `├─ 📄 *File Root (${includedFiles.length})*\n` +
                                        fileLines.map(l => `│  ${l}`).join('\n') + '\n' +
                                        `│\n` +
                                        `├─ 🗂️ *Total keseluruhan:* ${totalFiles} file\n` +
                                        `│\n` +
                                        `├─ 🚫 *Dikecualikan (${excludedItems.length}):*\n` +
                                        `│  ├─ ${excludedItems.join(', ')}\n` +
                                        `│  └─ bin/yt-dlp _(auto-download)_\n` +
                                        `│\n` +
                                        `╰─ _Membuat zip, harap tunggu..._`
                                );

                                // Buat zip ke /tmp
                                const zipName = `Readsw_${Date.now()}.zip`;
                                const zipPath = path.join('/tmp', zipName);
                                const output = fs.createWriteStream(zipPath);
                                const archive = archiver('zip', { zlib: { level: 9 } });

                                await new Promise((resolve, reject) => {
                                        output.on('close', resolve);
                                        archive.on('error', reject);
                                        archive.pipe(output);

                                        function addToArchive(archive, absPath, relPath) {
                                                const stat = fs.statSync(absPath);
                                                if (stat.isDirectory()) {
                                                        const children = fs.readdirSync(absPath);
                                                        for (const child of children) {
                                                                const childRel = `${relPath}/${child}`;
                                                                if (EXCLUDED_FILES.has(childRel)) continue;
                                                                addToArchive(archive, path.join(absPath, child), childRel);
                                                        }
                                                } else {
                                                        archive.file(absPath, { name: relPath });
                                                }
                                        }

                                        for (const item of includedItems) {
                                                const fullPath = path.join(rootDir, item);
                                                addToArchive(archive, fullPath, item);
                                        }
                                        archive.finalize();
                                });

                                const zipBuffer = fs.readFileSync(zipPath);
                                const zipSizeMB = (zipBuffer.length / 1024 / 1024).toFixed(2);

                                // Caption ringkas untuk dokumen zip
                                const zipCaption =
                                        `╭─「 📦 *BACKUP SELESAI* 」\n` +
                                        `│\n` +
                                        `├─ 🗜️ *File :* ${zipName}\n` +
                                        `├─ 📏 *Ukuran :* ${zipSizeMB} MB\n` +
                                        `├─ 🗂️ *Total :* ${totalFiles} file\n` +
                                        `│\n` +
                                        `├─ 📁 *Folder (${includedFolders.length})*\n` +
                                        includedFolders.map(f => {
                                                const { files, folders } = getFolderStats(path.join(rootDir, f));
                                                const detail = [files ? `${files} file` : '', folders ? `${folders} folder` : ''].filter(Boolean).join(', ') || 'kosong';
                                                return `│  └─ ${f}/ → ${detail}`;
                                        }).join('\n') + '\n' +
                                        `│\n` +
                                        `├─ 🚫 *Exclude :* ${excludedItems.join(', ')}, bin/yt-dlp\n` +
                                        `│\n` +
                                        `╰─ 🕐 ${new Date().toLocaleString('id-ID')}`;

                                // Kirim ke semua owner
                                const sentTo = [];
                                for (const ownerNum of owners) {
                                        const ownerJid = `${ownerNum}@s.whatsapp.net`;
                                        try {
                                                await hisoka.sendMessage(ownerJid, {
                                                        document: zipBuffer,
                                                        fileName: zipName,
                                                        mimetype: 'application/zip',
                                                        caption: zipCaption,
                                                });
                                                sentTo.push(ownerNum);
                                        } catch (e) {
                                                console.error('[Backup] Gagal kirim ke', ownerNum, e.message);
                                        }
                                }

                                // Hapus file zip tmp
                                try { fs.unlinkSync(zipPath); } catch {}

                                // Reaction ✅ selesai
                                await hisoka.sendMessage(m.from, { react: { text: '✅', key: m.key } });

                                await tolak(hisoka, m, 
                                        sentTo.length
                                        ? `╭─「 ✅ *BACKUP BERHASIL* 」\n` +
                                          `│\n` +
                                          `├─ 📏 *Ukuran :* ${zipSizeMB} MB\n` +
                                          `├─ 🗂️ *Total file :* ${totalFiles}\n` +
                                          `│\n` +
                                          `├─ 📨 *Terkirim ke ${sentTo.length} owner:*\n` +
                                          sentTo.map((n, i) => `│  ${i + 1}. +${n}`).join('\n') + '\n' +
                                          `│\n` +
                                          `╰─ 🕐 ${new Date().toLocaleString('id-ID')}`
                                        : `╭─「 ⚠️ *BACKUP* 」\n│\n├─ Zip dibuat tapi gagal kirim ke semua owner.\n╰─ Cek nomor owner di config.json`
                                );

                                logCommand(m, hisoka, 'backup');
                        }
                                break;

                        case 'ceksesi': {
                                if (!m.isOwner) return;
                                try {
                                        const sesiDir = path.join(process.cwd(), 'sessions', process.env.BOT_SESSION_NAME || 'hisoka');
                                        const files = fs.readdirSync(sesiDir);
                                        const total = files.length;

                                        const EMOJI_MAP = {
                                                'session':               '🔑',
                                                'pre-key':               '🗝️',
                                                'sender-key':            '📨',
                                                'app-state-sync-key':    '🔄',
                                                'app-state-sync-version':'📋',
                                                'creds.json':            '🛡️',
                                                'contacts.json':         '👥',
                                                'groups.json':           '🫂',
                                                'settings.json':         '⚙️',
                                        };
                                        const DESC_MAP = {
                                                'session':               'Sesi & koneksi utama bot',
                                                'pre-key':               'Kunci enkripsi pesan (E2E)',
                                                'sender-key':            'Kunci enkripsi per grup/chat',
                                                'app-state-sync-key':    'Sinkronisasi state WhatsApp',
                                                'app-state-sync-version':'Versi sync state WA',
                                                'creds.json':            'Kredensial utama bot',
                                                'contacts.json':         'Cache kontak tersimpan',
                                                'groups.json':           'Cache data grup',
                                                'settings.json':         'Pengaturan sesi lokal',
                                        };

                                        const groups = {};
                                        for (const file of files) {
                                                const name = file.replace(/\.json$/, '');
                                                let group;
                                                if (name.startsWith('app-state-sync-key'))          group = 'app-state-sync-key';
                                                else if (name.startsWith('app-state-sync-version'))  group = 'app-state-sync-version';
                                                else if (name.startsWith('pre-key'))                 group = 'pre-key';
                                                else if (name.startsWith('sender-key'))              group = 'sender-key';
                                                else if (name.startsWith('session'))                 group = 'session';
                                                else                                                  group = file;
                                                groups[group] = (groups[group] || 0) + 1;
                                        }

                                        const sorted = Object.entries(groups).sort((a, b) => b[1] - a[1]);
                                        const lines = sorted.map(([g, c]) => {
                                                const emoji = EMOJI_MAP[g] || '📄';
                                                const desc  = DESC_MAP[g]  || 'File sesi lainnya';
                                                return `├─ ${emoji} *${g}* ──→ *${c} file*\n│  └ _${desc}_`;
                                        });

                                        const teks =
                                                `╭─「 🗂️ *CEK SESI* 」\n` +
                                                `│\n` +
                                                lines.join('\n') + '\n' +
                                                `│\n` +
                                                `├─ 📦 *Total :* ${total} file\n` +
                                                `├─ 📁 *Path  :* sessions/${process.env.BOT_SESSION_NAME || 'hisoka'}\n` +
                                                `╰─ 🕐 ${new Date().toLocaleString('id-ID')}`;

                                        await tolak(hisoka, m, teks);
                                        logCommand(m, hisoka, 'ceksesi');
                                } catch (e) {
                                        await tolak(hisoka, m, `❌ Gagal baca sesi: ${e.message}`);
                                }
                                break;
                        }

                        case 'cekerror': {
                                if (!m.isOwner) return;

                                await hisoka.sendMessage(m.from, { react: { text: `🔍`, key: m.key } });

                                const arg = (query || '').trim().toLowerCase();

                                if (arg === 'reset' || arg === 'clear') {
                                        clearErrors();
                                        await tolak(hisoka, m, `╭─「 🗑️ *ERROR LOG* 」\n│\n╰➤ Semua log error berhasil dihapus!\n\n┗━➤ 🚀 *Powered By Wily Bot*`);
                                        logCommand(m, hisoka, 'cekerror');
                                        break;
                                }

                                const limit = parseInt(arg) || 10;
                                const summary = formatErrorReport(Math.min(limit, 50));
                                await tolak(hisoka, m, summary);

                                generateErrorFileTxt();
                                const txtPath   = getInfoErrorTxtPath();
                                const txtExists = fs.existsSync(txtPath);

                                if (txtExists) {
                                        const fileBuffer = fs.readFileSync(txtPath);
                                        await hisoka.sendMessage(m.from, {
                                                document: fileBuffer,
                                                mimetype: 'text/plain',
                                                fileName: 'infoerror.txt',
                                                caption: `📄 *File Error Lengkap — infoerror.txt*\n\n• Diperbarui otomatis setiap ada error baru\n• Stack trace & frekuensi duplikat tersimpan\n• Urutan terbaru di atas`
                                        }, { quoted: m });
                                }

                                logCommand(m, hisoka, 'cekerror');
                                break;
                        }

                        case 'listjadibot': {
                                if (!isMainBot(hisoka)) return;
                                if (!m.isOwner) return;

                                const ljPfx = m.prefix || '.';
                                const ljCtx = {
                                        stanzaId: m.key.id,
                                        participant: m.sender,
                                        quotedMessage: m.message
                                };
                                const list = [...jadibotMap.keys()];

                                if (!list.length) {
                                        try {
                                                await new Button()
                                                        .setBody(
                                                                `╔══════════════════════╗\n` +
                                                                `║  🤖  *LIST JADIBOT*  ║\n` +
                                                                `╚══════════════════════╝\n\n` +
                                                                `📭 *Belum ada jadibot yang aktif.*\n\n` +
                                                                `💡 Tambah jadibot dengan ketik:\n` +
                                                                `_${ljPfx}jadibot <nomor>_`
                                                        )
                                                        .setFooter(`🤖 Wily Bot · Jadibot Manager`)
                                                        .setContextInfo(ljCtx)
                                                        .addReply('➕ Tambah Jadibot', `${ljPfx}jadibot`)
                                                        .run(m.from, hisoka, m);
                                        } catch {
                                                await tolak(hisoka, m, 
                                                        `╔══════════════════════╗\n` +
                                                        `║  🤖  *LIST JADIBOT*  ║\n` +
                                                        `╚══════════════════════╝\n\n` +
                                                        `❌ Belum ada jadibot yang aktif.\n\n` +
                                                        `💡 Ketik *${ljPfx}jadibot <nomor>* untuk mulai.`
                                                );
                                        }
                                        break;
                                }

                                // Ada jadibot aktif — tampilkan dengan single_select + tombol aksi
                                const ljBodyText =
                                        `╔══════════════════════╗\n` +
                                        `║  🤖  *LIST JADIBOT*  ║\n` +
                                        `╚══════════════════════╝\n\n` +
                                        `📊 *Total aktif: ${list.length} bot*\n\n` +
                                        `👇 Pilih nomor untuk info atau ketuk tombol aksi:`;

                                try {
                                        const ljBtn = new Button()
                                                .setBody(ljBodyText)
                                                .setFooter(`🤖 Wily Bot · Jadibot Manager · Realtime`)
                                                .setContextInfo(ljCtx)
                                                .addReply('🛑 Stop Jadibot', `${ljPfx}stopjadibot`)
                                                .addReply('➕ Tambah Jadibot', `${ljPfx}jadibot`)
                                                .addSelection('📋 Pilih Nomor Jadibot')
                                                .makeSections(`🟢 Jadibot Aktif (${list.length})`);

                                        for (const [i, num] of list.entries()) {
                                                ljBtn.makeRow(
                                                        `Bot ${i + 1}`,
                                                        `+${num}`,
                                                        `🟢 Aktif · Ketuk untuk hentikan`,
                                                        `${ljPfx}stopjadibot ${num}`
                                                );
                                        }

                                        await ljBtn.run(m.from, hisoka, m);
                                } catch {
                                        const items = list.map((v, i) => `│ ${i + 1}. +${v}`).join('\n');
                                        await tolak(hisoka, m, 
                                                `╔══════════════════════╗\n` +
                                                `║  🤖  *LIST JADIBOT*  ║\n` +
                                                `╚══════════════════════╝\n\n` +
                                                `📊 Total aktif: *${list.length} bot*\n\n` +
                                                `┌─────────────────────\n` +
                                                `${items}\n` +
                                                `└─────────────────────\n\n` +
                                                `💡 *${ljPfx}stopjadibot <nomor>* untuk matikan`
                                        );
                                }
                                logCommand(m, hisoka, 'listjadibot');
                        }
                                break;
                        

                        case 'play': {
                                try {
                                        if (!query) {
                                                await tolak(hisoka, m, '❌ Masukkan judul lagu!\n\nContoh: .play shape of you ed sheeran');
                                                break;
                                        }

                                        await hisoka.sendMessage(m.from, { react: { text: '🔍', key: m.key } });
                                        const loadingMsg = await tolak(hisoka, m, '🔍 Mencari lagu...');

                                        const yts = (await import('yt-search')).default;
                                        const searchResult = await yts(query.trim());

                                        if (!searchResult || !searchResult.videos || searchResult.videos.length === 0) {
                                                await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                                await m.reply({ edit: loadingMsg.key, text: '❌ Lagu tidak ditemukan!' });
                                                break;
                                        }

                                        const video = searchResult.videos[0];

                                        if (video.seconds > 600) {
                                                await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                                await m.reply({ edit: loadingMsg.key, text: `❌ Durasi terlalu panjang! (${video.duration.timestamp})\nMaksimal 10 menit.` });
                                                break;
                                        }

                                        const thumbUrl = video.thumbnail || `https://i.ytimg.com/vi/${video.videoId}/hqdefault.jpg`;
                                        const videoLink = video.url || `https://youtu.be/${video.videoId}`;
                                        const durStr = video.duration.timestamp;
                                        const viewsFmt = video.views ? video.views.toLocaleString('id-ID') : '?';

                                        let playBody = `╭═══〔 *🎵 PLAY MUSIC* 〕═══╮\n`;
                                        playBody += `│\n`;
                                        playBody += `│ 📌 *${video.title}*\n`;
                                        playBody += `│ ⏱️ Durasi  : ${durStr}\n`;
                                        playBody += `│ 👁️ Views   : ${viewsFmt}\n`;
                                        if (video.author?.name) playBody += `│ 👤 Channel : ${video.author.name}\n`;
                                        playBody += `│ 🔗 Link    : ${videoLink}\n`;
                                        playBody += `│\n`;
                                        playBody += `│ Pilih format di bawah 👇\n`;
                                        playBody += `╰═══════════════════════╯`;

                                        let buttonSent = false;
                                        try {
                                                await new Button()
                                                        .setImage(thumbUrl)
                                                        .setBody(playBody)
                                                        .setFooter('⏳ Pilihan hangus dalam 2 menit')
                                                        .addReply('🎵 Audio MP3', '1')
                                                        .addReply('🎬 Video MP4 (360p)', '2')
                                                        .run(m.from, hisoka, m);
                                                buttonSent = true;
                                        } catch {
                                                await hisoka.sendMessage(m.from, {
                                                        image: { url: thumbUrl },
                                                        caption: playBody + `\n\n🎵 *1* - Audio MP3\n🎬 *2* - Video MP4\n\n_Balas dengan angka pilihanmu_`
                                                }, { quoted: m });
                                        }

                                        await hisoka.sendMessage(m.from, { react: { text: '🎵', key: m.key } });
                                        await m.reply({
                                                edit: loadingMsg.key,
                                                text: buttonSent
                                                        ? `🎵 Ketemu! Tap tombol *Audio MP3* atau *Video MP4* untuk download.`
                                                        : `🎵 Ketemu! Balas dengan *1* untuk Audio MP3 atau *2* untuk Video MP4.`
                                        });

                                        // Simpan pilihan pending dengan timeout 2 menit
                                        const timeoutId = setTimeout(() => {
                                                if (pendingPlayChoices.has(m.sender)) {
                                                        pendingPlayChoices.delete(m.sender);
                                                }
                                        }, 2 * 60 * 1000);

                                        pendingPlayChoices.set(m.sender, {
                                                url: video.url,
                                                title: video.title,
                                                duration: durStr,
                                                seconds: video.seconds,
                                                timeout: timeoutId
                                        });

                                        logCommand(m, hisoka, 'play');
                                } catch (error) {
                                        console.error('\x1b[31m[Play] Error:\x1b[39m', error.message);
                                        await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                        await tolak(hisoka, m, `❌ Gagal mencari lagu: ${error.message?.substring(0, 200)}`);
                                }
                                break;
                        }

                        case 'ytmp3': {
                                try {
                                        if (!query) {
                                                await tolak(hisoka, m, '❌ Masukkan link YouTube!\n\nContoh: .ytmp3 https://youtu.be/xxx\nAtau: .ytmp3 https://www.youtube.com/watch?v=xxx');
                                                break;
                                        }

                                        const ytUrl = query.trim();
                                        if (!ytUrl.includes('youtube.com') && !ytUrl.includes('youtu.be')) {
                                                await tolak(hisoka, m, '❌ Link tidak valid! Gunakan link YouTube.');
                                                break;
                                        }

                                        await hisoka.sendMessage(m.from, { react: { text: '⏳', key: m.key } });
                                        const loadingMsg = await tolak(hisoka, m, '⏳ Mengambil info video...');

                                        const ytdlpBin = await ensureYtdlp(hisoka, m);

                                        const metaRaw = await new Promise((resolve, reject) => {
                                                exec(`"${ytdlpBin}" --js-runtimes node --no-playlist --dump-json "${ytUrl}"`, { timeout: 30000 }, (err, stdout, stderr) => {
                                                        if (err) return reject(new Error(parseYtdlpError(stderr, err.message)));
                                                        resolve(stdout.trim());
                                                });
                                        });

                                        const meta = JSON.parse(metaRaw);
                                        const duration = meta.duration || 0;

                                        if (duration > 600) {
                                                await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                                await m.reply({ edit: loadingMsg.key, text: `❌ Durasi terlalu panjang! (${Math.floor(duration / 60)} menit)\nMaksimal 10 menit.` });
                                                break;
                                        }

                                        await m.reply({ edit: loadingMsg.key, text: '⏳ Mengunduh audio MP3...' });

                                        const durMin = Math.floor(duration / 60);
                                        const durSec = Math.floor(duration % 60);
                                        const durStr = `${durMin}:${String(durSec).padStart(2, '0')}`;
                                        const viewsFmt = meta.view_count ? parseInt(meta.view_count).toLocaleString('id-ID') : '?';
                                        const thumbUrl = meta.thumbnail || `https://i.ytimg.com/vi/${meta.id}/hqdefault.jpg`;
                                        const videoLink = `https://youtu.be/${meta.id}`;

                                        let mp3Caption = `╭═══〔 *🎵 YTMP3 DOWNLOADER* 〕═══╮\n`;
                                        mp3Caption += `│\n`;
                                        mp3Caption += `│ 📌 *${meta.title}*\n`;
                                        mp3Caption += `│ ⏱️ Durasi  : ${durStr}\n`;
                                        mp3Caption += `│ 👁️ Views   : ${viewsFmt}\n`;
                                        if (meta.uploader) mp3Caption += `│ 👤 Channel : ${meta.uploader}\n`;
                                        if (meta.like_count) mp3Caption += `│ 👍 Likes   : ${parseInt(meta.like_count).toLocaleString('id-ID')}\n`;
                                        mp3Caption += `│ 🔗 Link    : ${videoLink}\n`;
                                        mp3Caption += `│\n`;
                                        mp3Caption += `│ ⬇️ _Sedang mengunduh audio MP3..._\n`;
                                        mp3Caption += `╰══════════════════════════════╯`;

                                        await hisoka.sendMessage(m.from, {
                                                image: { url: thumbUrl },
                                                caption: mp3Caption
                                        }, { quoted: m });

                                        const tmpId = Date.now();
                                        const tmpFile = path.join(process.cwd(), 'tmp', `ytmp3_${tmpId}.mp3`);
                                        const tmpTemplate = path.join(process.cwd(), 'tmp', `ytmp3_${tmpId}.%(ext)s`);

                                        await new Promise((resolve, reject) => {
                                                const cmd = `"${ytdlpBin}" --js-runtimes node --no-playlist -x --audio-format mp3 --audio-quality 5 -o "${tmpTemplate}" "${ytUrl}"`;
                                                exec(cmd, { timeout: 120000 }, (err, stdout, stderr) => {
                                                        if (err) return reject(new Error(parseYtdlpError(stderr, err.message)));
                                                        resolve();
                                                });
                                        });

                                        const audioBuffer = fs.readFileSync(tmpFile);

                                        await hisoka.sendMessage(m.from, {
                                                audio: audioBuffer,
                                                mimetype: 'audio/mpeg',
                                                fileName: `${meta.title.replace(/[^\w\s]/gi, '')}.mp3`,
                                                ptt: false
                                        }, { quoted: m });

                                        await hisoka.sendMessage(m.from, { react: { text: '✅', key: m.key } });
                                        await m.reply({ edit: loadingMsg.key, text: `✅ *Audio MP3 berhasil dikirim!*\n📌 ${meta.title}` });

                                        try { fs.unlinkSync(tmpFile); } catch (_) {}

                                        logCommand(m, hisoka, 'ytmp3');
                                } catch (error) {
                                        console.error('\x1b[31m[YTMP3] Error:\x1b[39m', error.message);
                                        await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                        await tolak(hisoka, m, `❌ Gagal mengunduh audio: ${error.message?.substring(0, 200)}`);
                                }
                                break;
                        }

                        case 'ytmp4': {
                                try {
                                        if (!query) {
                                                await tolak(hisoka, m, '❌ Masukkan link YouTube!\n\nContoh: .ytmp4 https://youtu.be/xxx\nAtau: .ytmp4 https://www.youtube.com/watch?v=xxx');
                                                break;
                                        }

                                        const ytUrl = query.trim();
                                        if (!ytUrl.includes('youtube.com') && !ytUrl.includes('youtu.be')) {
                                                await tolak(hisoka, m, '❌ Link tidak valid! Gunakan link YouTube.');
                                                break;
                                        }

                                        await hisoka.sendMessage(m.from, { react: { text: '⏳', key: m.key } });
                                        const loadingMsg = await tolak(hisoka, m, '⏳ Mengambil info video...');

                                        const ytdlpBin = await ensureYtdlp(hisoka, m);

                                        const metaRaw = await new Promise((resolve, reject) => {
                                                exec(`"${ytdlpBin}" --js-runtimes node --no-playlist --dump-json "${ytUrl}"`, { timeout: 30000 }, (err, stdout, stderr) => {
                                                        if (err) return reject(new Error(parseYtdlpError(stderr, err.message)));
                                                        resolve(stdout.trim());
                                                });
                                        });

                                        const meta = JSON.parse(metaRaw);
                                        const duration = meta.duration || 0;

                                        if (duration > 300) {
                                                await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                                await m.reply({ edit: loadingMsg.key, text: `❌ Durasi terlalu panjang! (${Math.floor(duration / 60)} menit)\nMaksimal 5 menit untuk video.` });
                                                break;
                                        }

                                        await m.reply({ edit: loadingMsg.key, text: '⏳ Mengunduh video MP4...' });

                                        const durMin = Math.floor(duration / 60);
                                        const durSec = Math.floor(duration % 60);
                                        const durStr = `${durMin}:${String(durSec).padStart(2, '0')}`;
                                        const viewsFmt = meta.view_count ? parseInt(meta.view_count).toLocaleString('id-ID') : '?';
                                        const thumbUrl = meta.thumbnail || `https://i.ytimg.com/vi/${meta.id}/hqdefault.jpg`;
                                        const videoLink = `https://youtu.be/${meta.id}`;

                                        let mp4Caption = `╭═══〔 *🎬 YTMP4 DOWNLOADER* 〕═══╮\n`;
                                        mp4Caption += `│\n`;
                                        mp4Caption += `│ 📌 *${meta.title}*\n`;
                                        mp4Caption += `│ ⏱️ Durasi  : ${durStr}\n`;
                                        mp4Caption += `│ 📐 Kualitas: 360p\n`;
                                        mp4Caption += `│ 👁️ Views   : ${viewsFmt}\n`;
                                        if (meta.uploader) mp4Caption += `│ 👤 Channel : ${meta.uploader}\n`;
                                        if (meta.like_count) mp4Caption += `│ 👍 Likes   : ${parseInt(meta.like_count).toLocaleString('id-ID')}\n`;
                                        mp4Caption += `│ 🔗 Link    : ${videoLink}\n`;
                                        mp4Caption += `│\n`;
                                        mp4Caption += `│ ⬇️ _Sedang mengunduh video MP4..._\n`;
                                        mp4Caption += `╰══════════════════════════════╯`;

                                        await hisoka.sendMessage(m.from, {
                                                image: { url: thumbUrl },
                                                caption: mp4Caption
                                        }, { quoted: m });

                                        const tmpId = Date.now();
                                        const tmpFile = path.join(process.cwd(), 'tmp', `ytmp4_${tmpId}.mp4`);
                                        const tmpTemplate = path.join(process.cwd(), 'tmp', `ytmp4_${tmpId}.%(ext)s`);

                                        await new Promise((resolve, reject) => {
                                                const cmd = `"${ytdlpBin}" --js-runtimes node --no-playlist -f "bestvideo[height<=360][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=360]+bestaudio/best[height<=360]" --merge-output-format mp4 -o "${tmpTemplate}" "${ytUrl}"`;
                                                exec(cmd, { timeout: 180000 }, (err, stdout, stderr) => {
                                                        if (err) return reject(new Error(parseYtdlpError(stderr, err.message)));
                                                        resolve();
                                                });
                                        });

                                        const videoBuffer = fs.readFileSync(tmpFile);

                                        let mp4DoneCaption = `╭═══〔 *🎬 YTMP4 DOWNLOADER* 〕═══╮\n`;
                                        mp4DoneCaption += `│\n`;
                                        mp4DoneCaption += `│ 📌 *${meta.title}*\n`;
                                        mp4DoneCaption += `│ ⏱️ Durasi  : ${durStr}\n`;
                                        mp4DoneCaption += `│ 📐 Kualitas: 360p\n`;
                                        mp4DoneCaption += `│ 👁️ Views   : ${viewsFmt}\n`;
                                        if (meta.uploader) mp4DoneCaption += `│ 👤 Channel : ${meta.uploader}\n`;
                                        mp4DoneCaption += `│ 🔗 Link    : ${videoLink}\n`;
                                        mp4DoneCaption += `│\n`;
                                        mp4DoneCaption += `╰══════════════════════════════╯`;

                                        await hisoka.sendMessage(m.from, {
                                                video: videoBuffer,
                                                caption: mp4DoneCaption,
                                                mimetype: 'video/mp4'
                                        }, { quoted: m });

                                        await hisoka.sendMessage(m.from, { react: { text: '✅', key: m.key } });
                                        await m.reply({ edit: loadingMsg.key, text: `✅ *Video MP4 berhasil dikirim!*\n📌 ${meta.title}` });

                                        try { fs.unlinkSync(tmpFile); } catch (_) {}

                                        logCommand(m, hisoka, 'ytmp4');
                                } catch (error) {
                                        console.error('\x1b[31m[YTMP4] Error:\x1b[39m', error.message);
                                        await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                        await tolak(hisoka, m, `❌ Gagal mengunduh video: ${error.message?.substring(0, 200)}`);
                                }
                                break;
                        }

                        case 'antitagsw': {
                                if (!m.isGroup) return tolak(hisoka, m, '❌ Fitur ini hanya bisa digunakan di grup!');
                                if (!m.isAdmin && !m.isOwner) return tolak(hisoka, m, '❌ Hanya admin grup atau owner bot yang bisa menggunakan perintah ini!');

                                const arg = (query || '').trim().toLowerCase();

                                if (arg === 'on') {
                                        const config = loadConfig();
                                        if (!config.antiTagSW?.enabled) {
                                                return tolak(hisoka, m, '❌ Fitur AntiTagSW dinonaktifkan secara global oleh owner bot.\nUbah *antiTagSW.enabled* di config.json menjadi *true* terlebih dahulu.');
                                        }

                                        toggleAntiTagSW(m.from, true);
                                        await tolak(hisoka, m, 
                                                `╭───〔 *✅ ANTI-TAG SEMUA WARGA* 〕───╮\n` +
                                                `│\n` +
                                                `│ 🟢 *Fitur AntiTagSW AKTIF!*\n` +
                                                `│\n` +
                                                `│ ⚙️ Konfigurasi:\n` +
                                                `│ • Maks. warning: *${config.antiTagSW?.maxWarnings ?? 3}x*\n` +
                                                `│\n` +
                                                `│ ℹ️ Anggota yang mentag grup lewat\n` +
                                                `│    STATUS akan diperingatkan & dikick!\n` +
                                                `│\n` +
                                                `╰────────────────────────────────────╯`
                                        );
                                        logCommand(m, hisoka, 'antitagsw on');
                                } else if (arg === 'off') {
                                        toggleAntiTagSW(m.from, false);
                                        await tolak(hisoka, m, 
                                                `╭───〔 *❌ ANTI-TAG SEMUA WARGA* 〕───╮\n` +
                                                `│\n` +
                                                `│ 🔴 *Fitur AntiTagSW NONAKTIF!*\n` +
                                                `│\n` +
                                                `│ ℹ️ Semua warning di grup ini\n` +
                                                `│    juga telah direset.\n` +
                                                `│\n` +
                                                `╰────────────────────────────────────╯`
                                        );
                                        logCommand(m, hisoka, 'antitagsw off');
                                } else if (arg === 'reset') {
                                        resetWarnings(m.from);
                                        await tolak(hisoka, m, '✅ Semua warning AntiTagSW di grup ini telah direset!');
                                        logCommand(m, hisoka, 'antitagsw reset');
                                } else {
                                        const config = loadConfig();
                                        const isEnabled = isAntiTagSWEnabled(m.from);
                                        const globalEnabled = config.antiTagSW?.enabled ?? false;
                                        const warnings = getWarnings(m.from);
                                        const totalWarned = Object.keys(warnings).length;

                                        let statusText =
                                                `╭───〔 *ℹ️ ANTI-TAG SEMUA WARGA* 〕───╮\n` +
                                                `│\n` +
                                                `│ 🌐 Global   : ${globalEnabled ? '🟢 Aktif' : '🔴 Nonaktif'}\n` +
                                                `│ 📌 Grup ini : ${isEnabled ? '🟢 Aktif' : '🔴 Nonaktif'}\n` +
                                                `│\n` +
                                                `│ ⚙️ Konfigurasi:\n` +
                                                `│ • Maks. warning: *${config.antiTagSW?.maxWarnings ?? 3}x*\n` +
                                                `│ • Member warned: *${totalWarned} orang*\n` +
                                                `│\n` +
                                                `│ ℹ️ Mendeteksi tag grup via STATUS\n` +
                                                `│\n` +
                                                `│ 📋 Cara penggunaan:\n` +
                                                `│ • *.antitagsw on*  → Aktifkan\n` +
                                                `│ • *.antitagsw off* → Nonaktifkan\n` +
                                                `│ • *.antitagsw reset* → Reset warning\n` +
                                                `│\n` +
                                                `╰────────────────────────────────────╯`;

                                        await tolak(hisoka, m, statusText);
                                }
                                break;
                        }

                        case 'upswgc':
                        case 'swgc':
                        case 'swgrup':
                        case 'swgroup':
                        case 'statusgrup':
                        case 'statusgroup': {
                                if (!m.isOwner) return tolak(hisoka, m, '❌ Fitur ini hanya untuk owner!');

                                const swgcCaption = query ? query.trim() : '';
                                let swgcMeta = {};
                                let swgcTempFile = null;

                                // PRIORITAS 1: Media di pesan saat ini (kirim gambar/video/audio dengan caption .upswgc teks)
                                const swgcSelfType = m.type || '';
                                if (m.isMedia && /image|video|audio/i.test(swgcSelfType)) {
                                        try {
                                                const swgcBuf = await m.downloadMedia();
                                                if (!swgcBuf) return tolak(hisoka, m, '❌ Gagal mengambil media.');

                                                const swgcMime = m.content?.mimetype || 'application/octet-stream';
                                                const swgcExt = swgcMime.split('/')[1]?.split(';')[0]?.trim() || 'bin';
                                                swgcTempFile = path.join(process.cwd(), 'tmp', `upswgc_${Date.now()}.${swgcExt}`);
                                                fs.writeFileSync(swgcTempFile, swgcBuf);

                                                if (/image/i.test(swgcSelfType)) {
                                                        swgcMeta = { type: 'image', file: swgcTempFile, mime: swgcMime };
                                                        if (swgcCaption) swgcMeta.caption = swgcCaption;
                                                } else if (/video/i.test(swgcSelfType)) {
                                                        swgcMeta = { type: 'video', file: swgcTempFile, mime: swgcMime };
                                                        if (swgcCaption) swgcMeta.caption = swgcCaption;
                                                } else if (/audio/i.test(swgcSelfType)) {
                                                        swgcMeta = { type: 'audio', file: swgcTempFile, mime: swgcMime };
                                                        if (swgcCaption) swgcMeta.caption = swgcCaption;
                                                }
                                        } catch (e) {
                                                if (swgcTempFile && fs.existsSync(swgcTempFile)) fs.unlinkSync(swgcTempFile);
                                                return tolak(hisoka, m, '❌ Gagal memproses media: ' + (e.message || e));
                                        }
                                // PRIORITAS 2: Reply ke pesan lain yang berisi media
                                } else if (m.isQuoted && m.quoted) {
                                        try {
                                                const qType = m.quoted.type || '';
                                                if (!/image|video|audio/i.test(qType)) {
                                                        return tolak(hisoka, m, '❌ Reply harus berupa image/video/audio.');
                                                }

                                                const swgcBuf = await m.quoted.downloadMedia();
                                                if (!swgcBuf) return tolak(hisoka, m, '❌ Gagal mengambil media quoted.');

                                                const swgcMime = m.quoted.content?.mimetype || 'application/octet-stream';
                                                const swgcExt = swgcMime.split('/')[1]?.split(';')[0]?.trim() || 'bin';
                                                swgcTempFile = path.join(process.cwd(), 'tmp', `upswgc_${Date.now()}.${swgcExt}`);
                                                fs.writeFileSync(swgcTempFile, swgcBuf);

                                                if (/image/i.test(qType)) {
                                                        swgcMeta = { type: 'image', file: swgcTempFile, mime: swgcMime };
                                                        if (swgcCaption) swgcMeta.caption = swgcCaption;
                                                } else if (/video/i.test(qType)) {
                                                        swgcMeta = { type: 'video', file: swgcTempFile, mime: swgcMime };
                                                        if (swgcCaption) swgcMeta.caption = swgcCaption;
                                                } else if (/audio/i.test(qType)) {
                                                        swgcMeta = { type: 'audio', file: swgcTempFile, mime: swgcMime };
                                                        if (swgcCaption) swgcMeta.caption = swgcCaption;
                                                }
                                        } catch (e) {
                                                if (swgcTempFile && fs.existsSync(swgcTempFile)) fs.unlinkSync(swgcTempFile);
                                                return tolak(hisoka, m, '❌ Media tidak valid atau gagal diproses: ' + (e.message || e));
                                        }
                                } else if (swgcCaption) {
                                        swgcMeta = { type: 'text', text: swgcCaption };
                                } else {
                                        return tolak(hisoka, m, 
                                                `⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛\n` +
                                                `✦ 📢 *.UPSWGC* — CARA PAKAI ✦\n` +
                                                `⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛\n\n` +
                                                `◈━━━━━━━━━━━━━━━━━━━━━━━◈\n` +
                                                `  🖼️ *Cara 1 — Kirim Langsung*\n` +
                                                `◈━━━━━━━━━━━━━━━━━━━━━━━◈\n` +
                                                `▸ Kirim *foto* dengan caption *.upswgc [teks]*\n` +
                                                `▸ Kirim *video* dengan caption *.upswgc [teks]*\n` +
                                                `▸ Kirim *audio* dengan caption *.upswgc [teks]*\n\n` +
                                                `◈━━━━━━━━━━━━━━━━━━━━━━━◈\n` +
                                                `  🔁 *Cara 2 — Reply Pesan*\n` +
                                                `◈━━━━━━━━━━━━━━━━━━━━━━━◈\n` +
                                                `▸ Reply *foto/video/audio* + *.upswgc [caption]*\n\n` +
                                                `◈━━━━━━━━━━━━━━━━━━━━━━━◈\n` +
                                                `  💬 *Cara 3 — Kirim Teks*\n` +
                                                `◈━━━━━━━━━━━━━━━━━━━━━━━◈\n` +
                                                `▸ *.upswgc teks pesan kamu*\n\n` +
                                                `_Bot akan menampilkan pilihan grup tujuan_ 👇`
                                        );
                                }

                                const allGids = hisoka.groups.keys().filter(id => id.endsWith('@g.us'));
                                if (!allGids.length) {
                                        if (swgcTempFile && fs.existsSync(swgcTempFile)) fs.unlinkSync(swgcTempFile);
                                        return tolak(hisoka, m, '❌ Tidak ada grup dalam database bot.');
                                }

                                const swgcEncoded = encodeURIComponent(JSON.stringify(swgcMeta));
                                const swgcPrefix = m.prefix || '.';

                                // Hitung total stats semua grup
                                let swgcTotalMember = 0;
                                let swgcTotalAdmin = 0;
                                for (const gid of allGids) {
                                        try {
                                                const gm = hisoka.groups.read(gid);
                                                if (!gm?.participants) continue;
                                                swgcTotalMember += gm.participants.length;
                                                swgcTotalAdmin += gm.participants.filter(p => p.admin).length;
                                        } catch (_) {}
                                }

                                const swgcRows = [
                                        {
                                                title: '📢 Semua Grup',
                                                description: `◆ ${allGids.length} grup  ◆ 👥 ${swgcTotalMember} member  ◆ 🛡️ ${swgcTotalAdmin} admin`,
                                                id: `${swgcPrefix}sendstatus all ${swgcEncoded}`
                                        }
                                ];

                                for (const gid of allGids) {
                                        try {
                                                const meta = hisoka.groups.read(gid);
                                                if (!meta) continue;
                                                const pts = meta.participants || [];
                                                const mTotal = pts.length;
                                                const aTotal = pts.filter(p => p.admin).length;
                                                const aPct = mTotal > 0 ? Math.round((aTotal / mTotal) * 10) : 0;
                                                const aBar = '█'.repeat(aPct) + '░'.repeat(10 - aPct);
                                                swgcRows.push({
                                                        title: (meta.subject || gid).substring(0, 24),
                                                        description: `👥 ${mTotal} member  ◆  🛡️ ${aTotal} admin\n[${aBar}]`,
                                                        id: `${swgcPrefix}sendstatus ${gid} ${swgcEncoded}`
                                                });
                                        } catch (_) {}
                                }

                                // Tentukan label tipe konten
                                const swgcTypeLabel = swgcMeta.type === 'image' ? '🖼️ Gambar'
                                        : swgcMeta.type === 'video' ? '🎥 Video'
                                        : swgcMeta.type === 'audio' ? '🎵 Audio'
                                        : '💬 Teks';
                                const swgcCaptionInfo = swgcMeta.caption ? `\n◆ Caption: _${swgcMeta.caption.substring(0, 40)}${swgcMeta.caption.length > 40 ? '...' : ''}_` : '';

                                const swgcBodyText =
                                        `⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛\n` +
                                        `✦ 📢 *KIRIM GROUP STATUS* ✦\n` +
                                        `⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛\n\n` +
                                        `◈━━━━━━━━━━━━━━━━━━━━━━━◈\n` +
                                        `  📦 *INFO KONTEN*\n` +
                                        `◈━━━━━━━━━━━━━━━━━━━━━━━◈\n` +
                                        `${swgcTypeLabel}${swgcCaptionInfo}\n\n` +
                                        `◈━━━━━━━━━━━━━━━━━━━━━━━◈\n` +
                                        `  🏘️ *STATS SEMUA GRUP*\n` +
                                        `◈━━━━━━━━━━━━━━━━━━━━━━━◈\n` +
                                        `🗂️ Total Grup   ﹕ ${allGids.length} grup\n` +
                                        `👥 Total Member ﹕ ${swgcTotalMember} orang\n` +
                                        `🛡️ Total Admin  ﹕ ${swgcTotalAdmin} orang\n` +
                                        `◈━━━━━━━━━━━━━━━━━━━━━━━◈\n\n` +
                                        `_Pilih grup tujuan di bawah_ 👇`;

                                const swgcMsg = generateWAMessageFromContent(
                                        m.from,
                                        {
                                                viewOnceMessage: {
                                                        message: {
                                                                messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                                                                interactiveMessage: {
                                                                        body: { text: swgcBodyText },
                                                                        nativeFlowMessage: {
                                                                                buttons: [
                                                                                        {
                                                                                                name: 'single_select',
                                                                                                buttonParamsJson: JSON.stringify({
                                                                                                        title: '🏘️ PILIH GRUP TUJUAN',
                                                                                                        sections: [
                                                                                                                { title: '🏘️ Daftar Grup Bot', rows: swgcRows }
                                                                                                        ]
                                                                                                })
                                                                                        }
                                                                                ]
                                                                        }
                                                                }
                                                        }
                                                }
                                        },
                                        { quoted: m },
                                        {}
                                );

                                await hisoka.relayMessage(swgcMsg.key.remoteJid, swgcMsg.message, {
                                        messageId: swgcMsg.key.id
                                });

                                logCommand(m, hisoka, m.command);
                                break;
                        }

                        case 'sendstatus': {
                                if (!m.isOwner) return;

                                const ssArgs = m.text.trim().split(/ +/);
                                if (ssArgs.length < 3) return;

                                const ssTarget = ssArgs[1];
                                const ssEncoded = ssArgs.slice(2).join(' ');

                                let ssMeta;
                                try {
                                        ssMeta = JSON.parse(decodeURIComponent(ssEncoded));
                                } catch (e) {
                                        return tolak(hisoka, m, '❌ Gagal memparse konten: ' + (e.message || e));
                                }

                                const ssAllGids = hisoka.groups.keys().filter(id => id.endsWith('@g.us'));
                                const ssTargets = ssTarget === 'all' ? ssAllGids : [ssTarget];

                                if (!ssTargets.length) return tolak(hisoka, m, '❌ Tidak ada grup tujuan.');

                                let ssRawContent;
                                let ssAudioCaption = null;
                                if (ssMeta.type === 'text') {
                                        ssRawContent = { text: ssMeta.text };
                                } else if (ssMeta.type === 'image') {
                                        ssRawContent = { image: { url: ssMeta.file } };
                                        if (ssMeta.caption) ssRawContent.caption = ssMeta.caption;
                                } else if (ssMeta.type === 'video') {
                                        ssRawContent = { video: { url: ssMeta.file } };
                                        if (ssMeta.caption) ssRawContent.caption = ssMeta.caption;
                                } else if (ssMeta.type === 'audio') {
                                        ssRawContent = { audio: { url: ssMeta.file }, mimetype: ssMeta.mime || 'audio/ogg; codecs=opus', ptt: false };
                                        // Caption audio dikirim terpisah sebagai teks status
                                        if (ssMeta.caption) ssAudioCaption = ssMeta.caption;
                                } else {
                                        return tolak(hisoka, m, '❌ Tipe konten tidak dikenali.');
                                }

                                await tolak(hisoka, m, `⏳ Mengirim sebagai Group Status ke *${ssTargets.length}* grup, mohon tunggu...`);

                                let ssOk = 0, ssFail = 0;
                                for (const gid of ssTargets) {
                                        try {
                                                const ssInside = await generateWAMessageContent(ssRawContent, {
                                                        upload: hisoka.waUploadToServer
                                                });
                                                const ssSecret = crypto.randomBytes(32);
                                                const ssMsg = generateWAMessageFromContent(gid, {
                                                        messageContextInfo: { messageSecret: ssSecret },
                                                        groupStatusMessageV2: {
                                                                message: {
                                                                        ...ssInside,
                                                                        messageContextInfo: { messageSecret: ssSecret }
                                                                }
                                                        }
                                                }, {});
                                                await hisoka.relayMessage(gid, ssMsg.message, { messageId: ssMsg.key.id });

                                                // Kirim caption audio sebagai status teks terpisah
                                                if (ssAudioCaption) {
                                                        await new Promise(r => setTimeout(r, 800));
                                                        const ssCaptionInside = await generateWAMessageContent({ text: ssAudioCaption }, {
                                                                upload: hisoka.waUploadToServer
                                                        });
                                                        const ssCaptionSecret = crypto.randomBytes(32);
                                                        const ssCaptionMsg = generateWAMessageFromContent(gid, {
                                                                messageContextInfo: { messageSecret: ssCaptionSecret },
                                                                groupStatusMessageV2: {
                                                                        message: {
                                                                                ...ssCaptionInside,
                                                                                messageContextInfo: { messageSecret: ssCaptionSecret }
                                                                        }
                                                                }
                                                        }, {});
                                                        await hisoka.relayMessage(gid, ssCaptionMsg.message, { messageId: ssCaptionMsg.key.id });
                                                }

                                                ssOk++;
                                                if (ssTargets.length > 1) await new Promise(r => setTimeout(r, 1000));
                                        } catch (e) {
                                                console.error(`[sendstatus] Gagal ke ${gid}:`, e.message);
                                                ssFail++;
                                        }
                                }

                                if (ssMeta.file && fs.existsSync(ssMeta.file)) {
                                        try { fs.unlinkSync(ssMeta.file); } catch (_) {}
                                }

                                await tolak(hisoka, m, 
                                        `✅ *Selesai Kirim Group Status!*\n\n` +
                                        `📊 *Hasil:*\n` +
                                        `• ✅ Berhasil : ${ssOk} grup\n` +
                                        `• ❌ Gagal    : ${ssFail} grup\n` +
                                        `• 📦 Total    : ${ssTargets.length} grup`
                                );

                                logCommand(m, hisoka, 'sendstatus');
                                break;
                        }

                        case 'gt':
                        case 'gtag':
                        case 'ghosttag': {
                                if (!m.isOwner) return;

                                const gtPrefix = m.prefix || '.';
                                const gtUserJid = hisoka.user?.id;

                                const gtGroupKeys = hisoka.groups.keys().filter(id => id.endsWith('@g.us'));

                                // ── Helper: kirim albumMessage ghosttag ke 1 grup ──
                                async function gtSendOne(jid) {
                                        let participants = [];
                                        try {
                                                const meta = hisoka.groups.read(jid);
                                                participants = (meta?.participants || []).map(v => v.phoneNumber || v.id).filter(Boolean);
                                        } catch (_) {}
                                        if (!participants.length) {
                                                try {
                                                        const fetched = await hisoka.groupMetadata(jid);
                                                        participants = fetched.participants.map(v => v.id).filter(Boolean);
                                                } catch (_) {}
                                        }
                                        if (!participants.length) return 0;
                                        const album = generateWAMessageFromContent(
                                                jid,
                                                {
                                                        albumMessage: {
                                                                expectedImageCount: 0,
                                                                expectedVideoCount: 0,
                                                                contextInfo: { mentionedJid: participants }
                                                        }
                                                },
                                                { userJid: gtUserJid }
                                        );
                                        await hisoka.relayMessage(jid, album.message, { messageId: album.key.id });
                                        return participants.length;
                                }

                                // ── Tampilkan menu button jika tidak ada query / bukan JID / bukan 'all' ──
                                if (!query || (!query.trim().endsWith('@g.us') && query.trim() !== 'all')) {
                                        if (!gtGroupKeys.length) return tolak(hisoka, m, '❌ Bot tidak bergabung di grup manapun.');

                                        const gtBotNum = (hisoka.user?.id || '').split('@')[0].split(':')[0];
                                        const gtTotalMemberAll = gtGroupKeys.reduce((acc, jid) => {
                                                const g = hisoka.groups.read(jid);
                                                return acc + (g?.participants?.length || 0);
                                        }, 0);

                                        const gtSorted = gtGroupKeys
                                                .map(jid => {
                                                        const g = hisoka.groups.read(jid);
                                                        const parts = g?.participants || [];
                                                        const totalMember = parts.length;
                                                        const totalAdmin = parts.filter(p => p.admin).length;
                                                        const isBotAdmin = parts.some(p => {
                                                                const num = (p.jid || p.phoneNumber || p.id || '').split('@')[0].split(':')[0];
                                                                return num === gtBotNum && p.admin;
                                                        });
                                                        return {
                                                                jid,
                                                                name: g?.subject || g?.name || jid,
                                                                totalMember,
                                                                totalAdmin,
                                                                isBotAdmin
                                                        };
                                                })
                                                .sort((a, b) => b.totalMember - a.totalMember || a.name.toLowerCase().localeCompare(b.name.toLowerCase(), 'id', { numeric: true }));

                                        const btn = new Button()
                                                .setBody(
                                                        `『 👻 』 *G H O S T  T A G*\n` +
                                                        `▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` +
                                                        `✦ *Semua Grup* — tag semua grup sekaligus\n` +
                                                        `✦ *Pilih Satu Grup* — pilih dari daftar\n\n` +
                                                        `▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n` +
                                                        `🗂️ Grup   : *${gtGroupKeys.length}* grup\n` +
                                                        `👥 Member : *${gtTotalMemberAll}* total`
                                                )
                                                .setFooter(`⚡ Wily Bot • Ghost Tag System`)
                                                .addReply('🌐 Tag Semua Grup', `${gtPrefix}ghosttag all`)
                                                .addSelection('📂 Pilih Satu Grup')
                                                .makeSections('✦ Daftar Grup');

                                        for (const { jid, name, totalMember, totalAdmin, isBotAdmin } of gtSorted) {
                                                const adminBadge = isBotAdmin ? '👑 Admin' : '👤 Member';
                                                btn.makeRow(
                                                        adminBadge,
                                                        name,
                                                        `👥 ${totalMember} anggota  •  🛡️ ${totalAdmin} admin`,
                                                        `${gtPrefix}ghosttag ${jid}`
                                                );
                                        }

                                        await btn.run(m.from, hisoka, m);
                                        logCommand(m, hisoka, 'ghosttag');
                                        break;
                                }

                                // ── Mode: semua grup ──
                                if (query.trim() === 'all') {
                                        if (!gtGroupKeys.length) return tolak(hisoka, m, '❌ Bot tidak bergabung di grup manapun.');

                                        await tolak(hisoka, m, `⏳ Mengirim ghost tag ke *${gtGroupKeys.length}* grup, mohon tunggu...`);

                                        let gtOk = 0, gtFail = 0, gtTotalMember = 0;
                                        for (const jid of gtGroupKeys) {
                                                try {
                                                        const count = await gtSendOne(jid);
                                                        if (count > 0) { gtOk++; gtTotalMember += count; }
                                                        else gtFail++;
                                                } catch (_) { gtFail++; }
                                                if (gtGroupKeys.length > 1) await new Promise(r => setTimeout(r, 1000));
                                        }

                                        await tolak(hisoka, m, 
                                                `✅ *Ghost Tag Selesai!*\n\n` +
                                                `📊 *Hasil:*\n` +
                                                `• ✅ Berhasil : ${gtOk} grup\n` +
                                                `• ❌ Gagal    : ${gtFail} grup\n` +
                                                `• 👥 Total    : ${gtTotalMember} member di-tag`
                                        );
                                        logCommand(m, hisoka, 'ghosttag');
                                        break;
                                }

                                // ── Mode: satu grup dari JID ──
                                const gtJid = query.trim();
                                try {
                                        const count = await gtSendOne(gtJid);
                                        if (!count) return tolak(hisoka, m, '❌ Tidak ada member ditemukan atau gagal mengambil data grup.');
                                        await tolak(hisoka, m, `✅ Ghost tag berhasil dikirim ke *${count}* member!`);
                                } catch (e) {
                                        await tolak(hisoka, m, '❌ Gagal mengirim ghost tag: ' + (e.message || e));
                                }

                                logCommand(m, hisoka, 'ghosttag');
                                break;
                        }

                        case 'hd':
                        case 'remini':
                        case 'hdr':
                        case 'hdvid':
                        case 'vidhd':
                        case 'hdvideo': {
                                try {
                                        const { hdvideo } = _require(path.resolve('./src/scrape/hdvid.cjs'));
                                        const { hdr } = _require(path.resolve('./src/scrape/iloveimg.cjs'));

                                        const isMediaMsg = m.isMedia && (m.type === 'imageMessage' || m.type === 'videoMessage' || m.type === 'stickerMessage');
                                        const isQuotedMedia = m.isQuoted && quoted.isMedia && (quoted.type === 'imageMessage' || quoted.type === 'videoMessage' || quoted.type === 'stickerMessage');

                                        if (!isMediaMsg && !isQuotedMedia) {
                                                await tolak(hisoka, m,
                                                        `╭═══『 🖼️ *HD Enhancer* 』═══╮\n│\n` +
                                                        `│ Tingkatkan kualitas gambar/video\n` +
                                                        `│ menjadi lebih tajam & jernih!\n│\n` +
                                                        `│ *Cara Pakai:*\n` +
                                                        `│ • Kirim gambar/video dengan caption\n` +
                                                        `│   *.hd* / *.remini* / *.hdvideo*\n` +
                                                        `│ • Atau reply ke gambar/video\n│\n` +
                                                        `│ *Perintah:*\n` +
                                                        `│ *.hd* / *.remini* / *.hdr* → Gambar\n` +
                                                        `│ *.hdvid* / *.vidhd* / *.hdvideo* → Video\n` +
                                                        `│\n╰═════════════════════╯`
                                                );
                                                break;
                                        }

                                        let mediaBuffer;
                                        let mediaType;

                                        if (isMediaMsg) {
                                                mediaBuffer = await m.downloadMedia();
                                                mediaType = m.type;
                                        } else {
                                                mediaBuffer = await downloadMediaMessage(
                                                        { ...m.quoted, message: m.quoted.raw },
                                                        'buffer',
                                                        {},
                                                        { logger: hisoka.logger, reuploadRequest: hisoka.updateMediaMessage }
                                                );
                                                mediaType = quoted.type;
                                        }

                                        if (!mediaBuffer || mediaBuffer.length === 0) {
                                                await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                                await tolak(hisoka, m, '❌ Gagal download media. Coba lagi!');
                                                break;
                                        }

                                        const isVideo = mediaType === 'videoMessage';

                                        await hisoka.sendMessage(m.from, { react: { text: '⏳', key: m.key } });
                                        await tolak(hisoka, m, `⏳ Sedang memproses ${isVideo ? 'video' : 'gambar'} ke kualitas HD...\nMohon tunggu, proses ini membutuhkan waktu.`);

                                        if (isVideo) {
                                                const resultUrl = await hdvideo(mediaBuffer);

                                                await hisoka.sendMessage(m.from, {
                                                        video: { url: resultUrl },
                                                        caption: '✅ Video berhasil diproses ke kualitas HD!'
                                                }, { quoted: m });

                                                await hisoka.sendMessage(m.from, { react: { text: '✅', key: m.key } });
                                        } else {
                                                const resultBuffer = await hdr(mediaBuffer, 4);

                                                await hisoka.sendMessage(m.from, {
                                                        image: Buffer.from(resultBuffer),
                                                        caption: '✅ Gambar berhasil diproses ke kualitas HD!'
                                                }, { quoted: m });

                                                await hisoka.sendMessage(m.from, { react: { text: '✅', key: m.key } });
                                        }

                                        logCommand(m, hisoka, 'hd');
                                } catch (error) {
                                        console.error('\x1b[31m[HD] Error:\x1b[39m', error.message);
                                        await hisoka.sendMessage(m.from, { react: { text: '❌', key: m.key } });
                                        await tolak(hisoka, m, `❌ Gagal memproses media HD: ${error.message}`);
                                }
                                break;
                        }

                        default:
                                break;
                }
        } catch (error) {
                const errMsg = error?.message || String(error);
                const cmdSrc = `command:${m?.command || '?'}`;
                console.error(`\x1b[31m[Handler] Error on command "${m?.command || '?'}":\x1b[39m`, errMsg);
                logError(error, cmdSrc);
                try {
                        if (m?.reply && m?.command) {
                                await tolak(hisoka, m, `❌ Terjadi error pada perintah *.${m.command}*\n\n_${errMsg}_\n\nBot tetap berjalan, coba lagi atau gunakan perintah lain.`);
                        }
                } catch (_) {}
        }
}
